/* SPDX-License-Identifier: BSD-2-Clause */
/* X-SPDX-Copyright-Text: (c) Copyright 2019 Xilinx, Inc. */

#ifndef	EF100_HW_DEFS_H
#define	EF100_HW_DEFS_H

#include <ci/driver/efab/hardware/host_ef100_common.h>

#endif /* EF100_HW_DEFS_H */
