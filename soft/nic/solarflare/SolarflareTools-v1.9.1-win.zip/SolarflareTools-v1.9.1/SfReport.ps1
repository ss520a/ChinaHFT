<#
    Copyright (c) 2020 Xilinx, Inc. All rights reserved.
    Copyright (c) 2018-2019 Solarflare Communications Inc.
    Use is subject to license terms.
#>

<#
.SYNOPSIS
    SfReport
.DESCRIPTION
    Tool to produce report for Solarflare hardware
#>

#Requires -Version 5.1
#Requires -Modules CimCmdlets

class SfReport : Common {

  SfReport([Hashtable] $BaseParams, [String[]] $HardwareIds, [String[]] $Sections, [String] $InvocationName) : base ($BaseParams) {
        if ($HardwareIds) {
            $this.hardwareIds = $HardwareIds
        }
        $this.sections = $Sections
        $this.invocationName = $InvocationName
        $this.partsCount = $this.sections.length
    }

    hidden $sections
    hidden $invocationName
    hidden $sectionError = '<p>An error occurred while reporting {0}</p>'
    hidden $deviceIdPrefixPci = 'PCI\VEN_1924&'
    hidden $partsRun = 0
    hidden $partsCount = 0
    hidden $partsError = 0
    hidden $hardwareIds
    hidden $htmlField = 'Html'
    hidden $dataField = 'Data'
    hidden $errorField = 'Error'

    hidden [Bool] IsSolarflareDevicePresent() {
        $filter = 'DeviceID LIKE "{0}%"' -f $this.deviceIdPrefixPci.Replace('\', '\\')
        $baseParams = $this.baseParams
        $solarflareDevices = CimCmdlets\Get-CimInstance @baseParams -ClassName CIM_LogicalDevice -Filter $filter
        return @($solarflareDevices).Count -gt 0
    }

    hidden [Void] WriteProgress([String] $Message) {
        if ($this.partsCount -gt 0) {
            $progress = ($this.partsRun / $this.partsCount) * 100
            Write-Progress -Activity $Message -PercentComplete $progress
        }
        $this.partsRun += 1
    }

    hidden WriteError([PSCustomObject] $Result, [System.Exception] $Exception) {
        $Result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($this.sectionError -f $Result.Title)
        $Result | Add-Member -NotePropertyName $this.errorField -NotePropertyValue $_.Exception
        $this.partsError++
    }

    hidden [Boolean] HasProperty($object, $propertyName)
    {
        return $object.PSObject.Properties.Name -match $propertyName
    }

    hidden [PSCustomObject] CimInstanceHelper([String] $Namespace, [String] $ClassName, [String] $Title, [String[]] $Columns,
                                     [String] $Group, [String] $Section) {
        $result = [PSCustomObject] @{
            PSTypeName      = "Solarflare.Report.$Section"
            Title           = $Title
            Key             = 'sf_' + $ClassName
            Group           = $Group
            Help            = "$($this.invocationName) -Section $Section"
        }
        $this.WriteProgress($Title)
        try {
            $baseParams = $this.baseParams
            $data = CimCmdlets\Get-CimInstance @baseParams -Namespace $Namespace -ClassName $ClassName
        }
        catch {
            $this.WriteError($result, $_.Exception)
            return $result
        }
        if ($Columns) {
            $html = $data | ConvertTo-Html -Fragment -Property $Columns -As TABLE
        }
        else {
            $html = $data | ConvertTo-Html -Fragment -As TABLE
        }
        $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
        $result | Add-Member -NotePropertyMembers @{$this.htmlField = $html}
        return $result
    }

    hidden [PSCustomObject] GetWinSystemSummary() {
        $result = [PSCustomObject] @{
          PSTypeName  = 'Solarflare.Report.WinSummary'
          Title       = 'System Summary'
          Key         = 'w32_systemsummary'
          Group       = 'System'
          Help        = "$($this.invocationName) -Section WinSummary"
        }
        $this.WriteProgress($result.Title)
        try {
            $baseParams = $this.baseParams
            $computer = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_ComputerSystem
            $bios = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_BIOS
            $os = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_OperatingSystem
            $processor = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_Processor
            $power = CimCmdlets\Get-CimInstance @baseParams -Classname Win32_PowerPlan -Namespace root\cimv2\power |
                        Where-Object IsActive -eq $true
            $summary = [PSCustomObject] @{
                PSTypeName                  = 'Solarflare.Report.WinSystemSummary.Data'
                'OS Name'                   = $os.Caption
                'Version'                   = '{0} {1} {2}' -f $os.Version, $os.CSDVersion, $os.BuildNumber
                'System Name'               = $os.CSName
                'Boot Time'                 = $os.LastBootUpTime
                'System Manufacturer'       = $computer.Manufacturer
                'System Model'              = $computer.Model
                'System Type'               = $computer.SystemType
                'Logical Processor Count'   = $computer.NumberOfLogicalProcessors
                'Processor Count'           = $computer.NumberOfProcessors
                'Processor'                 = $processor | ForEach-Object {
                    '{0} {1} ~{2}MHz' -f $_.Description, $_.Manufacturer, + $_.MaxClockSpeed
                }
                'BIOS Version/Date'         = '{0} {1}, {2}' -f
                                              $bios.Manufacturer, $bios.SMBIOSBIOSVersion, $bios.ReleaseDate
                'SMBIOS Version'            = '{0}.{1}' -f $bios.SMBIOSMajorVersion, $bios.SMBIOSMinorVersion
                'Boot Device'               = $os.BootDevice
                'Time Zone'                 = $os.CurrentTimeZone
                'Total Physical Memory'     = '{0:n0} MB' -f ($os.TotalVisibleMemorySize / 1024)
                'Available Physical Memory' = '{0:n0} MB' -f ($os.FreePhysicalMemory / 1024)
                'Total Virtual Memory'      = '{0:n0} MB' -f ($os.TotalVirtualMemorySize / 1024)
                'Available Virtual Memory'  = '{0:n0} MB' -f ($os.FreeVirtualMemory / 1024)
                'Power Plan'                = if ($null -ne $power) { $power[0].ElementName }
            }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $summary}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data | ConvertTo-Html -Fragment -As List)
        }
        catch {
          $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetStatisticsSummary() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.StatisticsSummary'
            Title = 'Statistics Summary'
            Key   = 'system_stats_summary'
            Group = 'System'
            Help  = "$($this.invocationName) -Section StatisticsSummary"
        }
        $this.WriteProgress($result.Title)
        if (!$this.IsSolarflareDevicePresent()) { return $result }
        try {
            $baseParams = $this.baseParams
            $h1 = CimCmdlets\Get-CimInstance @baseParams -Namespace root/WMI `
                    -ClassName Solarflare_MacStatistics
            $h2 = CimCmdlets\Get-CimInstance @baseParams -Namespace root/StandardCimv2 `
                    -ClassName MSFT_NetAdapterStatisticsSettingData
            $data = ForEach($x1 in $h1) {
                        ForEach($x2 in $h2) {
                            if($x1.InstanceName -eq $x2.InterfaceDescription) {
                                @{
                                    Name = $x2.InterfaceDescription;
                                    RxBytes = $x1.RxBytes;
                                    RxPkts = $x1.RxPkts;
                                    TxBytes = $x1.TxBytes;
                                    TxPkts = $x1.TxPkts;
                                    RxDropEvents = $x1.RxDropEvents;
                                    RxNodescDropCnt = $x1.RxNodescDropCnt;
                                    PmDiscardVfifoFull = $x1.PmDiscardVfifoFull;
                                }
                            }
                        }
                    }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $html = $data | ForEach-Object {
                [PSCustomObject] $_ | ConvertTo-Html -Fragment -As List -Property @(
                        'Name', 'RxBytes', 'RxPkts', 'TxBytes', 'TxPkts',
                        'RxDropEvents', 'RxNodescDropCnt','PmDiscardVfifoFull' )

            }
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue $html
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetWinQfe() {
        $result = [PSCustomObject] @{
          PSTypeName  = 'Solarflare.Report.WinQfe'
          Title       = 'Service Packs & Hot Fixes'
          Key         = 'w32_qfe'
          Group       = 'System'
          Help        = "$($this.invocationName) -Section WinQfe"
        }
        $this.WriteProgress($result.Title)
        try {
            $baseParams = $this.baseParams
            $qfe = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_QuickFixEngineering |
                        Select-Object -Property HotFixID, Description
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $qfe}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                        ConvertTo-Html -Fragment -As List)
        }
        catch {
          $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetWinCpu() {
        $result = [PSCustomObject] @{
            PSTypeName = 'Solarflare.Report.WinCpu'
            Title = 'CPU'
            Key   = 'w32_processor'
            Group = 'System'
            Help  = "$($this.invocationName) -Section WinCpu"
        }
        $this.WriteProgress($result.Title)
        try {
            $baseParams = $this.baseParams
            $cpu = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_Processor |
                        Select-Object -Property DeviceID, Name, Description, NumberOfCores, NumberOfLogicalProcessors,
                            L2CacheSize, L3CacheSize, CurrentClockSpeed, MaxClockSpeed, Availability, CpuStatus,
                            Status, StatusInfo
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $cpu}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                        ConvertTo-Html -Fragment -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetWinRam() {
        $result = [PSCustomObject] @{
            PSTypeName = 'Solarflare.Report.WinRam'
            Title = 'Memory'
            Key   = 'w32_mem'
            Group = 'System'
            Help  = "$($this.invocationName) -Section WinRam"
        }
        $this.WriteProgress($result.Title)
        try {
            $baseParams = $this.baseParams
            $physicalMemory = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_PhysicalMemory
            $physicalMemoryArray = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_PhysicalMemoryArray
            $modules = $physicalMemory | Select-Object -Property Tag, BankLabel, @{
                    n = 'Module Capacity (GB)';
                    e = {$_.Capacity / 1GB}
                },
                Manufacturer, PartNumber, Speed
            $memory = $physicalMemory.Capacity | Measure-Object -Sum |
                        Select-Object -Property @{n = 'Total Memory (GB)'; e = {$_.Sum / 1GB}}
            $slots = $physicalMemoryArray.MemoryDevices |
                        Measure-Object -Sum | Select-Object -Property @{n = 'Slots'; e = {$_.Sum}}
            $ram = New-Object -TypeName PSCustomObject -Property @{
                        PhysicalMemory = $modules;
                        PhysicalMemoryCapacity = $memory;
                        PhysicalMemoryArray = $slots
                    }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $ram}
            $memory = $ram.PhysicalMemory | ConvertTo-Html -Fragment -Property 'Module Capacity (GB)'
            $memoryCapacity = $ram.PhysicalMemoryCapacity | ConvertTo-Html -Fragment -Property 'Total Memory (GB)'
            $memoryArray = $ram.PhysicalMemoryArray | ConvertTo-Html -Fragment -Property 'Slots'
            $html = $memory + $memoryCapacity + $memoryArray
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue $html
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetWinServices() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.WinServices'
            Title = 'Services'
            Key   = 'w32_services'
            Group = 'System'
            Help  = "$($this.invocationName) -Section WinServices"
        }
        $this.WriteProgress($result.Title)
        try {
            $baseParams = $this.baseParams
            $services = CimCmdlets\Get-CimInstance -ClassName Win32_Service @baseParams |
                        Select-Object -Property ProcessId, Name, StartMode, State, Status |
                        Sort-Object -Property Name
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $services}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                        ConvertTo-Html -Fragment -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
            return $result
        }
        return $result
    }

    hidden [PSCustomObject] GetWinNetworkAdapterConfiguration() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.WinNetworkAdapterConfiguration'
            Title = 'Adapter Config'
            Key   = 'w32_networkadapterconfig'
            Group = 'System'
            Help  = "$($this.invocationName) -Section WinNetworkAdapterConfiguration"
        }
        $this.WriteProgress($result.Title)
        try {
            $baseParams = $this.baseParams
            $config = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_NetworkAdapterConfiguration |
                    Select-Object -Property ServiceName, DHCPEnabled, Index, Description
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $config}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                        ConvertTo-Html -Fragment -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetWinNetworkProtocol() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.WinNetworkProtocol'
            Title = 'Protocols'
            Key   = 'w32_networkprotocol'
            Group = 'System'
            Help  = "$($this.invocationName) -Section WinNetworkProtocol"
        }
        $this.WriteProgress($result.Title)
        try {
            $baseParams = $this.baseParams
            $data = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_NetworkProtocol |
                        Select-Object -Property ConnectionlessService, Description, GuaranteesDelivery,
                            GuaranteesSequencing, InstallDate, MaximumAddressSize, MaximumMessageSize,
                            MessageOriented, MinimumAddressSize, Name, PseudoStreamOriented, Status,
                            SupportsBroadcasting, SupportsConnectData, SupportsDisconnectData, SupportsEncryption,
                            SupportsExpeditedData, SupportsFragmentation, SupportsGracefulClosing,
                            SupportsGuaranteedBandwidth, SupportsMulticasting, SupportsQualityofService, Caption
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                        ConvertTo-Html -Fragment -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetWinNetworkAdapter() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.WinNetworkAdapter'
            Title = 'Adapters'
            Key   = 'w32_networkadapter'
            Group = 'System'
            Help  = "$($this.invocationName) -Section WinNetworkAdapter"
        }
        $this.WriteProgress($result.Title)
        try {
            $baseParams = $this.baseParams
            $data = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_NetworkAdapter |
                        Select-Object -Property Name, DeviceID, CreationClassName, PNPDeviceID,
                            SystemName, Speed, AdapterType, Guid, Index, Installed, InterfaceIndex, MACAddress,
                            Manufacturer, NetConnectionID, NetConnectionStatus, NetEnabled,
                            PhysicalAdapter, ProductName, ServiceName, TimeOfLastReset
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                        ConvertTo-Html -Fragment -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetWinPciBridgeDevices() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.WinPciBridgeDevices'
            Title = 'PCI Bridge Devices'
            Key   = 'pci_bridge'
            Group = 'System'
            Help  = "$($this.invocationName) -Section WinPciBridgeDevices"
        }
        $this.WriteProgress($result.Title)
        try {
            $data = $null
            $baseParams = $this.baseParams
            CimCmdlets\Get-CimInstance @baseParams -Query 'SELECT * FROM CIM_LogicalDevice' | ForEach-Object {
                if ($this.HasProperty($_, 'Service')) {
                    if ($_.Service -eq 'pci') {
                        if ($data -eq $null) {
                            $data = @()
                        }
                        $data += $_
                    }
                }
            }
            $data = $data | Select-Object -Property DeviceId, Description
            if ($data -eq $null) {
                $html = '<h5>No PCI bridge devices found</h5>'
                $data = @{}
            }
            else {
                $html = $data | ConvertTo-Html -Fragment -As List -Property @(
                        'Name', 'Source', 'Description', 'OutboundDiscardedPackets', 'OutboundPacketErrors',
                        'RdmaStatistics', 'ReceivedBroadcastBytes', 'ReceivedBroadcastPackets', 'ReceivedBytes',
                        'ReceivedDiscardedPackets', 'ReceivedMulticastBytes', 'ReceivedMulticastPackets',
                        'ReceivedPacketErrors', 'ReceivedUnicastBytes', 'ReceivedUnicastPackets', 'RscStatistics',
                        'SentBroadcastBytes', 'SentBroadcastPackets', 'SentBytes', 'SentMulticastBytes',
                        'SentMulticastPackets', 'SentUnicastBytes', 'SentUnicastPackets', 'SupportedStatistics'
                    )
            }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                        ConvertTo-Html -Fragment -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetWinEventLog() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.WinEventLog'
            Title = 'Event Log'
            Key   = 'w32_ntlogevent'
            Group = 'System'
            Help  = "$($this.invocationName) -Section WinEventLog"
        }
        $this.WriteProgress($result.Title)
        try {
            $baseParams = $this.baseParams
            $data = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_NTLogEvent -Filter $(
                        'type="error" or type="warning" and (logfile="system" or logfile="application")'
                    ) | Select-Object -First 100 -Property EventCode, EventIdentifier, EventType,
                        Logfile, Message, RecordNumber
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                        ConvertTo-Html -Fragment -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [Hashtable] GetWinTeams() {
        $result = @{
            Title = 'Teams'
            Key   = 'sf_teams'
            Group = 'System'
            Help  = "$($this.invocationName) -Section WinTeams"
        }
        $this.WriteProgress($result.Title)
        try {
            $data = $null
            $baseParams = $this.baseParams
            CimCmdlets\Get-CimInstance @baseParams `
              -Namespace root\StandardCimv2 `
              -ClassName MSFT_NetAdapterStatisticsSettingData | ForEach-Object {
                if ($_.InterfaceDescription -like '*Multiplexor*') {
                    if ($data -eq $null) {
                        $data = @()
                    }
                    $data += $_
                }
            }
        }
        catch {
            $this.WriteError($result, $_.Exception)
            return $result
        }
        if ($data -eq $null) {
            $html = '<h5>No configured teams found</h5>'
            $data = @{}
        }
        else {
            $html = $data | ConvertTo-Html -Fragment -As List -Property @(
                    'Name', 'Source', 'Description', 'OutboundDiscardedPackets', 'OutboundPacketErrors',
                    'RdmaStatistics', 'ReceivedBroadcastBytes', 'ReceivedBroadcastPackets', 'ReceivedBytes',
                    'ReceivedDiscardedPackets', 'ReceivedMulticastBytes', 'ReceivedMulticastPackets',
                    'ReceivedPacketErrors', 'ReceivedUnicastBytes', 'ReceivedUnicastPackets', 'RscStatistics',
                    'SentBroadcastBytes', 'SentBroadcastPackets', 'SentBytes', 'SentMulticastBytes',
                    'SentMulticastPackets', 'SentUnicastBytes', 'SentUnicastPackets', 'SupportedStatistics'
                )
        }
        $result.Data = $data
        $result.Html = $html
        return $result
    }

    hidden [PSCustomObject] GetSfPciDevices() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.SfPciDevices'
            Title = 'PCI Devices'
            Key   = 'sf_pci_devices'
            Group = 'Solarflare'
            Help  = "$($this.invocationName) -Section SfPciDevices"
        }
        $this.WriteProgress($result.Title)
        if (!$this.IsSolarflareDevicePresent()) { return $result }
        try {
            $filter = 'DeviceID LIKE "{0}%"' -f $this.deviceIdPrefixPci.Replace('\', '\\')
            $baseParams = $this.baseParams
            $data = CimCmdlets\Get-CimInstance @baseParams -ClassName CIM_LogicalDevice -Filter $filter
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}

            # Replace string[] fields with flattened strings for HTML conversion
            $html = $data |
                Select-Object -Property *,@{ Name='CompatibleId2';
                                             Expression = {[string]::Join(' ',$_.CompatibleID)} },
                                          @{ Name='HardwareId2';
                                             Expression = {[string]::Join(' ',$_.HardwareID)} } `
                              -ExcludeProperty CompatibleID, HardwareID, Cim*, *ClassName |
                Select-Object -Property *,@{ Name='CompatibleID'; Expression = {$_.CompatibleId2} },
                                          @{ Name='HardwareID'; Expression = {$_.HardwareId2} } `
                              -ExcludeProperty CompatibleId2, HardwareId2 |
                ConvertTo-Html -Fragment -As List

            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue $html
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetSfDeviceFiles() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.SfDeviceFiles'
            Title = 'Adapter Files'
            Key   = 'sf_adapter_files'
            Group = 'Solarflare'
            Help  = "$($this.invocationName) -Section SfDeviceFiles"
        }
        $this.WriteProgress($result.Title)
        if (!$this.IsSolarflareDevicePresent()) { return $result }
        try {
            $baseParams = $this.baseParams
            $data = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_CIMLogicalDeviceCIMDataFile |
                ForEach-Object {
                    if ($_.Antecedent.DeviceId.StartsWith($this.deviceIdPrefixPci)) {
                        return New-Object -TypeName PSCustomObject -Property @{
                            File = $_.Dependent.Name;
                            Device = $_.Antecedent.DeviceID
                        }
                    }
                }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                        ConvertTo-Html -Fragment -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetSfDeviceFilesProperties() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.SfDeviceFilesProperties'
            Title = 'File Properties'
            Key   = 'sf_device_files_properties'
            Group = 'Solarflare'
            Help  = "$($this.invocationName) -Section SfDeviceFilesProperties"
        }
        $this.WriteProgress($result.Title)
        if (!$this.IsSolarflareDevicePresent()) { return $result }
        try {
            $keys = @()
            $rows = @()
            $baseParams = $this.baseParams
            CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_CIMLogicalDeviceCIMDataFile | ForEach-Object {
                if ($_.Antecedent.DeviceId.StartsWith($this.deviceIdPrefixPci)) {
                    $name = $_.Dependent.Name.Replace('\', '\\')
                    $filter = 'Name = "{0}"' -f $name
                    if (!($keys -contains $name)) {
                        $keys += $name
                        $file = CimCmdlets\Get-CimInstance @baseParams -ClassName CIM_DataFile -Filter $filter
                        $line = "" | Select-Object -Property Name, Version, FileSize, LastModified
                        $line.name = $file.Name
                        $line.version = $file.Version
                        $line.filesize = $file.FileSize
                        $line.lastmodified = $file.LastModified
                        $rows += $line
                    }
                }
            }
            $data = $rows
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                        ConvertTo-Html -Fragment -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetSfInstalledDrivers() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.SfInstalledDrivers'
            Title = 'Installed Drivers'
            Key   = 'sf_installed_drivers'
            Group = 'Solarflare'
            Help  = "$($this.invocationName) -Section SfInstalledDrivers"
        }
        $this.WriteProgress($result.Title)
        if (!$this.IsSolarflareDevicePresent()) { return $result }
        try {
            $rows = @()
            $baseParams = $this.baseParams
            CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_SystemDriver | ForEach-Object {
                if ($_.Name.StartsWith('SFN')) {
                    $line = '' | Select-Object -Property Name, State, StartMode, ExitCode
                    $line.name = $_.Name
                    $line.state = $_.State
                    $line.startmode = $_.StartMode
                    $line.exitcode = $_.ExitCode
                    $rows += $line
                }
            }
            $data = $rows
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                        ConvertTo-Html -Fragment -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [Hashtable] GetSfNetworkInterfaces_wmi([Hashtable] $baseParams, [String] $deviceIdPrefixPci) {
      $nics = @()
      $props = @()
      $baseParams = $this.baseParams
      CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_NetworkAdapter | ForEach-Object {
          if ($null -eq $_.PNPDeviceID) {
              return
          }
          if ($_.PNPDeviceID.StartsWith($this.deviceIdPrefixPci)) {
              $nics += $_
              $props += Get-NetAdapterAdvancedProperty @baseParams -Name $_.NetConnectionID
          }
      }
      $data = @{ nics = $nics; props = $props }
      return $data
    }

    hidden [Hashtable] GetSfNetworkInterfaces_pnp([Hashtable] $baseParams) {
      $nics = @()
      $props = @()
      $baseParams = $this.baseParams

      $SolarflareAdapters =  Get-SfDeviceInventoryInfo -HardwareId $this.hardwareId
      $SolarflareAdapters | ForEach-Object {
        $nics += $_
      }

      $data = @{ nics = $nics }
      return $data
    }

    hidden [bool] HasWin32NetworkAdapterClass () {
        $baseParams = $this.baseParams
        $adapters = CimCmdlets\Get-CimInstance -Class Win32_NetworkAdapter -Namespace 'root\cimv2' @baseParams
        return $null -ne $adapters
    }

    hidden [PSCustomObject] GetSfNetworkInterfaces() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.SfNetworkInterfaces'
            Title = 'NICs'
            Key   = 'sf_network_interfaces'
            Group = 'Solarflare'
            Help  = "$($this.invocationName) -Section SfNetworkInterfaces"
        }
        $this.WriteProgress($result.Title)
        try {
          $hasWmi = $this.HasWin32NetworkAdapterClass()
          if($hasWmi) {
            $data = $this.GetSfNetworkInterfaces_wmi($this.baseParams, $this.deviceIdPrefixPci)
            $nicsHtml += ($data.nics | ConvertTo-Html -Fragment -Property NetConnectionID, Index, InterfaceIndex,
              MACAddress, NetConnectionStatus, PNPDeviceID, GUID)
            $nicsHtml += ($data.props | ConvertTo-Html -Fragment -Property Name, DisplayName, DisplayValue)
          } else {
           $data = $this.GetSfNetworkInterfaces_pnp($this.baseParams)
           $nicsHtml = ($data.nics | ConvertTo-Html -Fragment)
          }
          $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
          $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue $nicsHtml
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetSfVersions() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.SfVersions'
            Title = 'Versions'
            Key   = 'sf_versions'
            Group = 'Solarflare'
            Help  = "$($this.invocationName)-Section SfVersions"
        }
        $this.WriteProgress($result.Title)
        if (!$this.IsSolarflareDevicePresent()) { return $result }
        try {
            $baseParams = $this.baseParams
            $data = CimCmdlets\Get-CimInstance @baseParams -Namespace root\wmi `
                -ClassName Solarflare_PartitionViewInfoList | ForEach-Object {
                $instance = $_
                New-Object -TypeName PSCustomObject -Property @{
                    InstanceName = $instance.InstanceName;
                    PartitionViewInfo = $_.PartitionViewInfo | ForEach-Object {
                        if ($_.VersionValid) {
                            $version = $_.Version
                            $currentVersion = '{0}.{1}.{2}.{3}' -f
                                $version.Major, $version.Minor, $version.Patch, $version.Build
                            New-Object -TypeName PSCustomObject -Property @{
                                PartitionView  = $_.Name;
                                CurrentVersion = $currentVersion
                            }
                        }
                    }
                }
            }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $html = $data | ForEach-Object {
                '<table>'
                '<tr><td><h5>' + $_.InstanceName + '</h5></td></tr>'
                '<tr><td>'
                '<table>'
                -join (
                    '<tr><th>PartitionView</th>',
                    '<th>Version</th>',
                    '</tr>'
                )
                $_.PartitionViewInfo | ForEach-Object {
                    '<tr><td>' + $_.PartitionView + '</td><td>' + $_.CurrentVersion + '</td></tr>'
                }
                '</table>'
                '</td><tr>'
                '</table>'
            }
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue $html
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetSfSensors() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.SfSensors'
            Title = 'Sensors'
            Key   = 'sf_sensors'
            Group = 'Solarflare'
            Help  = "$($this.invocationName) -Section SfSensors"
        }
        $this.WriteProgress($result.Title)
        if (!$this.IsSolarflareDevicePresent()) { return $result }
        try {
            $states = @('OK', 'Warning', 'Fatal', 'Broken', 'No Reading')
            $units = @('', '', 'C', 'mV', 'mA', 'W', 'RPM')
            $baseParams = $this.baseParams
            $data = CimCmdlets\Get-CimInstance @baseParams -Namespace root/WMI -ClassName Solarflare_Monitoring |
                ForEach-Object {
                $instance = $_
                CimCmdlets\Invoke-CimMethod @baseParams -InputObject $_ `
                    -MethodName Solarflare_Monitoring_GetSensorReadings |
                ForEach-Object {
                    New-Object -TypeName PSCustomObject -Property @{
                        InstanceName = $instance.InstanceName
                        Sensors      = $_.SensorReading | ForEach-Object {
                            $id = $_.Id
                            $sensorDesc = CimCmdlets\Invoke-CimMethod @baseParams -InputObject $instance -MethodName `
                                Solarflare_Monitoring_GetSensorDescription -Arguments @{ Id = $id; } -Confirm:$false
                            if ($sensorDesc -and $sensorDesc.ReturnValue) {
                                $sensorName = $sensorDesc.Description
                            } else {
                                $sensorDesc = CimCmdlets\Invoke-CimMethod @baseParams -InputObject $instance `
                                    -MethodName Solarflare_Monitoring_GetSensorName -Arguments @{ Id = $id; } `
                                    -Confirm:$false
                                if ($sensorDesc -and $sensorDesc.ReturnValue) {
                                    $sensorName = $sensorDesc.Name
                                } else {
                                    $sensorName = $id
                                }
                            }
                            New-Object -TypeName PSCustomObject -Property @{
                                SensorName   = $sensorName;
                                Value        = $_.Value;
                                Unit         = $units[$_.Unit];
                                State        = $states[$_.State];
                                ThresholdMax = $_.ThresholdMax;
                                ThresholdMin = $_.ThresholdMin;
                                CriticalMax  = $_.CriticalMax;
                                CriticalMin  = $_.CriticalMin;
                            }
                        }
                    }
                }
            }
            $html = $data | ForEach-Object {
                '<table>'
                '<tr><td><h5>' + $_.InstanceName + '</h5></td></tr>'
                '<tr><td>'
                '<table>'
                -join (
                    '<tr><th>Sensor</th>',
                    '<th>Value</th>',
                    '<th>Unit</th>',
                    '<th>State</th>',
                    '<th>ThresholdMin</th>',
                    '<th>ThresholdMax</th>',
                    '<th>CriticalMin</th>',
                    '<th>CriticalMax</th>',
                    '</tr>'
                )
                $_.Sensors | ForEach-Object {
                    '<tr><td>' + $_.SensorName + '</td><td>' + $_.Value + '</td><td>' + $_.Unit +
                    '</td><td>' + $_.State +
                    '</td><td>' + $_.ThresholdMin + '</td><td>' + $_.ThresholdMax +
                    '</td><td>' + $_.CriticalMin + '</td><td>' + $_.CriticalMax +
                    '</td></tr>'
                }
                '</table>'
                '</td><tr>'
                '</table>'
            }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue $html
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetSfVpd() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.SfVpd'
            Title = 'VPD'
            Key   = 'sf_vpd'
            Group = 'Solarflare'
            Help  = "$($this.invocationName) -Section SfVpd"
        }
        $this.WriteProgress($result.Title)
        if (!$this.IsSolarflareDevicePresent()) { return $result }
        try {
            $baseParams = $this.baseParams
            $data = New-Object System.Collections.ArrayList
            CimCmdlets\Get-CimInstance @baseParams -Namespace root/WMI -ClassName Solarflare_VPD | ForEach-Object {
                $binding = '' |
                    Select-Object -Property InstanceName, ProductName, SerialNumber, EngineeringChangeLevel, PartNumber
                $binding.InstanceName = $_.InstanceName
                $vpd = CimCmdlets\Invoke-CimMethod -InputObject $_ -MethodName Solarflare_VPD_ReadStringKeyword `
                    -Arguments @{
                        Tag = [byte]2; # ID
                        Keyword = [UInt16]0;
                    } @baseParams
                if ($vpd.ReturnValue) {
                    $binding.ProductName = $vpd.StrData
                }
                $vpd = CimCmdlets\Invoke-CimMethod -InputObject $_ -MethodName Solarflare_VPD_ReadStringKeyword `
                    -Confirm:$false -Arguments @{
                        Tag = [byte]16; # RO
                        Keyword = [UInt16]20051; # 'SN'
                    } @baseParams
                if ($vpd.ReturnValue) {
                    $binding.SerialNumber = $vpd.StrData
                }
                $vpd = CimCmdlets\Invoke-CimMethod -InputObject $_ -MethodName Solarflare_VPD_ReadStringKeyword `
                    -Arguments @{
                        Tag = [byte]16; # RO
                        Keyword = [UInt16]17221; # 'EC'
                    } @baseParams
                if ($vpd.ReturnValue) {
                    $binding.EngineeringChangeLevel = $vpd.StrData
                }
                $vpd = CimCmdlets\Invoke-CimMethod -InputObject $_ -MethodName Solarflare_VPD_ReadStringKeyword `
                    -Arguments @{
                        Tag = [byte]16; # RO
                        Keyword = [UInt16]20048; # 'PN'
                    } @baseParams
                if ($vpd.ReturnValue) {
                    $binding.PartNumber = $vpd.StrData
                }
                $data += $binding
            }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                ConvertTo-Html -Fragment -Property InstanceName, ProductName, SerialNumber,
                    EngineeringChangeLevel, PartNumber -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetNdisRss() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.NdisRss'
            Title = 'RSS'
            Key   = 'ndis_rss'
            Group = 'NDIS'
            Help  = "$($this.invocationName) -Section NdisRss"
        }
        $this.WriteProgress($result.Title)
        try {
            $data = @()
            $baseParams = $this.baseParams
            CimCmdlets\Get-CimInstance @baseParams -Namespace root/StandardCimv2 `
                -ClassName MSFT_NetAdapterRssSettingData | ForEach-Object {
                    $data += $_
                }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($data |
                ConvertTo-Html -Fragment -Property Description, Name, InterfaceAlias, Enabled, Profile,
                    ClassificationAtDpcSupported, ClassificationAtIsrSupported, IndirectionTableEntryCount,
                    IPv4HashEnabled, IPv6ExtensionHashEnabled, IPv6HashEnabled, MaxProcessorGroup,
                    MaxProcessorNumber, MaxProcessors, MsiSupported, MsiXEnabled, MsiXSupported, NumaNode,
                    NumberOfInterruptMessages, NumberOfReceiveQueues, RssOnPortsSupportedTcpIPv4HashEnabled,
                    TcpIPv4HashSupported, TcpIPv6ExtensionHashEnabled, TcpIPv6ExtensionHashSupported,
                    TcpIPv6HashEnabled, TcpIPv6HashSupported, ToeplitzHashFunctionEnabled,
                    ToeplitzHashFunctionSupported -As List)

        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetNdisVmq() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.NdisVmq'
            Title = 'VMQ'
            Key   = 'ndis_vmq'
            Group = 'NDIS'
            Help  = "$($this.invocationName) -Section NdisVmq"
        }
        $this.WriteProgress($result.Title)
        try {
            $data = @()
            $baseParams = $this.baseParams
            CimCmdlets\Get-CimInstance @baseParams -Namespace root/StandardCimv2 `
                -ClassName MSFT_NetAdapterVmqSettingData | ForEach-Object {
                    $data += $_
                }

            $html += ($data | ConvertTo-Html -Fragment -Property Description,
                    Name,
                    Enabled, NumberOfReceiveQueues)

            $dataqueues = @()
            CimCmdlets\Get-CimInstance @baseParams -Namespace root/StandardCimv2 `
                -ClassName MSFT_NetAdapterVmqQueueSettingData | ForEach-Object {
                    if ($_.NumFilters -gt 0) {
                        $queue = $_
                        $_.FilterList | ForEach-Object {
                            $dataqueues += New-Object -TypeName PSCustomObject -Property @{
                                Description = $queue.Description
                                Name = $queue.Name
                                QueueID = $queue.QueueID
                                VmFriendlyName = $queue.VmFriendlyName
                                FilterID = $_.FilterID
                                MacAddress = $_.MacAddress
                                VlanID = $_.VlanID
                            }
                        }
                    }
                    else {
                        $dataqueues += New-Object -TypeName PSCustomObject -Property @{
                            Description = $_.Description
                            Name = $_.Name
                            QueueID = $_.QueueID
                            VmFriendlyName = $_.VmFriendlyName
                            FilterID = $null
                            MacAddress = $null
                            VlanID = $null
                        }
                    }
                }

            $html += ($dataqueues | ConvertTo-Html -Fragment -Property Description, Name,
                    QueueID,
                    VmFriendlyName,
                    QueueName,
                    FilterID,
                    MacAddress,
                    VlanID)

            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data + $dataqueues}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue $html
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetSfStatistics() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.SfStatistics'
            Title = 'Statistics'
            Key   = 'sf_stats'
            Group = 'Solarflare'
            Help  = "$($this.invocationName) -Section SfStatistics"
        }
        $this.WriteProgress($result.Title)
        if (!$this.IsSolarflareDevicePresent()) { return $result }
        try {
            $data = @()
            $baseParams = $this.baseParams
            CimCmdlets\Get-CimInstance @baseParams -Namespace root/WMI -ClassName Solarflare_MacStatistics |
                ForEach-Object {
                    if ($_.InstanceName.StartsWith('Solarflare')) {
                        $data += $_
                    }
                }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($data |
                ConvertTo-Html -Fragment -Property InstanceName, LastUpdateTime,
                FecCorrectedErrors,
                FecCorrectedSymbolsLane0,
                FecCorrectedSymbolsLane1,
                FecCorrectedSymbolsLane2,
                FecCorrectedSymbolsLane3,
                FecUncorrectedErrors,
                PmDiscardBbOverflow,
                PmDiscardMapping,
                PmDiscardQbb, PmDiscardVfifoFull,
                PmTruncBbOverflow,
                PmTruncQbb,
                PmTruncVfifoFull,
                Rx1024To15xxPkts,
                Rx128To255Pkts,
                Rx256To511Pkts,
                Rx512To1023Pkts,
                Rx65To127Pkts,
                RxBrdcstPkts,
                RxBytes,
                RxdpDiDroppedPkts,
                RxdpHlbFetch,
                RxdpHlbIdle,
                RxdpHlbTimeout,
                RxdpHlbWait,
                RxdpQDisabledPkts,
                RxdpScatterDisabledTrunc,
                RxdpStreamingPkts,
                RxDropEvents,
                RxFcsErrors,
                RxGe15xxPkts,
                RxJabberPkts,
                RxLe64Pkts,
                RxMulticstPkts,
                RxNodescDropCnt,
                RxPausePkts,
                RxPkts,
                RxUnicstPkts,
                Tx1024To15xxPkts,
                Tx128To255Pkts,
                Tx256To511Pkts,
                Tx512To1023Pkts,
                Tx65To127Pkts,
                TxBrdcstPkts,
                TxBytes,
                TxGe15xxPkts,
                TxLe64Pkts,
                TxMulticstPkts,
                TxPausePkts,
                TxPkts,
                TxUnicstPkts,
                VadapterRxBadBytes,
                VadapterRxBadPackets,
                VadapterRxBroadcastBytes,
                VadapterRxBroadcastPackets,
                VadapterRxMulticastBytes,
                VadapterRxMulticastPackets,
                VadapterRxOverflow,
                VadapterRxUnicastBytes,
                VadapterRxUnicastPackets,
                VadapterTxBadBytes,
                VadapterTxBadPackets,
                VadapterTxBroadcastBytes,
                VadapterTxBroadcastPackets,
                VadapterTxMulticastBytes,
                VadapterTxMulticastPackets,
                VadapterTxOverflow,
                VadapterTxUnicastBytes,
                VadapterTxUnicastPackets -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] GetSfProtocolBindings() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.SfProtocolBindings'
            Title = 'Protocol Bindings'
            Key   = 'w32_protocolbindings'
            Group = 'Solarflare'
            Help  = "$($this.invocationName) -Section SfProtocolBindings"
        }
        $this.WriteProgress($result.Title)
        if (!$this.IsSolarflareDevicePresent()) { return $result }
        try {
            $baseParams = $this.baseParams
            $rawbindings = CimCmdlets\Get-CimInstance @baseParams -ClassName Win32_ProtocolBinding
            $data = New-Object System.Collections.ArrayList
            $rawbindings | ForEach-Object {
                $driver = $_.Dependent.Name
                if (!($driver -eq 'SFNDIS')) {
                    return
                }
                $protocol = $_.Antecedent.Name
                $deviceId = $_.Device.DeviceID
                $binding = '' | Select-Object -Property Protocol, Driver, Adapter
                $binding.Protocol = $protocol
                $binding.Driver = $driver
                $binding.Adapter = $deviceId
                $data += $binding
            }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($result.Data |
                ConvertTo-Html -Fragment -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [PSCustomObject] NdisWmiMethodHelper([String] $Namespace, [String] $ClassName, [String] $Method,
        [ScriptBlock] $Expression,
        [String] $Title, [String[]] $Columns, [String] $Group, [String] $Section) {
        $result = [PSCustomObject] @{
            PSTypeName      = "Solarflare.Report.$Section"
            Title           = $Title
            Key             = 'sf_' + $ClassName
            Group           = $Group
            Help            = "$($this.invocationName) -Section $Section"
        }
        $this.WriteProgress($Title)
        try {
            $data = @()
            $hdr = ([wmiclass]'root\wmi:MSNdis_ObjectHeader').CreateInstance()
            $hdr.Revision      = 1
            $hdr.Type          = 0x02
            $hdr.Size          = 0xffff
            $whdr = ([wmiclass]'root\wmi:MSNdis_WmiMethodHeader').CreateInstance()
            $whdr.Header       = $hdr
            $whdr.PortNumber   = 0
            $whdr.NetLuid      = 0
            $whdr.Padding      = 0
            $whdr.RequestId    = 0
            $whdr.Timeout      = 10
            Get-WmiObject -Namespace $Namespace -ClassName $ClassName |
                ForEach-Object {
                    $methodout = Invoke-WmiMethod -InputObject $_ -Name $Method -ArgumentList $whdr
                    $entry = & $Expression $_.InstanceName $ClassName $methodout
                    $data += $entry
                }
        }
        catch {
            $this.WriteError($result, $_.Exception)
            return $result
        }
        if ($Columns) {
            $html = $data | ConvertTo-Html -Fragment -Property $Columns -As TABLE
        }
        else {
            $html = $data | ConvertTo-Html -Fragment -As TABLE
        }
        $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
        $result | Add-Member -NotePropertyMembers @{$this.htmlField = $html}
        return $result
    }


    hidden [PSCustomObject] GetNdisTransmitsError() {
        return $this.CimInstanceHelper('root/WMI', 'MSNdis_TransmitsError', 'Transmit Error Counts', @(
                'InstanceName', 'Active', 'NdisTransmitsError'
                ), 'NDIS', 'NdisTransmitsError')
    }

    hidden [PSCustomObject] GetNdisReceiveBlockSize() {
        return $this.CimInstanceHelper('root/WMI', 'MSNdis_TransmitBufferSpace', 'Transmit Buffer Space', @(
            'InstanceName', 'Active', 'NdisTransmitBufferSpace'
            ), 'NDIS', 'NdisReceiveBlockSize')
    }

    hidden [PSCustomObject] GetNdisTransmitBlockSize() {
        return $this.CimInstanceHelper('root/WMI', 'MSNdis_ReceiveBlockSize', 'Receive Block Sizes', @(
            'InstanceName', 'Active', 'NdisReceiveBlockSize'
            ), 'NDIS', 'NdisTransmitBlockSize')
    }

    hidden [PSCustomObject] GetNdisMaximumFrameSize() {
        return $this.CimInstanceHelper('root/WMI', 'MSNdis_TransmitBlockSize', 'Transmit Block Sizes', @(
            'InstanceName', 'Active', 'NdisTransmitBlockSize'
            ), 'NDIS', 'NdisMaximumFrameSize')
    }

    hidden [PSCustomObject] GetNdisTransmitsOk() {
        return $this.CimInstanceHelper('root/WMI', 'MSNdis_MaximumFrameSize', 'Maximum Frame Size', @(
            'InstanceName', 'Active', 'NdisMaximumFrameSize'
            ), 'NDIS', 'NdisTransmitsOk')
    }

    hidden [PSCustomObject] GetNdisReceivesOk() {
        return $this.CimInstanceHelper('root/WMI', 'MSNdis_TransmitsOk', 'Transmit OK Counts', @(
            'InstanceName', 'Active', 'NdisTransmitsOk'
            ), 'NDIS', 'NdisReceivesOk')
    }

    hidden [PSCustomObject] GetNdisEnumerateAdapterEx() {
        return $this.CimInstanceHelper('root/WMI', 'MSNdis_ReceivesOk', 'Receive OK Counts', @(
            'InstanceName', 'Active', 'NdisReceivesOk'
            ), 'NDIS', 'NdisEnumerateAdapterEx')
    }

    hidden [PSCustomObject] GetNdisMediaConnectStatus() {
        return $this.CimInstanceHelper('root/WMI', 'MSNdis_MediaConnectStatus', 'Media Connect Status', @(
            'InstanceName', 'Active', 'NdisMediaConnectStatus'
            ), 'NDIS', 'NdisMediaConnectStatus')
    }

    hidden [PSCustomObject] GetNdisMacOptions() {
        return $this.CimInstanceHelper('root/WMI', 'MSNdis_MacOptions', 'MAC Options', @(
            'InstanceName', 'Active', 'NdisMacOptions'
            ), 'NDIS', 'NdisMacOptions')
    }

    hidden [PSCustomObject] GetNdisHardwareStatus() {
        return $this.CimInstanceHelper('root/WMI', 'MSNdis_HardwareStatus', 'Hardware Status', @(
            'InstanceName', 'Active', 'NdisHardwareStatus'
            ), 'NDIS', 'NdisHardwareStatus')
    }


    hidden [PSCustomObject] GetNdisLinkState() {
        if ($this.baseParams.ContainsKey('CimSession')) {
            return $null
        } else {
            [ScriptBlock] $Expression = {
                Param(
                    [String] $InstanceName,
                    [String] $ClassName,
                    [object] $MethodOut
                )
                $entry = [PSCustomObject] @{
                PSTypeName  = "Solarflare.Report.$ClassName"
                    InstanceName = $InstanceName
                    MediaConnectState = $MethodOut.LinkState.MediaConnectState
                    MediaDuplexState = $MethodOut.LinkState.MediaDuplexState
                    PauseFunctions = $MethodOut.LinkState.PauseFunctions
                    AutoNegotiationFlags = $MethodOut.LinkState.AutoNegotiationFlags
                    RcvLinkSpeed = 0
                    XmitLinkSpeed = 0
                }
                if (![uint64]::MaxValue.Equals($methodout.LinkState.RcvLinkSpeed)) {
                    $entry.RcvLinkSpeed = $methodout.LinkState.RcvLinkSpeed
                }
                if (![uint64]::MaxValue.Equals($methodout.LinkState.XmitLinkSpeed)) {
                    $entry.XmitLinkSpeed = $methodout.LinkState.XmitLinkSpeed
                }
                $entry
            }
            return $this.NdisWmiMethodHelper('root/WMI', 'MSNdis_LinkState', 'WmiQueryLinkState',
                $Expression, 'Link State', @(
                'InstanceName',
                'MediaConnectState', 'MediaDuplexState',
                'PauseFunctions', 'AutoNegotiationFlags',
                'RcvLinkSpeed', 'XmitLinkSpeed'
                ), 'NDIS', 'NdisLinkState')
        }
    }

    hidden [PSCustomObject] GetNdisStatistics() {
        $result = [PSCustomObject] @{
            PSTypeName  = 'Solarflare.Report.NdisStatistics'
            Title = 'Statistics'
            Key   = 'ndis_stats'
            Group = 'NDIS'
            Help  = "$($this.invocationName) -Section NdisStatistics"
        }
        $this.WriteProgress($result.Title)
        try {
            $data = @()
            $baseParams = $this.baseParams
            CimCmdlets\Get-CimInstance @baseParams -Namespace root/StandardCimv2 `
                -ClassName MSFT_NetAdapterStatisticsSettingData | ForEach-Object {
                    $data += $_
                }
            $result | Add-Member -NotePropertyMembers @{$this.dataField = $data}
            $result | Add-Member -NotePropertyName $this.htmlField -NotePropertyValue ($data |
                ConvertTo-Html -Fragment -Property Description, Name,
                OutboundDiscardedPackets, OutboundPacketErrors,
                ReceivedBroadcastBytes, ReceivedBroadcastPacket, ReceivedBytes,
                ReceivedDiscardedPackets, ReceivedMulticastBytes, ReceivedMulticastPackets,
                ReceivedPacketErrors, ReceivedUnicastBytes, ReceivedUnicastPackets, SentBroadcastBytes,
                SentBroadcastPackets, SentBytes, SentMulticastBytes, SentMulticastPackets,
                SentUnicastBytes, SentUnicastPackets, SupportedStatistics -As List)
        }
        catch {
            $this.WriteError($result, $_.Exception)
        }
        return $result
    }

    hidden [System.Collections.ArrayList] GetSfAllReportSections() {
        $array = New-Object System.Collections.ArrayList
        if($this.sections -contains 'WinSummary') { $array.Add($this.GetWinSystemSummary()) }
        if($this.sections -contains 'StatisticsSummary') { $array.Add($this.GetStatisticsSummary()) }
        if($this.sections -contains 'WinQfe') { $array.Add($this.GetWinQfe()) }
        if($this.sections -contains 'WinCpu') { $array.Add($this.GetWinCpu()) }
        if($this.sections -contains 'WinRam') { $array.Add($this.GetWinRam()) }
        if($this.sections -contains 'WinServices') { $array.Add($this.GetWinServices()) }
        if($this.sections -contains 'WinNetworkAdapterConfiguration') { $array.Add($this.GetWinNetworkAdapterConfiguration()) }
        if($this.sections -contains 'WinNetworkProtocol') { $array.Add($this.GetWinNetworkProtocol()) }
        if($this.sections -contains 'WinNetworkAdapter') { $array.Add($this.GetWinNetworkAdapter()) }
        if($this.sections -contains 'WinPciBridgeDevices') { $array.Add($this.GetWinPciBridgeDevices()) }
        if($this.sections -contains 'WinEventLog') { $array.Add($this.GetWinEventLog()) }
        if($this.sections -contains 'WinTeams') { $array.Add($this.GetWinTeams()) }
        if($this.sections -contains 'SfPciDevices') { $array.Add($this.GetSfPciDevices()) }
        if($this.sections -contains 'SfDeviceFiles') { $array.Add($this.GetSfDeviceFiles()) }
        if($this.sections -contains 'SfDeviceFilesProperties') { $array.Add($this.GetSfDeviceFilesProperties()) }
        if($this.sections -contains 'SfInstalledDrivers') { $array.Add($this.GetSfInstalledDrivers()) }
        if($this.sections -contains 'SfNetworkInterfaces') { $array.Add($this.GetSfNetworkInterfaces()) }
        if($this.sections -contains 'SfVersions') { $array.Add($this.GetSfVersions()) }
        if($this.sections -contains 'SfSensors') { $array.Add($this.GetSfSensors()) }
        if($this.sections -contains 'SfVpd') { $array.Add($this.GetSfVpd()) }
        if($this.sections -contains 'SfStatistics') { $array.Add($this.GetSfStatistics()) }
        if($this.sections -contains 'SfProtocolBindings') { $array.Add($this.GetSfProtocolBindings()) }
        if($this.sections -contains 'NdisLinkState') { $array.Add($this.GetNdisLinkState()) }
        if($this.sections -contains 'NdisStatistics') { $array.Add($this.GetNdisStatistics()) }
        if($this.sections -contains 'NdisTransmitsError') { $array.Add($this.GetNdisTransmitsError()) }
        if($this.sections -contains 'NdisReceiveBlockSize') { $array.Add($this.GetNdisReceiveBlockSize()) }
        if($this.sections -contains 'NdisTransmitBlockSize') { $array.Add($this.GetNdisTransmitBlockSize()) }
        if($this.sections -contains 'NdisMaximumFrameSize') { $array.Add($this.GetNdisMaximumFrameSize()) }
        if($this.sections -contains 'NdisTransmitsOk') { $array.Add($this.GetNdisTransmitsOk()) }
        if($this.sections -contains 'NdisReceivesOk') { $array.Add($this.GetNdisReceivesOk()) }
        if($this.sections -contains 'NdisEnumerateAdapterEx') { $array.Add($this.GetNdisEnumerateAdapterEx()) }
        if($this.sections -contains 'NdisMediaConnectStatus') { $array.Add($this.GetNdisMediaConnectStatus()) }
        if($this.sections -contains 'NdisMacOptions') { $array.Add($this.GetNdisMacOptions()) }
        if($this.sections -contains 'NdisHardwareStatus') { $array.Add($this.GetNdisHardwareStatus()) }
        if($this.sections -contains 'NdisRss') { $array.Add($this.GetNdisRss()) }
        if($this.sections -contains 'NdisVmq') { $array.Add($this.GetNdisVmq()) }
        return $array
    }

    [PSCustomObject] GetSfReportHtml() {
        $data = $this.GetSfAllReportSections()
        $CssOverrides = -join(
                '/* tab formatting */ ',
                '.tabitem { list-style-type: none; } .tabmenu { padding: 0 1.0rem 0 0; } ',
                'h3, h4 { clear: both; } h4 { padding: 4.0rem 0 0 0; } html { font-size: 0.5em; }'
            )
        $SwitchTabScript = -join (
                'function switchTab(tab_id, tab_content) { ',
                'var i; var x = document.getElementsByClassName("tabcontent"); ',
                'if (tab_id === "tb_all") { for (i = 0; i < x.length; i++) { x[i].style.display = "block"; } ',
                '} else { for (i = 0; i < x.length; i++) { x[i].style.display = "none"; } ',
                'document.getElementById(tab_content).style.display = "block"; } ',
                'var x = document.getElementsByClassName("tabmenu"); var i; ',
                'for (i = 0; i < x.length; i++) { x[i].className = "tabmenu"; } ',
                'document.getElementById(tab_id).className = "tabmenu active"; }'
            )
        $ReportTitle = 'Solarflare Report'
        $errors = ''
        if ($this.partsError -ne 0) {
            $errors = "<h3>{0} of {1} sections failed</h3>" -f $this.partsError, $($this.partsCount + 1)
        }
        $Head = "<title>{0}</title><style>{1}{2}</style><script>{3}</script>" -f
                    $ReportTitle, $this.Milligram, $CssOverrides, $SwitchTabScript
        $title = "<h1>$ReportTitle</h1>`n<h5>Updated: on $(Get-Date)</h5>$errors"

        $groupA = $null
        $groupB = $null
        $groupC = $null
        $content = ''

        foreach ($sec in $data.GetEnumerator()) {
            $tabs = -join (
                        "<li class=""float-left tabitem"">",
                        "<a href=""javascript:switchTab('tb_$($sec.Key)', 'content_$($sec.Key)');"" ",
                        "id=""tb_$($sec.Key)"" class=""tabmenu"">$($sec.Title)</a></li>`n"
                    )
            switch ($sec.Group) {
              'System' { $groupA += $tabs }
              'Solarflare' { $groupB += $tabs }
              'NDIS' { $groupC += $tabs }
          }
          $content += -join (
                          "<div id=""content_$($sec.Key)"" class=""tabcontent"">",
                          "<h4>$($sec.Title) ($($sec.Group))</h4>$($sec.Html)",
                          "<code>$($sec.Help)</code></div>"
                      )
        }
        $all = -join (
                 "<li class=""float-left tabitem"">",
                 "<a href=""javascript:switchTab('tb_all', 'content_all');"" id=""tb_all"" class=""tabmenu active"">",
                 "ALL</a></li>`n"
               )

        $html = ConvertTo-HTML -Head $Head -Body $(-join (
            "$title <h3>System</h3> <ul> $all $groupA </ul> <h3>Solarflare</h3> <ul> $groupB </ul> ",
            "<h3>NDIS</h3> <ul> $groupC </ul> $content")
        )

        $reportData = [PSCustomObject]@{
          PSTypeName = 'Solarflare.ReportData'
          Data = $data
          Html = $html
        }

        return $reportData
    }

    $Milligram = @"
    /*!
    * Milligram v1.3.0
    * https://milligram.github.io
    *
    * Copyright (c) 2018 CJ Patoilo
    * Licensed under the MIT license
    */

   *,
   *:after,
   *:before {
     box-sizing: inherit;
   }

   html {
     box-sizing: border-box;
     font-size: 62.5%;
   }

   body {
     color: #606c76;
     font-family: 'Roboto', 'Helvetica Neue', 'Helvetica', 'Arial', sans-serif;
     font-size: 1.6em;
     letter-spacing: .01em;
     line-height: 1.6;
   }

   blockquote {
     border-left: 0.3rem solid #d1d1d1;
     margin-left: 0;
     margin-right: 0;
     padding: 1rem 1.5rem;
   }

   blockquote *:last-child {
     margin-bottom: 0;
   }

   .button,
   button,
   input[type='button'],
   input[type='reset'],
   input[type='submit'] {
     background-color: #9b4dca;
     border: 0.1rem solid #9b4dca;
     border-radius: .4rem;
     color: #fff;
     cursor: pointer;
     display: inline-block;
     font-size: 1.1rem;
     font-weight: 700;
     height: 3.8rem;
     letter-spacing: .1rem;
     line-height: 3.8rem;
     padding: 0 3.0rem;
     text-align: center;
     text-decoration: none;
     text-transform: uppercase;
     white-space: nowrap;
   }

   .button:focus, .button:hover,
   button:focus,
   button:hover,
   input[type='button']:focus,
   input[type='button']:hover,
   input[type='reset']:focus,
   input[type='reset']:hover,
   input[type='submit']:focus,
   input[type='submit']:hover {
     background-color: #606c76;
     border-color: #606c76;
     color: #fff;
     outline: 0;
   }

   .button[disabled],
   button[disabled],
   input[type='button'][disabled],
   input[type='reset'][disabled],
   input[type='submit'][disabled] {
     cursor: default;
     opacity: .5;
   }

   .button[disabled]:focus, .button[disabled]:hover,
   button[disabled]:focus,
   button[disabled]:hover,
   input[type='button'][disabled]:focus,
   input[type='button'][disabled]:hover,
   input[type='reset'][disabled]:focus,
   input[type='reset'][disabled]:hover,
   input[type='submit'][disabled]:focus,
   input[type='submit'][disabled]:hover {
     background-color: #9b4dca;
     border-color: #9b4dca;
   }

   .button.button-outline,
   button.button-outline,
   input[type='button'].button-outline,
   input[type='reset'].button-outline,
   input[type='submit'].button-outline {
     background-color: transparent;
     color: #9b4dca;
   }

   .button.button-outline:focus, .button.button-outline:hover,
   button.button-outline:focus,
   button.button-outline:hover,
   input[type='button'].button-outline:focus,
   input[type='button'].button-outline:hover,
   input[type='reset'].button-outline:focus,
   input[type='reset'].button-outline:hover,
   input[type='submit'].button-outline:focus,
   input[type='submit'].button-outline:hover {
     background-color: transparent;
     border-color: #606c76;
     color: #606c76;
   }

   .button.button-outline[disabled]:focus, .button.button-outline[disabled]:hover,
   button.button-outline[disabled]:focus,
   button.button-outline[disabled]:hover,
   input[type='button'].button-outline[disabled]:focus,
   input[type='button'].button-outline[disabled]:hover,
   input[type='reset'].button-outline[disabled]:focus,
   input[type='reset'].button-outline[disabled]:hover,
   input[type='submit'].button-outline[disabled]:focus,
   input[type='submit'].button-outline[disabled]:hover {
     border-color: inherit;
     color: #9b4dca;
   }

   .button.button-clear,
   button.button-clear,
   input[type='button'].button-clear,
   input[type='reset'].button-clear,
   input[type='submit'].button-clear {
     background-color: transparent;
     border-color: transparent;
     color: #9b4dca;
   }

   .button.button-clear:focus, .button.button-clear:hover,
   button.button-clear:focus,
   button.button-clear:hover,
   input[type='button'].button-clear:focus,
   input[type='button'].button-clear:hover,
   input[type='reset'].button-clear:focus,
   input[type='reset'].button-clear:hover,
   input[type='submit'].button-clear:focus,
   input[type='submit'].button-clear:hover {
     background-color: transparent;
     border-color: transparent;
     color: #606c76;
   }

   .button.button-clear[disabled]:focus, .button.button-clear[disabled]:hover,
   button.button-clear[disabled]:focus,
   button.button-clear[disabled]:hover,
   input[type='button'].button-clear[disabled]:focus,
   input[type='button'].button-clear[disabled]:hover,
   input[type='reset'].button-clear[disabled]:focus,
   input[type='reset'].button-clear[disabled]:hover,
   input[type='submit'].button-clear[disabled]:focus,
   input[type='submit'].button-clear[disabled]:hover {
     color: #9b4dca;
   }

   code {
     background: #f4f5f6;
     border-radius: .4rem;
     font-size: 86%;
     margin: 0 .2rem;
     padding: .2rem .5rem;
     white-space: nowrap;
   }

   pre {
     background: #f4f5f6;
     border-left: 0.3rem solid #9b4dca;
     overflow-y: hidden;
   }

   pre > code {
     border-radius: 0;
     display: block;
     padding: 1rem 1.5rem;
     white-space: pre;
   }

   hr {
     border: 0;
     border-top: 0.1rem solid #f4f5f6;
     margin: 3.0rem 0;
   }

   input[type='email'],
   input[type='number'],
   input[type='password'],
   input[type='search'],
   input[type='tel'],
   input[type='text'],
   input[type='url'],
   input[type='color'],
   input[type='date'],
   input[type='month'],
   input[type='week'],
   input[type='datetime'],
   input[type='datetime-local'],
   input:not([type]),
   textarea,
   select {
     -webkit-appearance: none;
        -moz-appearance: none;
             appearance: none;
     background-color: transparent;
     border: 0.1rem solid #d1d1d1;
     border-radius: .4rem;
     box-shadow: none;
     box-sizing: inherit;
     height: 3.8rem;
     padding: .6rem 1.0rem;
     width: 100%;
   }

   input[type='email']:focus,
   input[type='number']:focus,
   input[type='password']:focus,
   input[type='search']:focus,
   input[type='tel']:focus,
   input[type='text']:focus,
   input[type='url']:focus,
   input[type='color']:focus,
   input[type='date']:focus,
   input[type='month']:focus,
   input[type='week']:focus,
   input[type='datetime']:focus,
   input[type='datetime-local']:focus,
   input:not([type]):focus,
   textarea:focus,
   select:focus {
     border-color: #9b4dca;
     outline: 0;
   }

   select {
     background: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="14" viewBox="0 0 29 14" width="29"><path fill="%23d1d1d1" d="M9.37727 3.625l5.08154 6.93523L19.54036 3.625"/></svg>') center right no-repeat;
     padding-right: 3.0rem;
   }

   select:focus {
     background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="14" viewBox="0 0 29 14" width="29"><path fill="%239b4dca" d="M9.37727 3.625l5.08154 6.93523L19.54036 3.625"/></svg>');
   }

   textarea {
     min-height: 6.5rem;
   }

   label,
   legend {
     display: block;
     font-size: 1.6rem;
     font-weight: 700;
     margin-bottom: .5rem;
   }

   fieldset {
     border-width: 0;
     padding: 0;
   }

   input[type='checkbox'],
   input[type='radio'] {
     display: inline;
   }

   .label-inline {
     display: inline-block;
     font-weight: normal;
     margin-left: .5rem;
   }

   .container {
     margin: 0 auto;
     max-width: 112.0rem;
     padding: 0 2.0rem;
     position: relative;
     width: 100%;
   }

   .row {
     display: flex;
     flex-direction: column;
     padding: 0;
     width: 100%;
   }

   .row.row-no-padding {
     padding: 0;
   }

   .row.row-no-padding > .column {
     padding: 0;
   }

   .row.row-wrap {
     flex-wrap: wrap;
   }

   .row.row-top {
     align-items: flex-start;
   }

   .row.row-bottom {
     align-items: flex-end;
   }

   .row.row-center {
     align-items: center;
   }

   .row.row-stretch {
     align-items: stretch;
   }

   .row.row-baseline {
     align-items: baseline;
   }

   .row .column {
     display: block;
     flex: 1 1 auto;
     margin-left: 0;
     max-width: 100%;
     width: 100%;
   }

   .row .column.column-offset-10 {
     margin-left: 10%;
   }

   .row .column.column-offset-20 {
     margin-left: 20%;
   }

   .row .column.column-offset-25 {
     margin-left: 25%;
   }

   .row .column.column-offset-33, .row .column.column-offset-34 {
     margin-left: 33.3333%;
   }

   .row .column.column-offset-50 {
     margin-left: 50%;
   }

   .row .column.column-offset-66, .row .column.column-offset-67 {
     margin-left: 66.6666%;
   }

   .row .column.column-offset-75 {
     margin-left: 75%;
   }

   .row .column.column-offset-80 {
     margin-left: 80%;
   }

   .row .column.column-offset-90 {
     margin-left: 90%;
   }

   .row .column.column-10 {
     flex: 0 0 10%;
     max-width: 10%;
   }

   .row .column.column-20 {
     flex: 0 0 20%;
     max-width: 20%;
   }

   .row .column.column-25 {
     flex: 0 0 25%;
     max-width: 25%;
   }

   .row .column.column-33, .row .column.column-34 {
     flex: 0 0 33.3333%;
     max-width: 33.3333%;
   }

   .row .column.column-40 {
     flex: 0 0 40%;
     max-width: 40%;
   }

   .row .column.column-50 {
     flex: 0 0 50%;
     max-width: 50%;
   }

   .row .column.column-60 {
     flex: 0 0 60%;
     max-width: 60%;
   }

   .row .column.column-66, .row .column.column-67 {
     flex: 0 0 66.6666%;
     max-width: 66.6666%;
   }

   .row .column.column-75 {
     flex: 0 0 75%;
     max-width: 75%;
   }

   .row .column.column-80 {
     flex: 0 0 80%;
     max-width: 80%;
   }

   .row .column.column-90 {
     flex: 0 0 90%;
     max-width: 90%;
   }

   .row .column .column-top {
     align-self: flex-start;
   }

   .row .column .column-bottom {
     align-self: flex-end;
   }

   .row .column .column-center {
     -ms-grid-row-align: center;
         align-self: center;
   }

   @media (min-width: 40rem) {
     .row {
       flex-direction: row;
       margin-left: -1.0rem;
       width: calc(100% + 2.0rem);
     }
     .row .column {
       margin-bottom: inherit;
       padding: 0 1.0rem;
     }
   }

   a {
     color: #9b4dca;
     text-decoration: none;
   }

   a:focus, a:hover {
     color: #606c76;
   }

   dl,
   ol,
   ul {
     list-style: none;
     margin-top: 0;
     padding-left: 0;
   }

   dl dl,
   dl ol,
   dl ul,
   ol dl,
   ol ol,
   ol ul,
   ul dl,
   ul ol,
   ul ul {
     font-size: 90%;
     margin: 1.5rem 0 1.5rem 3.0rem;
   }

   ol {
     list-style: decimal inside;
   }

   ul {
     list-style: circle inside;
   }

   .button,
   button,
   dd,
   dt,
   li {
     margin-bottom: 1.0rem;
   }

   fieldset,
   input,
   select,
   textarea {
     margin-bottom: 1.5rem;
   }

   blockquote,
   dl,
   figure,
   form,
   ol,
   p,
   pre,
   table,
   ul {
     margin-bottom: 2.5rem;
   }

   table {
     border-spacing: 0;
     width: 100%;
   }

   td,
   th {
     border-bottom: 0.1rem solid #e1e1e1;
     padding: 1.2rem 1.5rem;
     text-align: left;
   }

   td:first-child,
   th:first-child {
     padding-left: 0;
   }

   td:last-child,
   th:last-child {
     padding-right: 0;
   }

   b,
   strong {
     font-weight: bold;
   }

   p {
     margin-top: 0;
   }

   h1,
   h2,
   h3,
   h4,
   h5,
   h6 {
     font-weight: 300;
     letter-spacing: -.1rem;
     margin-bottom: 2.0rem;
     margin-top: 0;
   }

   h1 {
     font-size: 4.6rem;
     line-height: 1.2;
   }

   h2 {
     font-size: 3.6rem;
     line-height: 1.25;
   }

   h3 {
     font-size: 2.8rem;
     line-height: 1.3;
   }

   h4 {
     font-size: 2.2rem;
     letter-spacing: -.08rem;
     line-height: 1.35;
   }

   h5 {
     font-size: 1.8rem;
     letter-spacing: -.05rem;
     line-height: 1.5;
   }

   h6 {
     font-size: 1.6rem;
     letter-spacing: 0;
     line-height: 1.4;
   }

   img {
     max-width: 100%;
   }

   .clearfix:after {
     clear: both;
     content: ' ';
     display: table;
   }

   .float-left {
     float: left;
   }

   .float-right {
     float: right;
   }

   /*# sourceMappingURL=milligram.css.map */
"@

}

function Get-NetAdapterDiagnosticReport() {
    <#
        .SYNOPSIS
        System status reporting tool for Solarflare adapters.
        .DESCRIPTION
        Extracts information relating to the Solarflare Net Adapters on the target computer.

        When run (either locally or remotely) the tool generates the report as Powershell objects. An HTML rendering
        will also be output to a file unless the -NoFile option is selected. By default the file name is in the form
        SfReport-COMPUTERNAME-YYYYMMDDHHMMSS.html in the current working directory.

        This command is non-obtrusive and does not affect configuration. It is safe for production environments.

        This command can also be invoked using the alias 'SfReport'.
        .PARAMETER CimSession
        Enter a computer name or a session object, such as the output of a New-CimSession or Get-CimSession cmdlet.
        The default is the current session on the local computer.
        .PARAMETER Sections
        A comma-separated list of sections to include in the report. Wildcards are permitted (e.g. * for all sections).
        Section names are: WinSummary, WinQfe, WinCpu, WinRam,
            WinServices, WinNetworkAdapterConfiguration, WinNetworkProtocol, WinNetworkAdapter,
            WinPciBridgeDevices, WinEventLog, WinTeams, SfPciDevices,
            SfDeviceFiles, SfDeviceFilesProperties, SfInstalledDrivers, SfNetworkInterfaces,
            SfStatistics, SfVersions, SfSensors,
            SfVpd, SfProtocolBindings, NdisTransmitsError, NdisReceiveBlockSize,
            NdisTransmitBlockSize, NdisMaximumFrameSize, NdisTransmitsOk, NdisReceivesOk,
            NdisEnumerateAdapterEx, NdisMediaConnectStatus, NdisMacOptions, NdisLinkState,
            NdisStatistics, StatisticsSummary, NdisHardwareStatus,
            NdisRss, NdisVmq
        .PARAMETER ExcludeSections
        A comma-separated list of sections to exclude from the report. Wildcards are permitted.
        .PARAMETER NoFile
        A switch to disable saving the HTML report to a file.
        .PARAMETER FileName
        The filename (and optional path) of the saved report. If not specified, the filename is constructed using the
        name of the computer on which the command is executed and the date and time.
        .EXAMPLE
        Get-SfNetAdapterDiagnosticReport
        Runs the report on the local computer. The name of the generated report file is output.
        .EXAMPLE
        $session = New-CimSession -ComputerName COMPUTERNAME -Credential DOMAIN\USERNAME
        Get-SfNetAdapterDiagnosticReport -CimSession $session
        Runs the report on the remote computer by passing a CimSession parameter.
        .EXAMPLE
        SfReport | Invoke-Item
        Runs the report using the 'SfReport' alias and displays the saved report in the default browser.
        .EXAMPLE
        SfReport -Sections WinSummary, WinQfe, WinCpu -FileName subset.html
        Runs a subset of the report.
        .EXAMPLE
        SfReport -Sections Win* -ExcludeSections WinEventLog
        Select a subset of the report using a wildcard and a specific exclusion.
        .EXAMPLE
        SfReport -CimSession $session -FileName my_report.html
        Runs the report with a specified name on the remote computer by passing a CimSession parameter.
    #>
    [Alias('Report')]
    [cmdletBinding(PositionalBinding = $false, SupportsShouldProcess = $True, ConfirmImpact = 'None')]
    param(
        [Parameter(ParameterSetName = 'ByName')]
        [Alias('ifAlias InterfaceAlias')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $Name,

        [Parameter(ParameterSetName = 'ByDescription', Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias('ifDesc')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $InterfaceDescription,

        [Parameter(ParameterSetName = 'ByHardwareId', Mandatory = $true)]
        [String[]] $HardwareId,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Alias('Session')]
        [ValidateNotNull()]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(Mandatory=$false)]
        [SupportsWildcards()]
        [String[]] $Sections = @('*'),

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(Mandatory=$false)]
        [SupportsWildcards()]
        [String[]] $ExcludeSections = @(),

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(Mandatory=$false)]
        [Switch] $NoFile,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(Mandatory=$false)]
        [String] $FileName
    )

    begin {
        $overrides = @{}

        [String[]] $allSections = @('WinSummary', 'WinQfe', 'WinCpu', 'WinRam',
            'WinServices', 'WinNetworkAdapterConfiguration', 'WinNetworkProtocol', 'WinNetworkAdapter',
            'WinPciBridgeDevices', 'WinEventLog', 'WinTeams', 'SfPciDevices',
            'SfDeviceFiles', 'SfDeviceFilesProperties', 'SfInstalledDrivers', 'SfNetworkInterfaces',
            'SfStatistics', 'SfVersions', 'SfSensors',
            'SfVpd', 'SfProtocolBindings', 'NdisTransmitsError', 'NdisReceiveBlockSize',
            'NdisTransmitBlockSize', 'NdisMaximumFrameSize', 'NdisTransmitsOk', 'NdisReceivesOk',
            'NdisEnumerateAdapterEx', 'NdisMediaConnectStatus', 'NdisMacOptions', 'NdisLinkState',
            'NdisStatistics', 'StatisticsSummary', 'NdisHardwareStatus',
            'NdisRss', 'NdisVmq' )

        if (-not $PSBoundParameters.ContainsKey('InformationAction')) {
            $overrides['InformationAction'] = 'Continue'
        }

        Write-Information 'Solarflare report utility' @overrides
        if ($MyInvocation.MyCommand.Module) {
            Write-Information $MyInvocation.MyCommand.Module.Copyright @overrides
            $version = $MyInvocation.MyCommand.Module.PrivateData.ModuleSemanticVersion
            Write-Verbose "SolarflareTools $version" @overrides
        }

        $baseParams = @{}
        if ($PSBoundParameters.ContainsKey('CimSession')) {
            $baseParams['CimSession'] = $PSBoundParameters['CimSession']
        }
    }

    process {
        $selectedSet = New-Object System.Collections.Generic.HashSet[String]
        if ($PSBoundParameters.ContainsKey('Name')) {
            foreach ($interface in (Get-NetAdapter @baseParams -Name $Name -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('InterfaceDescription')) {
            foreach ($interface in (Get-NetAdapter @baseParams -InterfaceDescription $InterfaceDescription `
                    -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('HardwareId')) {
            $SolarflareAdapters = Get-SfDeviceInventoryInfo @baseParams -HardwareId $HardwareId
            if (!$SolarflareAdapters) {
                # No Adapters Found
                Write-Error "No Solarflare adapter(s) found with HardwareId:$HardwareId"
                return $Adapters
            }
            foreach($interface in $SolarflareAdapters) {
                $selectedSet.Add($interface.FriendlyName) | Out-Null
            }
        }
        else {
            foreach ($interface in (Get-NetAdapter @baseParams -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }

        $invocationName = $MyInvocation.InvocationName.ToLower()

        # Produce list of matched sections
        $matchedSections = @()
        foreach ($section in $allSections) {
            foreach ($include in $Sections) {
                if ($section -like $include) {
                    foreach ($exclude in $ExcludeSections) {
                        if ($section -like $exclude)
                        {
                            $section = $null
                            break
                        }
                    }
                    if ($section) {
                        $matchedSections += $section
                    }
                    break
                }
            }
        }
        $sut = [sfreport]::new($baseParams, $selectedSet, $matchedSections, $invocationName)
        $report = $sut.GetSfReportHtml()
        $reportInfo = [PSCustomObject]@{
            PSTypeName = 'Solarflare.Report'
            InterfaceDescription = $selectedSet
            Data = $report.Data
            Path = $null
        }

        $saveToFile = $true
        if($PSBoundParameters.ContainsKey('FileName')) {
            $fileName = $PSBoundParameters['FileName']
        }
        if($PSBoundParameters.ContainsKey('NoFile')) {
            $saveToFile = $false
        }
        if($saveToFile) {
            if($fileName) {
                $outputFileName = $fileName
            } else {
                if ($PSBoundParameters.ContainsKey('CimSession')) {
                    $computerName = $PSBoundParameters['CimSession'].ComputerName
                } else {
                    $computerName = $env:computername
                }
                $date = Get-Date -Format "yyyyMMddHHmmss"
                $outputFileName = "SfReport_$($computerName)_$($date).html"
            }
            $report.Html | Out-File -FilePath $outputFileName
            $fullName = (Get-ChildItem $outputFileName | Select-Object FullName).FullName
            $reportInfo.Path = $fullName
            Write-Information "Report saved to $fullName" @overrides
        }

        $reportInfo
    }

    end {
    }
}

# SIG # Begin signature block
# MIIefQYJKoZIhvcNAQcCoIIebjCCHmoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCCj+JZsT5Y8ElAK
# YLCUuPI2wqoeiMc4n1rDf9a/gB4zNKCCGY0wggWKMIIEcqADAgECAhAL9isXqX/2
# 8aS6px6yF9fnMA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNV
# BAMTIkRpZ2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwHhcNMjAwOTA0
# MDAwMDAwWhcNMjMwODMxMTIwMDAwWjCBqDETMBEGCysGAQQBgjc8AgEDEwJHQjEd
# MBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xETAPBgNVBAUTCDA0NDQxMzg2
# MQswCQYDVQQGEwJHQjESMBAGA1UEBxMJQ2FtYnJpZGdlMR4wHAYDVQQKExVYaWxp
# bnggVGVjaG5vbG9neSBMdGQxHjAcBgNVBAMTFVhpbGlueCBUZWNobm9sb2d5IEx0
# ZDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALpCrVaJ0WUXy0vh2eDQ
# PbK2vwC51KJMF0vEbwtj501kbujnHRbd03C9K6kFw7crzLI1KI7sKqPep5bLjQfP
# mG3rdY1dS8d40yXQJLTiQWtlSkGSW2UIlhJdN9ASlwMPIqjbLrZlBbKsalyc/8Ry
# 9CayLQM1dJECX7MgRxz15fr04X4FbC2baJdrg6hgbJ9IDDuU5l7XVYXp1GkZFCPD
# S+92WMPTpb7LFFb+4KPULlF0Vmf3fJ6ZL8geqdCrVpADekGgj/EopsrIBvVy3Anr
# y5PgvVWl+GyYn+Xr9i3HxDkqrsJ9fZOuCWI1M8yyQE7trqPRCt+9bUwbpUSA7hES
# sWkCAwEAAaOCAekwggHlMB8GA1UdIwQYMBaAFI/ofvBtMmoABSPHcJdqOpD/a+rU
# MB0GA1UdDgQWBBQbN9po8ibTH5kEwgmurjm1ryenPTAmBgNVHREEHzAdoBsGCCsG
# AQUFBwgDoA8wDQwLR0ItMDQ0NDEzODYwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQM
# MAoGCCsGAQUFBwMDMHsGA1UdHwR0MHIwN6A1oDOGMWh0dHA6Ly9jcmwzLmRpZ2lj
# ZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwN6A1oDOGMWh0dHA6Ly9j
# cmw0LmRpZ2ljZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwSwYDVR0g
# BEQwQjA3BglghkgBhv1sAwIwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGln
# aWNlcnQuY29tL0NQUzAHBgVngQwBAzB+BggrBgEFBQcBAQRyMHAwJAYIKwYBBQUH
# MAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBIBggrBgEFBQcwAoY8aHR0cDov
# L2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0RVZDb2RlU2lnbmluZ0NBLVNI
# QTIuY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggEBAJGCCl1voKTA
# ml2M6QyubvxhbjOHzau7EL8YEHQgkBfarH0zrtOFXypqwELz219z9wdjUQ4czWEg
# MWCAusWIQpA47qFsrcFSjmvoa+AMYzCEMbkwXGGjquRTD/s61Zy6jh5ayPzxyj2+
# Ql61mIvDYiXhWv5BZuq/mS8YZGNXM1GwIDZK05gDup+NvIVVCoUa9A61KAJeXOyq
# d6yquSSaqW1HqD4Yg29YdxdF+nySo7cuI9LnefYofsNZ4PJJC2W7OtNgr770RTPz
# QrhJHRpJwfm5w2aUV0sO8KciQ+JySwKqZoO+WqxJ9q9JjUl/WY7qsFe3EcY+9vdK
# +dlK+QD24gowggZqMIIFUqADAgECAhADAZoCOv9YsWvW1ermF/BmMA0GCSqGSIb3
# DQEBBQUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgQ0EtMTAeFw0xNDEwMjIwMDAwMDBaFw0yNDEwMjIwMDAwMDBaMEcxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDElMCMGA1UEAxMcRGlnaUNlcnQg
# VGltZXN0YW1wIFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAKNkXfx8s+CCNeDg9sYq5kl1O8xu4FOpnx9kWeZ8a39rjJ1V+JLjntVaY1sC
# SVDZg85vZu7dy4XpX6X51Id0iEQ7Gcnl9ZGfxhQ5rCTqqEsskYnMXij0ZLZQt/US
# s3OWCmejvmGfrvP9Enh1DqZbFP1FI46GRFV9GIYFjFWHeUhG98oOjafeTl/iqLYt
# WQJhiGFyGGi5uHzu5uc0LzF3gTAfuzYBje8n4/ea8EwxZI3j6/oZh6h+z+yMDDZb
# esF6uHjHyQYuRhDIjegEYNu8c3T6Ttj+qkDxss5wRoPp2kChWTrZFQlXmVYwk/PJ
# YczQCMxr7GJCkawCwO+k8IkRj3cCAwEAAaOCAzUwggMxMA4GA1UdDwEB/wQEAwIH
# gDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIIBvwYDVR0g
# BIIBtjCCAbIwggGhBglghkgBhv1sBwEwggGSMCgGCCsGAQUFBwIBFhxodHRwczov
# L3d3dy5kaWdpY2VydC5jb20vQ1BTMIIBZAYIKwYBBQUHAgIwggFWHoIBUgBBAG4A
# eQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkAYwBhAHQA
# ZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBjAGUA
# IABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMAUABTACAA
# YQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkAIABBAGcA
# cgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBhAGIA
# aQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBhAHQA
# ZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMAZQAuMAsG
# CWCGSAGG/WwDFTAfBgNVHSMEGDAWgBQVABIrE5iymQftHt+ivlcNK2cCzTAdBgNV
# HQ4EFgQUYVpNJLZJMp1KKnkag0v0HonByn0wfQYDVR0fBHYwdDA4oDagNIYyaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0EtMS5jcmww
# OKA2oDSGMmh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RENBLTEuY3JsMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0xLmNydDANBgkqhkiG9w0BAQUF
# AAOCAQEAnSV+GzNNsiaBXJuGziMgD4CH5Yj//7HUaiwx7ToXGXEXzakbvFoWOQCd
# 42yE5FpA+94GAYw3+puxnSR+/iCkV61bt5qwYCbqaVchXTQvH3Gwg5QZBWs1kBCg
# e5fH9j/n4hFBpr1i2fAnPTgdKG86Ugnw7HBi02JLsOBzppLA044x2C/jbRcTBu7k
# A7YUq/OPQ6dxnSHdFMoVXZJB2vkPgdGZdA0mxA5/G7X1oPHGdwYoFenYk+VVFvC7
# Cqsc21xIJ2bIo4sKHOWV2q7ELlmgYd3a822iYemKC23sEhi991VUQAOSK2vCUcIK
# SK+w1G7g9BQKOhvjjz3Kr2qNe9zYRDCCBrwwggWkoAMCAQICEAPxtOFfOoLxFJZ4
# s9fYR1wwDQYJKoZIhvcNAQELBQAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMi
# RGlnaUNlcnQgSGlnaCBBc3N1cmFuY2UgRVYgUm9vdCBDQTAeFw0xMjA0MTgxMjAw
# MDBaFw0yNzA0MTgxMjAwMDBaMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdp
# Q2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNVBAMTIkRp
# Z2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCnU/oPsrUT8WTPhID8roA10bbXx6MsrBosrPGErDo1
# EjqSkbpX5MTJ8y+oSDy31m7clyK6UXlhr0MvDbebtEkxrkRYPqShlqeHTyN+w2xl
# JJBVPqHKI3zFQunEemJFm33eY3TLnmMl+ISamq1FT659H8gTy3WbyeHhivgLDJj0
# yj7QRap6HqVYkzY0visuKzFYZrQyEJ+d8FKh7+g+03byQFrc+mo9G0utdrCMXO42
# uoPqMKhM3vELKlhBiK4AiasD0RaCICJ2615UOBJi4dJwJNvtH3DSZAmALeK2nc4f
# 8rsh82zb2LMZe4pQn+/sNgpcmrdK0wigOXn93b89OgklAgMBAAGjggNYMIIDVDAS
# BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggr
# BgEFBQcDAzB/BggrBgEFBQcBAQRzMHEwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBJBggrBgEFBQcwAoY9aHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0SGlnaEFzc3VyYW5jZUVWUm9vdENBLmNydDCBjwYDVR0f
# BIGHMIGEMECgPqA8hjpodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRI
# aWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMECgPqA8hjpodHRwOi8vY3JsNC5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMIIBxAYD
# VR0gBIIBuzCCAbcwggGzBglghkgBhv1sAwIwggGkMDoGCCsGAQUFBwIBFi5odHRw
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9zc2wtY3BzLXJlcG9zaXRvcnkuaHRtMIIBZAYI
# KwYBBQUHAgIwggFWHoIBUgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAg
# AEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAg
# AGEAYwBjAGUAcAB0AGEAbgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBl
# AHIAdAAgAEMAUAAvAEMAUABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBu
# AGcAIABQAGEAcgB0AHkAIABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAg
# AGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAg
# AGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIABy
# AGUAZgBlAHIAZQBuAGMAZQAuMB0GA1UdDgQWBBSP6H7wbTJqAAUjx3CXajqQ/2vq
# 1DAfBgNVHSMEGDAWgBSxPsNpA/i/RwHUmCYaCALvY2QrwzANBgkqhkiG9w0BAQsF
# AAOCAQEAGTNKDIEzN9utNsnkyTq7tRsueqLi9ENCF56/TqFN4bHb6YHdnwHy5IjV
# 6f4J/SHB7F2A0vDWwUPC/ncr2/nXkTPObNWyGTvmLtbJk0+IQI7N4fV+8Q/GWVZy
# 6OtqQb0c1UbVfEnKZjgVwb/gkXB3h9zJjTHJDCmiM+2N4ofNiY0/G//V4BqXi3za
# bfuoxrI6Zmt7AbPN2KY07BIBq5VYpcRTV6hg5ucCEqC5I2SiTbt8gSVkIb7P7kIY
# Q5e7pTcGr03/JqVNYUvsRkG4Zc64eZ4IlguBjIo7j8eZjKMqbphtXmHGlreKuWEt
# k7jrDgRD1/X+pvBi1JlqpcHB8GSUgDCCBs0wggW1oAMCAQICEAb9+QOWA63qAArr
# Pye7uhswDQYJKoZIhvcNAQEFBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMb
# RGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4XDTA2MTExMDAwMDAwMFoXDTIx
# MTExMDAwMDAwMFowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IElu
# YzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQg
# QXNzdXJlZCBJRCBDQS0xMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
# 6IItmfnKwkKVpYBzQHDSnlZUXKnE0kEGj8kz/E1FkVyBn+0snPgWWd+etSQVwpi5
# tHdJ3InECtqvy15r7a2wcTHrzzpADEZNk+yLejYIA6sMNP4YSYL+x8cxSIB8HqIP
# kg5QycaH6zY/2DDD/6b3+6LNb3Mj/qxWBZDwMiEWicZwiPkFl32jx0PdAug7Pe2x
# QaPtP77blUjE7h6z8rwMK5nQxl0SQoHhg26Ccz8mSxSQrllmCsSNvtLOBq6thG9I
# hJtPQLnxTPKvmPv2zkBdXPao8S+v7Iki8msYZbHBc63X8djPHgp0XEK4aH631XcK
# J1Z8D2KkPzIUYJX9BwSiCQIDAQABo4IDejCCA3YwDgYDVR0PAQH/BAQDAgGGMDsG
# A1UdJQQ0MDIGCCsGAQUFBwMBBggrBgEFBQcDAgYIKwYBBQUHAwMGCCsGAQUFBwME
# BggrBgEFBQcDCDCCAdIGA1UdIASCAckwggHFMIIBtAYKYIZIAYb9bAABBDCCAaQw
# OgYIKwYBBQUHAgEWLmh0dHA6Ly93d3cuZGlnaWNlcnQuY29tL3NzbC1jcHMtcmVw
# b3NpdG9yeS5odG0wggFkBggrBgEFBQcCAjCCAVYeggFSAEEAbgB5ACAAdQBzAGUA
# IABvAGYAIAB0AGgAaQBzACAAQwBlAHIAdABpAGYAaQBjAGEAdABlACAAYwBvAG4A
# cwB0AGkAdAB1AHQAZQBzACAAYQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8AZgAgAHQA
# aABlACAARABpAGcAaQBDAGUAcgB0ACAAQwBQAC8AQwBQAFMAIABhAG4AZAAgAHQA
# aABlACAAUgBlAGwAeQBpAG4AZwAgAFAAYQByAHQAeQAgAEEAZwByAGUAZQBtAGUA
# bgB0ACAAdwBoAGkAYwBoACAAbABpAG0AaQB0ACAAbABpAGEAYgBpAGwAaQB0AHkA
# IABhAG4AZAAgAGEAcgBlACAAaQBuAGMAbwByAHAAbwByAGEAdABlAGQAIABoAGUA
# cgBlAGkAbgAgAGIAeQAgAHIAZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZIAYb9bAMV
# MBIGA1UdEwEB/wQIMAYBAf8CAQAweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzAB
# hhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9j
# YWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQw
# gYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdp
# Q2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwHQYDVR0OBBYEFBUA
# EisTmLKZB+0e36K+Vw0rZwLNMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3z
# bcgPMA0GCSqGSIb3DQEBBQUAA4IBAQBGUD7Jtygkpzgdtlspr1LPUukxR6tWXHvV
# DQtBs+/sdR90OPKyXGGinJXDUOSCuSPRujqGcq04eKx1XRcXNHJHhZRW0eu7NoR3
# zCSl8wQZVann4+erYs37iy2QwsDStZS9Xk+xBdIOPRqpFFumhjFiqKgz5Js5p8T1
# zh14dpQlc+Qqq8+cdkvtX8JLFuRLcEwAiR78xXm8TBJX/l/hHrwCXaj++wc4Tw3G
# XZG5D2dFzdaD7eeSDY2xaYxP+1ngIw/Sqq4AfO6cQg7PkdcntxbuD8O9fAqg7iwI
# VYUiuOsYGk38KiGtSTGDR5V3cdyxG0tLHBCcdxTBnU8vWpUIKRAmMYIERjCCBEIC
# AQEwgYAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMiRGlnaUNlcnQgRVYgQ29k
# ZSBTaWduaW5nIENBIChTSEEyKQIQC/YrF6l/9vGkuqceshfX5zANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCB1pu6wHHMwXRKRbDIdedSnJROt5pUKQ38gYfY0slMmjDANBgkq
# hkiG9w0BAQEFAASCAQAndr/VTecsFMjqme2Y4FLrtMnaIKHWi408ho4iobHjMm7g
# YthTjqw4oMfCCz/8R3mEqtBcSbGKbttOt7kof7vAwRjtBSL+MZeC1zMpH8KjaigP
# wiSURIvGn3agos18mlrPoDxBYypbINMy/gJuiYS1IPS26mDf0FjeMJ564TE0d6IL
# mrtnGRA9hRXvGHbXjmuRFyNmDY62oPfJaxUbNGxXzEc0msaactAAKZkfNuw37WZN
# 1PEQsiktPON/7Lf9pB8tAMwxtU/xdtBQw3WI2iBfy7fRQ6Fbk5FjJoHxeCVOWeWF
# 0ECuqbSmKZAmP8Y1wyheiq7g43kvPiQUtRxpqpTSoYICDzCCAgsGCSqGSIb3DQEJ
# BjGCAfwwggH4AgEBMHYwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0
# IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNl
# cnQgQXNzdXJlZCBJRCBDQS0xAhADAZoCOv9YsWvW1ermF/BmMAkGBSsOAwIaBQCg
# XTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0yMDEw
# MTkxMDMxMjhaMCMGCSqGSIb3DQEJBDEWBBTtJ89vA38t12YNzQ+1Yg0aYXRfPDAN
# BgkqhkiG9w0BAQEFAASCAQAXfz5cjr6VJXsn0qwnzyZsoPkKqwNvzhPq13Ryuw6J
# SoojF3jh/MLso6M8OwHaR4+NZQOphPLg9RFbdgn+dTBsJpdEdYW4nMiQYFXcp69D
# aCnr3M4Yf9o6MztD8C+X3N5P7KhPSCgMxa2Kh/2xoCc/iSphO88bN4LMFC8PaZ7L
# 5dslcWMvHH/bdgym3R+Xfgnt6UB22E9lJxSUCAPWR7heDqSv9xnAJQb6OJH7Q/vy
# hPLEQCUOSSDK201ywbCKeAZsW5QHNJZrTtOviPRT5SAyN2VbA2Mh41MeNbpwKBKU
# li/UKt2GzR3P5kD/3z2QpW7ENrQVBfeTnEIcPKreuNbA
# SIG # End signature block
