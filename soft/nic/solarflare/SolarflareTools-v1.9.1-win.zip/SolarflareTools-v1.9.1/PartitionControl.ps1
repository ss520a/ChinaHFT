<#
    Copyright (c) 2020 Xilinx, Inc. All rights reserved.
    Copyright (c) 2018-2019 Solarflare Communications Inc.
    Use is subject to license terms.
#>

<#
.SYNOPSIS
    PartitionControl
.DESCRIPTION
    Base class for Solarflare powershell utilities using NVRAM
#>

#Requires -Version 5.1
#Requires -Modules CimCmdlets

class PartitionControl : Common {

    static [UInt32]$maxWriteChunkSize = '0x1000'
    static [UInt32]$errorFail = '0xC0000001'

    PartitionControl([Hashtable] $BaseParams)
    : base ($BaseParams) {
    }

    [void] ResetSfAdapters() {
        $baseParams = $this.baseParams
        Get-NetAdapter @baseParams -InterfaceDescription 'Solarflare*' | Restart-NetAdapter
    }

    [CimInstance[]] GetPartitionViewInfoList() {
        $baseParams = $this.baseParams
        return CimCmdlets\Get-CimInstance @baseParams -Namespace root\wmi -ClassName Solarflare_PartitionViewInfoList
    }

    [CimInstance] GetPartitionControl([String] $InstanceName) {
        $baseParams = $this.baseParams
        $instances = CimCmdlets\Get-CimInstance @baseParams -Namespace root\wmi -ClassName Solarflare_PartitionControl
        $instance = $instances | Where-Object { $_.InstanceName -eq $InstanceName } | Select-Object -First 1
        return $instance
    }

    [Int64] OpenView([CimInstance] $Instance, [Int] $Type, [Int] $SubType, [Int] $View, [Int] $AccessMode,
        [String] $Path) {
        $session = CimCmdlets\Invoke-CimMethod -InputObject $Instance `
                    -MethodName Solarflare_PartitionControl_OpenView `
                    -Arguments @{
                        Type = $Type;
                        SubType = $SubType;
                        View = $View;
                        AccessMode = $AccessMode;
                        Path = $Path } -Confirm:$false -WhatIf:$false
        if ($session.Result -eq 0) {
            return $session.SessionId
        }
        else {
            return $null
        }
    }

    [UInt32] GetViewSize([CimInstance] $Instance, [Int64] $SessionId) {
        $status = CimCmdlets\Invoke-CimMethod -InputObject $Instance `
                    -MethodName Solarflare_PartitionControl_GetStatus `
                    -Arguments @{ SessionId = $SessionId } -Confirm:$false -WhatIf:$false
        if ($status.Result -ne 0) { throw 'Error occurred in GetStatus' }
        return $status.CurrentSize
    }

    [UInt32] ClearView([CimInstance] $Instance, [Int64] $SessionId) {
        $clear = CimCmdlets\Invoke-CimMethod -InputObject $Instance `
                    -MethodName Solarflare_PartitionControl_ClearView `
                    -Arguments @{ SessionId = $SessionId } -Confirm:$false -WhatIf:$false
        return $clear.Result
    }

    [UInt32[]] ReadViewUInt32s([CimInstance] $Instance, [Int64] $SessionId, [Int] $Offset, [Int] $Length) {
        $read = CimCmdlets\Invoke-CimMethod -InputObject $Instance `
                    -MethodName Solarflare_PartitionControl_ReadView `
                    -Arguments @{ SessionId = $SessionId; Offset = $Offset; Length = $Length } `
                    -Confirm:$false -WhatIf:$false
        [Byte[]] $data = $read.Data
        $dword_array = [System.UInt32[]]::new([Math]::Floor($data.Length / 4))
        $j = 0
        for ($i = 0; ($i + 4) -le $data.Length; $i += 4) {
            $bytes = [Byte[]]($data[$i], $data[$i + 1], $data[$i + 2], $data[$i + 3])
            $dword = [BitConverter]::ToUInt32($bytes, 0)
            $dword_array[$j++] = $dword
        }
        return $dword_array
    }

    [Hashtable] ReadTLV([UInt32[]] $View) {
        if ($null -eq $View) {
            return $null
        }
        $dict = @{}
        $endmarker = [UInt32]'0xEEEEEEEE'
        $ix = 0
        while ($true) {
            $tag = $View[$ix]
            if ($tag -eq $endmarker) { break; }
            $length = [Int]([Math]::Ceiling($View[$ix + 1] / 4))
            $datastart = ($ix + 2)
            $dataend = ($ix + 2 + $length - 1)
            $data = $View[$datastart..$dataend]
            $dict.Add($tag, $data)
            $ix = $dataend + 1
        }
        return $dict
    }

    [UInt32[]] UpdateTLV([UInt32[]] $View, [UInt32] $Tagg, [UInt32[]] $Value) {
        $endmarker = [UInt32]'0xEEEEEEEE'
        $ix = 0
        while ($true) {
            $tag = $View[$ix]
            if ($tag -eq $endmarker) { break }

            $length = [Int]([Math]::Ceiling($View[$ix + 1] / 4))
            $datastart = ($ix + 2)
            $dataend = ($ix + 2 + $length - 1)
            if ($tag -eq $Tagg) {
                $View = $View[0..($datastart - 1)] + $Value + $View[($dataend + 1)..($View.Length - 1)]
                return $View
            }
            $ix = $dataend + 1
        }

        # Replace the end marker with key followed by end marker
        [UInt32[]] $newtag = ($Tagg, [UInt32]($Value.Length * 4)) + $Value
        if ($ix -le 1) {
            return $newtag + @($endmarker)
        }
        else {
            return $View[0..($ix - 1)] + $newtag + @($endmarker)
        }
    }

    [UInt32[]] UpdateTLVBytes([UInt32[]] $View, [UInt32] $Tagg, [byte[]] $Value) {

        # Convert Value to a UInt32 array with padding
        $length = [Int]([Math]::Ceiling($Value.Length / 4))
        $dword_array = [System.UInt32[]]::new($length)
        for ($ix = 0; $ix -lt $length; $ix++) {
            $val_ix = ($ix * 4)
            $bytes_left = $Value.Length - $val_ix
            [UInt32]$val = 0
            if ($bytes_left -ge 4) {
                $val = [UInt32]$Value[$val_ix] -bor
                   ([UInt32]$Value[$val_ix + 1] -shl 8) -bor
                   ([UInt32]$Value[$val_ix + 2] -shl 16) -bor
                   ([UInt32]$Value[$val_ix + 3] -shl 24)
            } else {
                $byte_ix = 0
                while ($bytes_left -gt 0) {
                    $val = $val -bor ([UInt32]$Value[$val_ix + $byte_ix] -shl ($byte_ix * 8))
                    $byte_ix++
                    $bytes_left--
                }
                while ($byte_ix -lt 4) {
                    $val = $val -bor ([UInt32]'0x000000FF' -shl ($byte_ix * 8))
                    $byte_ix++
                }
            }
            $dword_array[$ix] = $val
        }

        $endmarker = [UInt32]'0xEEEEEEEE'
        $ix = 0
        while ($true) {
            $tag = $View[$ix]
            if ($tag -eq $endmarker) { break }

            $length = [Int]([Math]::Ceiling($View[$ix + 1] / 4))
            $datastart = ($ix + 2)
            $dataend = ($ix + 2 + $length - 1)
            if ($tag -eq $Tagg) {
                # In-place replacement
                if ($dword_array.Length -eq $length) {
                    $View = $View[0..($datastart - 1)] + $dword_array + $View[($dataend + 1)..($View.Length - 1)]
                    return $View
                } else {
                    # Remove and replace below
                    $View = $View[0..($ix - 1)] + $View[($dataend + 1)..($View.Length - 1)]
                    break
                }
            }
            $ix = $dataend + 1
        }

        # Replace the end marker with key followed by end marker
        [UInt32[]] $newtag = ($Tagg, [UInt32]($Value.Length)) + $dword_array
        if ($ix -le 1) {
            return $newtag + @($endmarker)
        }
        else {
            return $View[0..($ix - 1)] + $newtag + @($endmarker)
        }
    }

    [UInt32[]] RemoveTLV([UInt32[]] $View, [UInt32] $Tagg) {
        $endmarker = [UInt32]'0xEEEEEEEE'
        $ix = 0
        while ($true) {
            $tag = $View[$ix]
            if ($tag -eq $endmarker) { break }

            $length = [Int]([Math]::Ceiling($View[$ix + 1] / 4))
            $next = ($ix + 2 + $length)
            if ($tag -eq $Tagg) {
                if ($ix -le 1) {
                    $View = $View[$next..($View.Length - 1)]
                }
                else {
                    $View = $View[0..($ix - 1)] + $View[$next..($View.Length - 1)]
                }
                return $View
            }
            $ix = $next
        }
        return $View
    }

    [UInt32] WriteView([CimInstance] $Instance, [Int64] $SessionId, [Byte[]] $Bytes) {
        $dataLength = $Bytes.Length
        $offset = 0
        $dataRemaining = $dataLength
        $result = [PartitionControl]::errorFail
        while ($offset -lt $dataLength) {
            if ($dataRemaining -gt [PartitionControl]::maxWriteChunkSize) {
                $chunkSize = [PartitionControl]::maxWriteChunkSize
            }
            else {
                $chunkSize = $dataRemaining
            }
            $write = CimCmdlets\Invoke-CimMethod -InputObject $Instance `
                        -MethodName Solarflare_PartitionControl_WriteView `
                        -Arguments @{
                            SessionId = $SessionId;
                            Offset = $offset;
                            DataLength = $chunkSize;
                            Data = $Bytes[$offset..($offset + $chunkSize - 1)]
                        } -Confirm:$false -WhatIf:$false
            $result = $write.Result
            if ($result -ne 0) { break }
            $dataRemaining -= $chunkSize
            $offset += $chunkSize
        }
        return $result
    }

    [UInt32] WriteViewUInt32s([CimInstance] $Instance, [Int64] $SessionId, [UInt32[]] $Words) {
        $dataLength = $Words.Length * 4
        $bytes = [System.Byte[]]::new($dataLength)
        $offset = 0
        for ($i = 0; $i -lt $Words.Length; $i += 1 ) {
            $word_as_bytes = [bitconverter]::GetBytes($Words[$i])
            for ($j = 0; $j -lt $word_as_bytes.Length; $j += 1) {
                $bytes[$offset + $j] = $word_as_bytes[$j]
            }
            $offset += $word_as_bytes.Length
        }

        $offset = 0
        $dataRemaining = $dataLength
        $result = [PartitionControl]::errorFail
        while ($offset -lt $dataLength) {
            if ($dataRemaining -gt [PartitionControl]::maxWriteChunkSize) {
                $chunkSize = [PartitionControl]::maxWriteChunkSize
            }
            else {
                $chunkSize = $dataRemaining
            }
            $write = CimCmdlets\Invoke-CimMethod -InputObject $Instance `
                        -MethodName Solarflare_PartitionControl_WriteView `
                        -Arguments @{
                            SessionId = $SessionId;
                            Offset = $offset;
                            DataLength = $chunkSize;
                            Data = $bytes[$offset..($offset + $chunkSize - 1)]
                        } -Confirm:$false -WhatIf:$false
            $result = $write.Result
            if ($result -ne 0) { break }
            $dataRemaining -= $chunkSize
            $offset += $chunkSize
        }
        return $result
    }

    hidden [UInt32] CommitView([CimInstance] $Instance, [Int64] $SessionId, [Int] $UpdateMode) {
        $commit = CimCmdlets\Invoke-CimMethod -InputObject $Instance `
                    -MethodName Solarflare_PartitionControl_CommitView `
                    -Arguments @{
                        SessionId = $SessionId;
                        UpdateMode = $UpdateMode
                    } -Confirm:$false -WhatIf:$false
        return $commit.Result
    }

    hidden [Hashtable] GetStatus([CimInstance] $Instance, [Int64] $SessionId) {
        $status = CimCmdlets\Invoke-CimMethod -InputObject $Instance `
                    -MethodName Solarflare_PartitionControl_GetStatus `
                    -Arguments @{
                        SessionId = $SessionId;
                    } -Confirm:$false -WhatIf:$false
        if ($status.Result -eq 0) {
            return @{
                InstanceName = $Instance.InstanceName
                OperationProgress = $status.OperationProgress;
                OperationResult = $status.OperationResult;
                ActionsRequired = $status.ActionsRequired;
            }
        } else {
            return @{}
        }
    }

    hidden [UInt32] CloseView([CimInstance] $Instance, [Int64] $SessionId) {
        $close = CimCmdlets\Invoke-CimMethod -InputObject $Instance `
                    -MethodName Solarflare_PartitionControl_CloseView `
                    -Arguments @{ SessionId = $SessionId } -Confirm:$false -WhatIf:$false
        return $close.Result
    }

    hidden [Partition[]] FilterPartitionsByName([CimInstance[]] $Instances, [String] $ViewName,
        [System.Collections.Generic.HashSet[String]] $InstanceNameSet) {
        $arr = @()
        foreach ($instance in $Instances) {

            $instanceName = $instance.InstanceName
            if ($instanceNameSet -and (!$InstanceNameSet.Contains($instanceName))) { continue }

            foreach ($viewinfo in $instance.PartitionViewInfo) {

                $name = $viewInfo.Name

                if ($ViewName -and ($name -ne $ViewName)) { continue }

                $view = $viewInfo.View
                $versionValid = $viewInfo.VersionValid
                $type = $viewInfo.Type
                $subType = $viewInfo.SubType
                $version = $viewInfo.Version
                $currentVersion = "$($version.Major).$($version.Minor).$($version.Patch).$($version.Build)"

                $arr += [Partition]::new($instanceName,
                    $type, $subType, $view,
                    $versionValid, $currentVersion,
                    $name)
            }
        }
        return $arr
    }

    [CimInstance] GetMcdi([String] $InstanceName)
    {
        $baseParams = $this.baseParams
        $instances = CimCmdlets\Get-CimInstance @baseParams -Namespace root\wmi -ClassName Solarflare_Mcdi
        $instance = $instances | Where-Object { $_.InstanceName -eq $InstanceName } | Select-Object -First 1
        return $instance
    }

    hidden [void] McdiReboot([String] $InstanceName)
    {
        $instance = $this.GetMcdi($InstanceName)
        CimCmdlets\Invoke-CimMethod -InputObject $instance -MethodName Solarflare_Mcdi_Reboot -Confirm:$false

        # Add wait for device to re-enumerate
        $resumed = $false
        for ($count = 0; $count -lt 10; $count++) {
            $instance = $this.GetMcdi($InstanceName)
            if ($null -ne $instance) {
                $status = CimCmdlets\Invoke-CimMethod -InputObject $instance -MethodName Solarflare_Mcdi_GetStatus `
                            -Confirm:$false -ErrorAction:SilentlyContinue
                if (($status.StatusFlags -band 0x1) -ne -0) {
                    # MCDI is alive
                    $resumed = $true
                    break
                }
            }
            Write-Information "Waiting for restart on: $InstanceName ..."
            Start-Sleep 1
        }
        if (!$resumed) {
            Write-Warning "Timeout on adapter $InstanceName restart."
        }
    }

    hidden [void] DeviceRestart([String] $InstanceName)
    {
        $baseParams = $this.baseParams
        Get-NetAdapter @baseParams -InterfaceDescription $InstanceName | Restart-NetAdapter
    }

}

class Partition {
    [String] $InstanceName
    [Int] $Type
    [Int] $SubType
    [Int] $View
    [Bool] $VersionValid
    [Version] $CurrentVersion
    [String] $Name

    Partition([String] $InstanceName, [Int] $Type, [Int] $SubType, [Int] $View, [Bool] $VersionValid,
                [Version] $CurrentVersion, [String] $Name) {
        $this.InstanceName = $InstanceName
        $this.Type = $Type
        $this.SubType = $SubType
        $this.View = $View
        $this.VersionValid = $VersionValid
        $this.CurrentVersion = $CurrentVersion
        $this.Name = $Name
    }
}

# SIG # Begin signature block
# MIIefQYJKoZIhvcNAQcCoIIebjCCHmoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB5wPNv5mTcGF/p
# X5dLUkoZICFHhHIMx6ppkZ4tckLzEqCCGY0wggWKMIIEcqADAgECAhAL9isXqX/2
# 8aS6px6yF9fnMA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNV
# BAMTIkRpZ2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwHhcNMjAwOTA0
# MDAwMDAwWhcNMjMwODMxMTIwMDAwWjCBqDETMBEGCysGAQQBgjc8AgEDEwJHQjEd
# MBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xETAPBgNVBAUTCDA0NDQxMzg2
# MQswCQYDVQQGEwJHQjESMBAGA1UEBxMJQ2FtYnJpZGdlMR4wHAYDVQQKExVYaWxp
# bnggVGVjaG5vbG9neSBMdGQxHjAcBgNVBAMTFVhpbGlueCBUZWNobm9sb2d5IEx0
# ZDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALpCrVaJ0WUXy0vh2eDQ
# PbK2vwC51KJMF0vEbwtj501kbujnHRbd03C9K6kFw7crzLI1KI7sKqPep5bLjQfP
# mG3rdY1dS8d40yXQJLTiQWtlSkGSW2UIlhJdN9ASlwMPIqjbLrZlBbKsalyc/8Ry
# 9CayLQM1dJECX7MgRxz15fr04X4FbC2baJdrg6hgbJ9IDDuU5l7XVYXp1GkZFCPD
# S+92WMPTpb7LFFb+4KPULlF0Vmf3fJ6ZL8geqdCrVpADekGgj/EopsrIBvVy3Anr
# y5PgvVWl+GyYn+Xr9i3HxDkqrsJ9fZOuCWI1M8yyQE7trqPRCt+9bUwbpUSA7hES
# sWkCAwEAAaOCAekwggHlMB8GA1UdIwQYMBaAFI/ofvBtMmoABSPHcJdqOpD/a+rU
# MB0GA1UdDgQWBBQbN9po8ibTH5kEwgmurjm1ryenPTAmBgNVHREEHzAdoBsGCCsG
# AQUFBwgDoA8wDQwLR0ItMDQ0NDEzODYwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQM
# MAoGCCsGAQUFBwMDMHsGA1UdHwR0MHIwN6A1oDOGMWh0dHA6Ly9jcmwzLmRpZ2lj
# ZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwN6A1oDOGMWh0dHA6Ly9j
# cmw0LmRpZ2ljZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwSwYDVR0g
# BEQwQjA3BglghkgBhv1sAwIwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGln
# aWNlcnQuY29tL0NQUzAHBgVngQwBAzB+BggrBgEFBQcBAQRyMHAwJAYIKwYBBQUH
# MAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBIBggrBgEFBQcwAoY8aHR0cDov
# L2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0RVZDb2RlU2lnbmluZ0NBLVNI
# QTIuY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggEBAJGCCl1voKTA
# ml2M6QyubvxhbjOHzau7EL8YEHQgkBfarH0zrtOFXypqwELz219z9wdjUQ4czWEg
# MWCAusWIQpA47qFsrcFSjmvoa+AMYzCEMbkwXGGjquRTD/s61Zy6jh5ayPzxyj2+
# Ql61mIvDYiXhWv5BZuq/mS8YZGNXM1GwIDZK05gDup+NvIVVCoUa9A61KAJeXOyq
# d6yquSSaqW1HqD4Yg29YdxdF+nySo7cuI9LnefYofsNZ4PJJC2W7OtNgr770RTPz
# QrhJHRpJwfm5w2aUV0sO8KciQ+JySwKqZoO+WqxJ9q9JjUl/WY7qsFe3EcY+9vdK
# +dlK+QD24gowggZqMIIFUqADAgECAhADAZoCOv9YsWvW1ermF/BmMA0GCSqGSIb3
# DQEBBQUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgQ0EtMTAeFw0xNDEwMjIwMDAwMDBaFw0yNDEwMjIwMDAwMDBaMEcxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDElMCMGA1UEAxMcRGlnaUNlcnQg
# VGltZXN0YW1wIFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAKNkXfx8s+CCNeDg9sYq5kl1O8xu4FOpnx9kWeZ8a39rjJ1V+JLjntVaY1sC
# SVDZg85vZu7dy4XpX6X51Id0iEQ7Gcnl9ZGfxhQ5rCTqqEsskYnMXij0ZLZQt/US
# s3OWCmejvmGfrvP9Enh1DqZbFP1FI46GRFV9GIYFjFWHeUhG98oOjafeTl/iqLYt
# WQJhiGFyGGi5uHzu5uc0LzF3gTAfuzYBje8n4/ea8EwxZI3j6/oZh6h+z+yMDDZb
# esF6uHjHyQYuRhDIjegEYNu8c3T6Ttj+qkDxss5wRoPp2kChWTrZFQlXmVYwk/PJ
# YczQCMxr7GJCkawCwO+k8IkRj3cCAwEAAaOCAzUwggMxMA4GA1UdDwEB/wQEAwIH
# gDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIIBvwYDVR0g
# BIIBtjCCAbIwggGhBglghkgBhv1sBwEwggGSMCgGCCsGAQUFBwIBFhxodHRwczov
# L3d3dy5kaWdpY2VydC5jb20vQ1BTMIIBZAYIKwYBBQUHAgIwggFWHoIBUgBBAG4A
# eQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkAYwBhAHQA
# ZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBjAGUA
# IABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMAUABTACAA
# YQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkAIABBAGcA
# cgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBhAGIA
# aQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBhAHQA
# ZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMAZQAuMAsG
# CWCGSAGG/WwDFTAfBgNVHSMEGDAWgBQVABIrE5iymQftHt+ivlcNK2cCzTAdBgNV
# HQ4EFgQUYVpNJLZJMp1KKnkag0v0HonByn0wfQYDVR0fBHYwdDA4oDagNIYyaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0EtMS5jcmww
# OKA2oDSGMmh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RENBLTEuY3JsMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0xLmNydDANBgkqhkiG9w0BAQUF
# AAOCAQEAnSV+GzNNsiaBXJuGziMgD4CH5Yj//7HUaiwx7ToXGXEXzakbvFoWOQCd
# 42yE5FpA+94GAYw3+puxnSR+/iCkV61bt5qwYCbqaVchXTQvH3Gwg5QZBWs1kBCg
# e5fH9j/n4hFBpr1i2fAnPTgdKG86Ugnw7HBi02JLsOBzppLA044x2C/jbRcTBu7k
# A7YUq/OPQ6dxnSHdFMoVXZJB2vkPgdGZdA0mxA5/G7X1oPHGdwYoFenYk+VVFvC7
# Cqsc21xIJ2bIo4sKHOWV2q7ELlmgYd3a822iYemKC23sEhi991VUQAOSK2vCUcIK
# SK+w1G7g9BQKOhvjjz3Kr2qNe9zYRDCCBrwwggWkoAMCAQICEAPxtOFfOoLxFJZ4
# s9fYR1wwDQYJKoZIhvcNAQELBQAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMi
# RGlnaUNlcnQgSGlnaCBBc3N1cmFuY2UgRVYgUm9vdCBDQTAeFw0xMjA0MTgxMjAw
# MDBaFw0yNzA0MTgxMjAwMDBaMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdp
# Q2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNVBAMTIkRp
# Z2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCnU/oPsrUT8WTPhID8roA10bbXx6MsrBosrPGErDo1
# EjqSkbpX5MTJ8y+oSDy31m7clyK6UXlhr0MvDbebtEkxrkRYPqShlqeHTyN+w2xl
# JJBVPqHKI3zFQunEemJFm33eY3TLnmMl+ISamq1FT659H8gTy3WbyeHhivgLDJj0
# yj7QRap6HqVYkzY0visuKzFYZrQyEJ+d8FKh7+g+03byQFrc+mo9G0utdrCMXO42
# uoPqMKhM3vELKlhBiK4AiasD0RaCICJ2615UOBJi4dJwJNvtH3DSZAmALeK2nc4f
# 8rsh82zb2LMZe4pQn+/sNgpcmrdK0wigOXn93b89OgklAgMBAAGjggNYMIIDVDAS
# BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggr
# BgEFBQcDAzB/BggrBgEFBQcBAQRzMHEwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBJBggrBgEFBQcwAoY9aHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0SGlnaEFzc3VyYW5jZUVWUm9vdENBLmNydDCBjwYDVR0f
# BIGHMIGEMECgPqA8hjpodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRI
# aWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMECgPqA8hjpodHRwOi8vY3JsNC5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMIIBxAYD
# VR0gBIIBuzCCAbcwggGzBglghkgBhv1sAwIwggGkMDoGCCsGAQUFBwIBFi5odHRw
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9zc2wtY3BzLXJlcG9zaXRvcnkuaHRtMIIBZAYI
# KwYBBQUHAgIwggFWHoIBUgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAg
# AEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAg
# AGEAYwBjAGUAcAB0AGEAbgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBl
# AHIAdAAgAEMAUAAvAEMAUABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBu
# AGcAIABQAGEAcgB0AHkAIABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAg
# AGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAg
# AGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIABy
# AGUAZgBlAHIAZQBuAGMAZQAuMB0GA1UdDgQWBBSP6H7wbTJqAAUjx3CXajqQ/2vq
# 1DAfBgNVHSMEGDAWgBSxPsNpA/i/RwHUmCYaCALvY2QrwzANBgkqhkiG9w0BAQsF
# AAOCAQEAGTNKDIEzN9utNsnkyTq7tRsueqLi9ENCF56/TqFN4bHb6YHdnwHy5IjV
# 6f4J/SHB7F2A0vDWwUPC/ncr2/nXkTPObNWyGTvmLtbJk0+IQI7N4fV+8Q/GWVZy
# 6OtqQb0c1UbVfEnKZjgVwb/gkXB3h9zJjTHJDCmiM+2N4ofNiY0/G//V4BqXi3za
# bfuoxrI6Zmt7AbPN2KY07BIBq5VYpcRTV6hg5ucCEqC5I2SiTbt8gSVkIb7P7kIY
# Q5e7pTcGr03/JqVNYUvsRkG4Zc64eZ4IlguBjIo7j8eZjKMqbphtXmHGlreKuWEt
# k7jrDgRD1/X+pvBi1JlqpcHB8GSUgDCCBs0wggW1oAMCAQICEAb9+QOWA63qAArr
# Pye7uhswDQYJKoZIhvcNAQEFBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMb
# RGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4XDTA2MTExMDAwMDAwMFoXDTIx
# MTExMDAwMDAwMFowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IElu
# YzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQg
# QXNzdXJlZCBJRCBDQS0xMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
# 6IItmfnKwkKVpYBzQHDSnlZUXKnE0kEGj8kz/E1FkVyBn+0snPgWWd+etSQVwpi5
# tHdJ3InECtqvy15r7a2wcTHrzzpADEZNk+yLejYIA6sMNP4YSYL+x8cxSIB8HqIP
# kg5QycaH6zY/2DDD/6b3+6LNb3Mj/qxWBZDwMiEWicZwiPkFl32jx0PdAug7Pe2x
# QaPtP77blUjE7h6z8rwMK5nQxl0SQoHhg26Ccz8mSxSQrllmCsSNvtLOBq6thG9I
# hJtPQLnxTPKvmPv2zkBdXPao8S+v7Iki8msYZbHBc63X8djPHgp0XEK4aH631XcK
# J1Z8D2KkPzIUYJX9BwSiCQIDAQABo4IDejCCA3YwDgYDVR0PAQH/BAQDAgGGMDsG
# A1UdJQQ0MDIGCCsGAQUFBwMBBggrBgEFBQcDAgYIKwYBBQUHAwMGCCsGAQUFBwME
# BggrBgEFBQcDCDCCAdIGA1UdIASCAckwggHFMIIBtAYKYIZIAYb9bAABBDCCAaQw
# OgYIKwYBBQUHAgEWLmh0dHA6Ly93d3cuZGlnaWNlcnQuY29tL3NzbC1jcHMtcmVw
# b3NpdG9yeS5odG0wggFkBggrBgEFBQcCAjCCAVYeggFSAEEAbgB5ACAAdQBzAGUA
# IABvAGYAIAB0AGgAaQBzACAAQwBlAHIAdABpAGYAaQBjAGEAdABlACAAYwBvAG4A
# cwB0AGkAdAB1AHQAZQBzACAAYQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8AZgAgAHQA
# aABlACAARABpAGcAaQBDAGUAcgB0ACAAQwBQAC8AQwBQAFMAIABhAG4AZAAgAHQA
# aABlACAAUgBlAGwAeQBpAG4AZwAgAFAAYQByAHQAeQAgAEEAZwByAGUAZQBtAGUA
# bgB0ACAAdwBoAGkAYwBoACAAbABpAG0AaQB0ACAAbABpAGEAYgBpAGwAaQB0AHkA
# IABhAG4AZAAgAGEAcgBlACAAaQBuAGMAbwByAHAAbwByAGEAdABlAGQAIABoAGUA
# cgBlAGkAbgAgAGIAeQAgAHIAZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZIAYb9bAMV
# MBIGA1UdEwEB/wQIMAYBAf8CAQAweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzAB
# hhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9j
# YWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQw
# gYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdp
# Q2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwHQYDVR0OBBYEFBUA
# EisTmLKZB+0e36K+Vw0rZwLNMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3z
# bcgPMA0GCSqGSIb3DQEBBQUAA4IBAQBGUD7Jtygkpzgdtlspr1LPUukxR6tWXHvV
# DQtBs+/sdR90OPKyXGGinJXDUOSCuSPRujqGcq04eKx1XRcXNHJHhZRW0eu7NoR3
# zCSl8wQZVann4+erYs37iy2QwsDStZS9Xk+xBdIOPRqpFFumhjFiqKgz5Js5p8T1
# zh14dpQlc+Qqq8+cdkvtX8JLFuRLcEwAiR78xXm8TBJX/l/hHrwCXaj++wc4Tw3G
# XZG5D2dFzdaD7eeSDY2xaYxP+1ngIw/Sqq4AfO6cQg7PkdcntxbuD8O9fAqg7iwI
# VYUiuOsYGk38KiGtSTGDR5V3cdyxG0tLHBCcdxTBnU8vWpUIKRAmMYIERjCCBEIC
# AQEwgYAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMiRGlnaUNlcnQgRVYgQ29k
# ZSBTaWduaW5nIENBIChTSEEyKQIQC/YrF6l/9vGkuqceshfX5zANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCD+oM//eHoVqTUIcwtPB3P/qqad4tWiABN+lq9nXZPIwDANBgkq
# hkiG9w0BAQEFAASCAQCrY/A92/aYyFrZm46OERrDJdkR2qj8Us2V2Fxirt+owm81
# JZl02UStXo+E+q1LWSQywlNmprRKd2ZD4iNRIixOQqLLj99KkRhwuUjtpWqkck4o
# oEga7orp5R85iNU2hLgS86UvnDG2ZI0p9TFoOl6WdklCX62fGKkuzyvw3Xuu2ntG
# UmZyeuJ6+ixMfGvHcnMOFco2zmg+tpFmvsdmh5hYO0MDxzQSDlI3MF2m56XLNF/D
# HvMUCHwwA+YLjF9kb+SRO7zFzAiqq3n/xxnm6MiYe48ikMFxSFDnt44VjQjH7YZL
# UgoFghyOrllP9/lzQ7WR08iVT1GP75c7wDO9W7gqoYICDzCCAgsGCSqGSIb3DQEJ
# BjGCAfwwggH4AgEBMHYwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0
# IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNl
# cnQgQXNzdXJlZCBJRCBDQS0xAhADAZoCOv9YsWvW1ermF/BmMAkGBSsOAwIaBQCg
# XTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0yMDEw
# MTkxMDMxMjZaMCMGCSqGSIb3DQEJBDEWBBTYUSvuiWC5e/VW2jL1+IOcrYjYOzAN
# BgkqhkiG9w0BAQEFAASCAQCNH5oDA81ZOprM0ePPf6XO3uUxNY3jCiPC9VDEyJXZ
# pU1wWSAIytawHViu9X6pl27FjFzf9luGmoeuS72g3XAxcjgc/NUuQA7bjezpBJsl
# ztkb+Z2uso2M+o8jqm6j1gSYKK/Pah6nvTuWLSjpD7nVQrPBlDgIkHy2OHjHCsg0
# o0gkD+xNcpsSUNike/E9Zv6waxfJ82b02bBmSSiJuPyThn2YhFpEvKT32evSQsgz
# E+F33PlGgQ6nP/3/oQWcUrOZu2kicnmT+P7HQStC7gK1Bqr8g7h2RFpfnOit2lVs
# NC3EVBMh75oRWCOqdu0QcV8vocOsY7BNUZmXg56XFma3
# SIG # End signature block
