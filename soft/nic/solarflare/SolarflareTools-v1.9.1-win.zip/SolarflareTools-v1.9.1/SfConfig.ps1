<#
    Copyright (c) 2020 Xilinx, Inc. All rights reserved.
    Copyright (c) 2018-2019 Solarflare Communications Inc.
    Use is subject to license terms.
#>

<#
.SYNOPSIS
    SfConfig
.DESCRIPTION
    Tool to manage configuration for Solarflare hardware
#>

#Requires -Version 5.1
#Requires -Modules CimCmdlets

class SfConfig : PartitionControl {

    SfConfig([Hashtable] $BaseParams)
        : base ($BaseParams)
    {
    }

    $GlobalDynCfgTagMap = @{
      'Global Port Mode' = [UInt32]'0x10110000'; # TLV_TAG_GLOBAL_PORT_MODE
      'Firmware Options' = [UInt32]'0x100b0000';  # TLV_TAG_FIRMWARE_OPTIONS
      'Bundle Update Disabled' = [UInt32]'0x102d0000';  # TLV_TAG_BUNDLE_UPDATE_DISABLED
      "Privilege Mask Add" = [UInt32]'0x10150000'; # TLV_TAG_PRIVILEGE_MASK_ADD
      "Privilege Mask Rem" = [UInt32]'0x10160000';  # TLV_TAG_PRIVILEGE_MASK_REM
    }

    $PortDynCfgTagMap = @{
      'VSwitch Type' = [UInt32]'0x10120000'; # TLV_TAG_VSWITCH_TYPE
      'Pf Pcie Config' = [UInt32]'0x10080000'; # TLV_TAG_PF_PCIE_CONFIG(0)
      'VPort VLan Tag' = [UInt32]'0x10130000'; # TLV_TAG_VPORT_VLAN_TAG(0)
    }

    # Common names for port modes
    $PortModeMap = @{
      'Default' = [UInt32]'0xFFFFFFFF';
    }

    # Per-family port-mode aliases which should be
    # used for display and accepted as input
    $PortModeMap_7K = @{
      '[1x10G]' = 0;         # TLV_PORT_MODE_1x1_NA
      '[1x40G]' = 1;         # TLV_PORT_MODE_1x4_NA
      '[1x10G][1x10G]' = 2;  # TLV_PORT_MODE_1x1_1x1
      '[1x40G][1x40G]' = 3;  # TLV_PORT_MODE_1x4_1x4
      '[2x10G][2x10G]' = 4;  # TLV_PORT_MODE_4x1_NA
    }
    $PortModeMap_8K = @{
      '[1x40G]' = 1;         # TLV_PORT_MODE_1x4_NA
      '[1x10G][1x10G]' = 2;  # TLV_PORT_MODE_1x1_1x1
      '[1x40G][1x40G]' = 3;  # TLV_PORT_MODE_1x4_1x4
      '[4x10G]' = 4;         # TLV_PORT_MODE_4x1_NA
      '[2x10G][2x10G]' = 5;  # TLV_PORT_MODE_2x1_2x1
    }
    $PortModeMap_X2 = @{
      '[1x100G]' = 1;              # TLV_PORT_MODE_1x4_NA
      '[1x10/25G][1x10/25G]' = 2;  # TLV_PORT_MODE_1x1_1x1
      '[1x50G][1x50G]' = 12;       # TLV_PORT_MODE_1x2_1x2
      '[4x10/25G]' = 4;            # TLV_PORT_MODE_4x1_NA
      '[2x10/25G][2x10/25G]' = 5;  # TLV_PORT_MODE_2x1_2x1
      '[2x50G]' = 13;              # TLV_PORT_MODE_2x2_NA
    }

    # Accept another set of port-mode aliases for compatibility with
    # 7K-era Sfboot terminology.
    $PortModeMap_Legacy = @{
        '1x10G' = 0;  # TLV_PORT_MODE_1x1_NA
        '1x40G' = 1;  # TLV_PORT_MODE_1x4_NA
        '2x10G' = 2;  # TLV_PORT_MODE_1x1_1x1
        '2x40G' = 3;  # TLV_PORT_MODE_1x4_1x4
        '4x10G' = 4;  # TLV_PORT_MODE_4x1_NA
      }

    $FirmwareVariantMap = @{
      'Auto' = [UInt32]'0xFFFFFFFF';
      'Full feature' = 0;
      'Ultra low latency' = 1;
      'Capture packed stream' = 2;
      'Capture packed stream hash 1' = 4; # Hide
      'Rules engine' = 5;
      'DPDK' = 6;
      'L3xUDP' = 7; # Hide
    }

    $GlobalPrivilegesMap = @{
        "Link" =             [UInt32]"0x00000002";
    }

    $BooleanFlagMap = @{
        "Enabled" = $true;
        "Disabled" = $false;
    }

    [String] ReverseLookup([Hashtable] $Dict, [UInt32] $Value)
    {
        foreach($entry in $Dict.GetEnumerator()) {
            if ($entry.Value -eq $Value) {
                return $entry.Key
            }
        }
        return [String]::Empty
    }

    [Hashtable] LookupFamilyPortMap([String] $InstanceName) {
        # Look up device ID to allow family-specific strings
        $baseParams = $this.baseParams
        if (Get-Command -CommandType Function "Get-NetAdapter" -errorAction SilentlyContinue) {
            $deviceId = (Get-NetAdapter @baseParams -InterfaceDescription $InstanceName).PnpDeviceId
        } else {
            # TODO WinPE support - use WMI Win32_NetworkAdapter
            return @{}
        }

        ($deviceId -match 'PCI\\VEN_1924\&DEV_(?<deviceId>[\w]*)')

        switch -Wildcard ($matches.deviceId) {
        '*9*3'  { return $this.PortModeMap_7K }
        '*A03'  { return $this.PortModeMap_8K }
        '*B03'  { return $this.PortModeMap_X2 }
        }
        return $null
    }

    hidden [void] ResetSfAdapters()
    {
        $baseParams = $this.baseParams
        Get-NetAdapter @baseParams -InterfaceDescription 'Solarflare*' | Restart-NetAdapter
    }

    hidden [CimInstance[]] GetPartitionViewInfoList()
    {
        $baseParams = $this.baseParams
        return CimCmdlets\Get-CimInstance @baseParams -Namespace root\wmi -ClassName Solarflare_PartitionViewInfoList
    }

    hidden [void] HandleStatus([Hashtable] $Status) {
        if ($Status.ActionsRequired) {
            if ($Status.ActionsRequired -bAND 0x1) {
                # Adapter firmware reboot required - schedule an MCDI reboot
                Write-Warning "Adapter $($Status.InstanceName) is being rebooted."
                $this.McdiReboot($Status.InstanceName)
            }
            elseif ($Status.ActionsRequired -bAND 0x2) {
                Write-Warning "Adapter $($Status.InstanceName) is being restarted."
                $this.DeviceRestart($Status.InstanceName)
            }
            if ($Status.ActionsRequired -bAND 0x8) {
                Write-Warning "Computer must be powered off for changes to take effect"
            }
            elseif ($Status.ActionsRequired -bAND 0x4) {
                Write-Warning "Computer must be restarted for changes to take effect"
            }
        }
    }

    hidden [void] ClearView([Partition] $Update)
    {
        $instanceName = $Update.InstanceName
        $type = $Update.Type
        $subtype = $Update.SubType
        $view = $Update.View
        $accessMode = 0
        $path = ''
        $updateMode = 0 #0: sync, 16 async
        $status = @{}

        $instance = $this.GetPartitionControl($instanceName)
        $sessionId = $this.OpenView($instance, $type, $subtype, $view, $accessMode, $path)
        if ($sessionId) {
            try {
                $this.ClearView($instance, $sessionId)
                $commitResult = $this.CommitView($instance, $sessionId, $updateMode)
                if ($commitResult -eq 0) {
                    $status = $this.GetStatus($instance, $sessionId)
                } else {
                    Write-Error "Update to $($Update.InstanceName):$($Update.Name) rejected"
                }
            } finally {
                $this.CloseView($instance, $sessionId)
            }
        }
        $this.HandleStatus($status)
    }

    hidden [void] SetView([Partition] $Update, [Byte[]] $Data)
    {
        $instanceName = $Update.InstanceName
        $type = $Update.Type
        $subtype = $Update.SubType
        $view = $Update.View
        $accessMode = 0
        $path = ''
        $updateMode = 0 #0: sync, 16 async

        $instance = $this.GetPartitionControl($instanceName)
        $sessionId = $this.OpenView($instance, $type, $subtype, $view, $accessMode, $path)
        if ($sessionId) {
            try {
                $this.ClearView($instance, $sessionId)
                $this.WriteView($instance, $sessionId, $Data)
                $commitResult = $this.CommitView($instance, $sessionId, $updateMode)
                if ($commitResult -ne 0) {
                    Write-Error "Update to $($update.InstanceName):$($update.Name) rejected"
                }
            } finally {
                $this.CloseView($instance, $sessionId)
            }
        }
    }

    [void] ClearAll([System.Collections.Generic.HashSet[String]] $SelectedSet)
    {
        $PartitionViewInfoList = $this.GetPartitionViewInfoList()
        $GlobalDynCfgList = $this.FilterPartitionsByName($PartitionViewInfoList, 'Global Dynamic Config', $SelectedSet)
        foreach($GlobalDynCfg in $GlobalDynCfgList) {
            if ($PSCmdlet.ShouldProcess("Clear global configuration on $($GlobalDynCfg.InstanceName)",
                "Clear global configuration on $($GlobalDynCfg.InstanceName)?",
                'Clear global configuration to factory defaults')) {
                $this.ClearView($GlobalDynCfg)
            }
        }
        $GlobalBootCfgList = $this.FilterPartitionsByName($PartitionViewInfoList, 'Global Boot Config', $SelectedSet)
        foreach($GlobalBootCfg in $GlobalBootCfgList) {
            if ($PSCmdlet.ShouldProcess("Clear boot configuration on $($GlobalBootCfg.InstanceName)",
                "Clear boot configuration on $($GlobalBootCfg.InstanceName)?",
                'Clear boot configuration to factory defaults')) {
                $this.ClearView($GlobalBootCfg)
            }
        }
        $PortDynCfgList = $this.FilterPartitionsByName($PartitionViewInfoList, "Port Dynamic Config", $SelectedSet)
        foreach($PortDynCfg in $PortDynCfgList) {
            if ($PSCmdlet.ShouldProcess("Clear port configuration on $($PortDynCfg.InstanceName)",
                "Clear port configuration on $($PortDynCfg.InstanceName)?",
                'Clear port configuration to factory defaults')) {
                $this.ClearView($PortDynCfg)
            }
        }
        $PfBootCfgList = $this.FilterPartitionsByName($PartitionViewInfoList, "PF Boot Config", $SelectedSet)
        foreach($PfBootCfg in $PfBootCfgList) {
            if ($PSCmdlet.ShouldProcess("Clear PF configuration on $($PfBootCfg.InstanceName)",
                "Clear PF configuration on $($PfBootCfg.InstanceName)?",
                'Clear PF configuration to factory defaults')) {
                $this.ClearView($PfBootCfg)
            }
        }
    }

    hidden [UInt32[]] GetDynCfgView([Partition]$ViewInfo, [String]$Name)
    {
        $instanceName = $viewInfo.InstanceName

        if ($viewInfo.Type -ne 11) { return $null }
        if ($viewInfo.Name -ne $Name) { return $null }

        $accessMode = 1 #1: Fetch
        $path = ''
        $view = $null

        $instance = $this.GetPartitionControl($instanceName)
        $sessionId = $this.OpenView($instance, $ViewInfo.Type, $ViewInfo.Subtype, $ViewInfo.View, $accessMode, $path)
        if ($sessionId) {
            try {
                $viewSize = $this.GetViewSize($instance, $sessionId)
                $view = $this.ReadViewUInt32s($instance, $sessionId, 0, $viewSize)
            } finally {
                $this.CloseView($instance, $sessionId)
            }
        }

        return $view
    }

    hidden [void] SetDynCfgView([Partition]$ViewInfo, [String]$Name, [UInt32[]] $View,
        [UInt32] $ExtraActions)
    {
        $instanceName = $ViewInfo.InstanceName

        if ($ViewInfo.Type -ne 11) { return }
        if ($ViewInfo.Name -ne $Name) { return }

        if ($PSCmdlet.ShouldProcess("Write to $($viewInfo.InstanceName):$($name)",
            "Write to $($viewInfo.InstanceName):$($name)?", "Write configuration")) {
            $accessMode = 0
            $path = ''
            $updateMode = 0 #0: sync
            $status = @{}

            $instance = $this.GetPartitionControl($instanceName)
            $sessionId = $this.OpenView(
                            $instance, $viewInfo.Type, $viewInfo.Subtype, $viewInfo.View, $accessMode, $path)
            if ($sessionId) {
                try {
                    $this.WriteViewUInt32s($instance, $sessionId, $View)
                    $commitResult = $this.CommitView($instance, $sessionId, $updateMode)
                    if ($commitResult -eq 0) {
                        $status = $this.GetStatus($instance, $sessionId)
                        # Add any extra actions on successful commit of this view
                        if ($status.InstanceName -and ($ExtraActions)) {
                            $status.ActionsRequired = ($status.ActionsRequired -bOR $ExtraActions)
                        }
                    } else {
                        Write-Error "Update to $($viewInfo.InstanceName):$Name rejected"
                    }
                } finally {
                    $this.CloseView($instance, $sessionId)
                }
            }
            $this.HandleStatus($status)
        }
    }
}

function Get-NetAdapterGlobalPrivileges() {
    <#
        .SYNOPSIS
        Report the current global privileges settings for Solarflare NICs.
        .DESCRIPTION
        Report privilege settings common to all ports of Solarflare NICs. Settings:
        Link - Enabled, Disabled, or not set for default
        .PARAMETER Name
        Specifies the network adapter by name.
        .PARAMETER InterfaceDescription
        Specifies the network adapter by interface description.
        .PARAMETER HardwareId
        Specifies network adapters by Windows HardwareId match.
        .PARAMETER CimSession
        Enter a computer name or a session object, such as the output of a New-CimSession or Get-CimSession cmdlet.
        The default is the current session on the local computer.
        .OUTPUTS
        Solarflare.GlobalPrivileges
        .EXAMPLE
        Get-NetAdapter | Get-SfNetAdapterGlobalPrivileges
    #>
    [cmdletBinding(PositionalBinding=$false,ConfirmImpact='Low')]
    [OutputType('Solarflare.GlobalPrivileges', ParameterSetName = 'ByName')]
    [OutputType('Solarflare.GlobalPrivileges', ParameterSetName = 'ByDescription')]
    [OutputType('Solarflare.GlobalPrivileges', ParameterSetName = 'ByHardwareId')]
    param(

        [Parameter(ParameterSetName = 'ByName')]
        [Alias('ifAlias InterfaceAlias')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $Name,

        [Parameter(ParameterSetName = 'ByDescription', Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias('ifDesc')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $InterfaceDescription,

        [Parameter(ParameterSetName = 'ByHardwareId', Mandatory = $true)]
        [ValidateNotNull()]
        [String[]] $HardwareId,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Alias('Session')]
        [ValidateNotNull()]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession
    )

    begin {
        $baseParams = @{}
        if ($PSBoundParameters.ContainsKey('CimSession')) {
            $baseParams['CimSession'] = $PSBoundParameters['CimSession']
        }
        $sc = [SfConfig]::new($baseParams)
        $configList = @()
    }

    process {

        $PartitionViewInfoList = $sc.GetPartitionViewInfoList()
        if($PSBoundParameters.ContainsKey('Name')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[string]
            foreach ($interface in (Get-NetAdapter @baseParams -Name $Name)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('InterfaceDescription')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            foreach ($interface in (Get-NetAdapter @baseParams -InterfaceDescription $InterfaceDescription `
                    -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('HardwareId')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            $SolarflareAdapters = Get-PnpEntity @baseParams -HardwareId $HardwareId -PresentOnly
            if (!$SolarflareAdapters) {
                # No Adapters Found
                Write-Error "No Solarflare adapter(s) found with HardwareId:$HardwareId"
                return $Adapters
            }
            foreach($interface in $SolarflareAdapters) {
                $selectedSet.Add($interface.Name) | Out-Null
            }
        }
        else {
            $selectedSet = $null
        }
        $instances = $sc.FilterPartitionsByName($PartitionViewInfoList, $null, $selectedSet)

        foreach($instance in $instances) {

            # Get settings from dynamic config partition view
            $matchedSettings = $sc.ReadTLV($sc.GetDynCfgView($instance, "Global Dynamic Config"))

            if ($matchedSettings) {

                $globalSettings = [PSCustomObject] @{
                    PSTypeName = 'Solarflare.GlobalPrivileges'
                    InterfaceDescription = $instance.InstanceName
                    Link = $null
                }

                if ($matchedSettings.Contains($sc.GlobalDynCfgTagMap["Privilege Mask Rem"])) {
                    [UInt32]$removed = ($matchedSettings[$sc.GlobalDynCfgTagMap["Privilege Mask Rem"]])[0]
                    if (($removed -band $sc.GlobalPrivilegesMap["Link"]) -ne 0) {
                        $globalSettings.Link = "Disabled"
                    }
                }
                if ($matchedSettings.Contains($sc.GlobalDynCfgTagMap["Privilege Mask Add"])) {
                    [UInt32]$added = ($matchedSettings[$sc.GlobalDynCfgTagMap["Privilege Mask Add"]])[0]
                    if (($added -band $sc.GlobalPrivilegesMap["Link"]) -ne 0) {
                        $globalSettings.Link = "Enabled"
                    }
                }
                $configList += $globalSettings
            }
        }
    }

    end {
        $configList
    }
}

function Get-NetAdapterSwitchConfiguration() {
    <#
        .SYNOPSIS
        Report the current port switch configuration settings for Solarflare NICs.
        .DESCRIPTION
        Report settings common to all ports of Solarflare NICs. Settings:
        PfCount - integer count of PFs on this port
        VlanTags - list of VLAN tags associated with the PFS on this port
        VfCount - integer count of VFs allocated per PF
        MsixLimit - list of integer limit on MSIX interupts associated with the PFS on this port
        .PARAMETER Name
        Specifies the network adapter by name.
        .PARAMETER InterfaceDescription
        Specifies the network adapter by interface description.
        .PARAMETER HardwareId
        Specifies network adapters by Windows HardwareId match.
        .PARAMETER CimSession
        Enter a computer name or a session object, such as the output of a New-CimSession or Get-CimSession cmdlet.
        The default is the current session on the local computer.
        .OUTPUTS
        Solarflare.SwitchConfiguration
        .EXAMPLE
        Get-NetAdapter | Get-SfNetAdapterSwitchConfiguration
    #>
    [cmdletBinding(PositionalBinding=$false,ConfirmImpact='Low')]
    [OutputType('Solarflare.SwitchConfiguration', ParameterSetName = 'ByName')]
    [OutputType('Solarflare.SwitchConfiguration', ParameterSetName = 'ByDescription')]
    [OutputType('Solarflare.SwitchConfiguration', ParameterSetName = 'ByHardwareId')]
    param(

        [Parameter(ParameterSetName = 'ByName')]
        [Alias('ifAlias InterfaceAlias')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $Name,

        [Parameter(ParameterSetName = 'ByDescription', Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias('ifDesc')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $InterfaceDescription,

        [Parameter(ParameterSetName = 'ByHardwareId', Mandatory = $true)]
        [ValidateNotNull()]
        [String[]] $HardwareId,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Alias('Session')]
        [ValidateNotNull()]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession
    )

    begin {
        $baseParams = @{}
        if ($PSBoundParameters.ContainsKey('CimSession')) {
            $baseParams['CimSession'] = $PSBoundParameters['CimSession']
        }
        $sc = [SfConfig]::new($baseParams)

        $configHash = @{}
    }

    process {

        $PartitionViewInfoList = $sc.GetPartitionViewInfoList()
        if($PSBoundParameters.ContainsKey('Name')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[string]
            foreach ($interface in (Get-NetAdapter @baseParams -Name $Name)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('InterfaceDescription')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            foreach ($interface in (Get-NetAdapter @baseParams -InterfaceDescription $InterfaceDescription `
                    -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('HardwareId')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            $SolarflareAdapters = Get-PnpEntity @baseParams -HardwareId $HardwareId -PresentOnly
            if (!$SolarflareAdapters) {
                # No Adapters Found
                Write-Error "No Solarflare adapter(s) found with HardwareId:$HardwareId"
                return $Adapters
            }
            foreach($interface in $SolarflareAdapters) {
                $selectedSet.Add($interface.Name) | Out-Null
            }
        }
        else {
            $selectedSet = $null
        }
        $instances = $sc.FilterPartitionsByName($PartitionViewInfoList, $null, $selectedSet)

        foreach($instance in $instances) {

            # Get matching dynamic config partion
            $matchedSettings = $sc.ReadTLV($sc.GetDynCfgView($instance, "Port Dynamic Config"))
            if ($matchedSettings) {
                if ($configHash.Contains($instance.InstanceName)) {
                    $switchSettings = $configHash[$instance.InstanceName]
                }
                else {
                    $switchSettings = [PSCustomObject] @{
                        PSTypeName = 'Solarflare.SwitchConfiguration'
                        InterfaceDescription = $instance.InstanceName
                        VlanTags = $null
                        PfCount = $null
                        MsixLimit = $null
                    }
                }

                # Scan PF_PCIE_CONFIG until 1st missing per-PF tag to collate PF count and VLAN assignments
                # Driver presents a per-Port view of the PCIe Config tags, so we just need to count them
                $pfCount = 0
                $msixLimit = $null
                for ($pfIndex = 0; $pfIndex -lt 16; $pfIndex++) {
                    $tagId = $sc.PortDynCfgTagMap['Pf Pcie Config'] + $pfIndex
                    if ($matchedSettings.Contains($tagId)) {
                        $pfCount = $pfIndex + 1

                        [UInt32]$MsixLimitsValue = $matchedSettings[$tagId][0]
                        [UInt16]$PfMsixLimitsValue = (($MsixLimitsValue -shr 16) -band [UInt16]'0xFFFF')
                        if ($PfMsixLimitsValue -eq [UInt16]'0xFFFF') {
                            $PfMsixLimitsString = 'Default'
                        }
                        else {
                            $PfMsixLimitsString = "$PfMsixLimitsValue"
                        }
                        if ($pfIndex -eq 0) {
                            $msixLimit = @($PfMsixLimitsString)
                        }
                        else {
                            $msixLimit += $PfMsixLimitsString
                        }
                    }
                    else {
                        break
                    }
                }

                if ($pfCount -gt 0) {
                    $switchSettings.PfCount = $pfCount
                    $switchSettings.MsixLimit = $msixLimit
                }

                # Scan VLAN tags. Driver presents the per-Port view of these tags
                $vlanTags = $null
                [int]$intVlanCount = 0
                for ($pfIndex = 0; $pfIndex -lt $pfCount; $pfIndex++) {
                    $tagId = $sc.PortDynCfgTagMap['VPort VLan Tag'] + $pfIndex
                    if ($matchedSettings.Contains($tagId)) {
                        [UInt32]$VlanTagValue = $matchedSettings[$tagId][0]
                        if ($VlanTagValue -eq [UInt32]'0xffffffff') {
                            $VlanTagString = ''
                        }
                        else {
                            $VlanTagString = $VlanTagValue.ToString()
                        }
                        $intVlanCount++
                    }
                    else {
                        $VlanTagString = $null
                    }
                    if ($pfIndex -eq 0) {
                        $vlanTags = @($VlanTagString)
                    }
                    else {
                        $vlanTags += $VlanTagString
                    }
                }

                if ($intVlanCount -gt 0) {
                    $switchSettings.VlanTags = $vlanTags
                }
                else {
                    $switchSettings.VlanTags = $null
                }

                if (-not $configHash.Contains($instance.InstanceName)) {
                    $configHash.Add($instance.InstanceName, $switchSettings)
                }
            }
        }
    }

    end {
        $configHash.Values
    }
}

function Get-NetAdapterGlobalConfiguration() {
    <#
        .SYNOPSIS
        Report the current global configuration settings for Solarflare NICs.
        .DESCRIPTION
        Report settings common to all ports of Solarflare NICs. Settings:
        FirmwareVariant - string specifying NIC firmware variant to enable at power-up
        PortMode - string specifying port configuration at power-up
        AllowDowngradeToLegacyFirmware - specified to allow downgrades to legacy firmware images
        .PARAMETER Name
        Specifies the network adapter by name.
        .PARAMETER InterfaceDescription
        Specifies the network adapter by interface description.
        .PARAMETER HardwareId
        Specifies network adapters by Windows HardwareId match.
        .PARAMETER CimSession
        Enter a computer name or a session object, such as the output of a New-CimSession or Get-CimSession cmdlet.
        The default is the current session on the local computer.
        .OUTPUTS
        Solarflare.GlobalConfiguration
        .EXAMPLE
        Get-NetAdapter | Get-SfNetAdapterGlobalConfiguration
        Report the current global configuration from local computer.
        .EXAMPLE
        Get-NetAdapter -CimSession $session | Get-SfNetAdapterGlobalConfiguration -CimSession $session
        Report the current global configuration from remote computer.
    #>
    [CmdletBinding(PositionalBinding = $false, ConfirmImpact = 'Low')]
    [OutputType('Solarflare.GlobalConfiguration', ParameterSetName = 'ByName')]
    [OutputType('Solarflare.GlobalConfiguration', ParameterSetName = 'ByDescription')]
    [OutputType('Solarflare.GlobalConfiguration', ParameterSetName = 'ByHardwareId')]
    param(

        [Parameter(ParameterSetName = 'ByName')]
        [Alias('ifAlias InterfaceAlias')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $Name,

        [Parameter(ParameterSetName = 'ByDescription', Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias('ifDesc')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $InterfaceDescription,

        [Parameter(ParameterSetName = 'ByHardwareId', Mandatory = $true)]
        [ValidateNotNull()]
        [String[]] $HardwareId,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Alias('Session')]
        [ValidateNotNull()]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession
    )

    begin {
        $baseParams = @{}
        if ($PSBoundParameters.ContainsKey('CimSession')) {
            $baseParams['CimSession'] = $PSBoundParameters['CimSession']
        }
        $sc = [SfConfig]::new($baseParams)

        $configHash = @{}
    }

    process {

        $PartitionViewInfoList = $sc.GetPartitionViewInfoList()
        if ($PSBoundParameters.ContainsKey('Name')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            foreach ($interface in (Get-NetAdapter @baseParams -Name $Name -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('InterfaceDescription')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            foreach ($interface in (Get-NetAdapter @baseParams -InterfaceDescription $InterfaceDescription `
                    -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('HardwareId')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            $SolarflareAdapters = Get-PnpEntity @baseParams -HardwareId $HardwareId -PresentOnly
            if (!$SolarflareAdapters) {
                # No Adapters Found
                Write-Error "No Solarflare adapter(s) found with HardwareId:$HardwareId"
                return $Adapters
            }
            foreach($interface in $SolarflareAdapters) {
                $selectedSet.Add($interface.Name) | Out-Null
            }
        }
        else {
            $selectedSet = $null
        }
        $instances = $sc.FilterPartitionsByName($PartitionViewInfoList, $null, $selectedSet)

        foreach($instance in $instances) {

            # Get settings from dynamic config partition view
            $matchedSettings = $sc.ReadTLV($sc.GetDynCfgView($instance, 'Global Dynamic Config'))

            if ($matchedSettings) {
                if ($configHash.Contains($instance.InstanceName)) {
                    $globalSettings = $configHash[$instance.InstanceName]
                }
                else {
                    $globalSettings = [PSCustomObject] @{
                        PSTypeName = 'Solarflare.GlobalConfiguration'
                        InterfaceDescription = $instance.InstanceName
                        PortMode = $null
                        FirmwareVariant = $null
                        AllowDowngradeToLegacyFirmware = $null
                    }
                }
                # Look up device ID to allow family-specific strings
                $PortModeMap_family = $sc.LookupFamilyPortMap($instance.InstanceName)
                if ($matchedSettings.Contains($sc.GlobalDynCfgTagMap['Global Port Mode'])) {
                    [UInt32]$PortModeValue = ($matchedSettings[$sc.GlobalDynCfgTagMap['Global Port Mode']])[0]
                    # Output family-specific rendering if available
                    $globalSettings.PortMode = $sc.ReverseLookup($PortModeMap_family, $PortModeValue)
                    if ($globalSettings.PortMode -eq [String]::Empty) {
                        $globalSettings.PortMode = $sc.ReverseLookup($sc.PortModeMap, $PortModeValue)
                    }
                }
                if ($matchedSettings.Contains($sc.GlobalDynCfgTagMap['Firmware Options'])) {
                    $globalSettings.FirmwareVariant = $sc.ReverseLookup($sc.FirmwareVariantMap,
                        ($matchedSettings[$sc.GlobalDynCfgTagMap['Firmware Options']])[0])
                }
                if ($matchedSettings.Contains($sc.GlobalDynCfgTagMap['Bundle Update Disabled'])) {
                    $globalSettings.AllowDowngradeToLegacyFirmware = $sc.ReverseLookup($sc.BooleanFlagMap, $true)
                }
                if (-not $configHash.Contains($instance.InstanceName)) {
                    $configHash.Add($instance.InstanceName, $globalSettings)
                }
            }
        }
    }

    end {
        $configHash.Values
    }
}

function Set-NetAdapterGlobalConfiguration() {
    <#
        .SYNOPSIS
        Set global configuration settings for Solarflare NICs.
        .DESCRIPTION
        Changes the settings common to all ports of Solarflare NICs.
        .PARAMETER Name
        Specifies the network adapter by name.
        .PARAMETER InterfaceDescription
        Specifies the network adapter by interface description.
        .PARAMETER HardwareId
        Specifies network adapters by Windows HardwareId match.
        .PARAMETER Clear
        Clears the global configuration to the default settings. Individual settings may be cleared by providing an
        empty string ('') value.
        .PARAMETER PortMode
        Specifies the global port mode configuration at power-up.
        The valid values for this setting depend on the series and model of the NIC:
          X2522: Default, [1x10/25G][1x10/25G]*
          X2541: Default, [4x10/25G], [2x50G], [1x100G]*
          X2542: Default, [4x10/25G], [2x10/25G][2x10/25G], [2x50G], [1x50G][1x50G]*, [1x100G]
          X2552: Default, [1x10/25G][1x10/25G]*
          X2562: Default, [1x10/25G][1x10/25G]*
          SFN8042: Default, [1x40G][1x40G]*, [4x10G], [2x10G][2x10G]
          SFN8522: Default, [1x10G][1x10G]*
          SFN8542: Default, [1x40G][1x40G]*, [4x10G], [2x10G][2x10G]
          SFN8722: Default, [1x10G][1x10G]*
        The mode annotated with * is the Default port mode for that model.
        Note that MAC address assignments may change after altering this setting.
        .PARAMETER FirmwareVariant
        Specifies the global NIC firmware variant to enable at power-up. Possible values:
            Auto
            Full feature
            Ultra low latency
        .PARAMETER AllowDowngradeToLegacyFirmware
        Specified to allow downgrades to legacy firmware images. Possible values:
            Enabled
            Disabled
        .PARAMETER CimSession
        Enter a computer name or a session object, such as the output of a New-CimSession or Get-CimSession cmdlet.
        The default is the current session on the local computer.
        .EXAMPLE
        Set-SfNetAdapterGlobalConfiguration -PortMode Default
        Set the port mode configuration. The valid values for this setting depend on the series and model of the NIC.
        .EXAMPLE
        Set-SfNetAdapterGlobalConfiguration -FirmwareVariant Auto
        Set the firmware variant configuration. The valid values for this setting depend on the series and model of the NIC.
        .EXAMPLE
        Set-SfNetAdapterGlobalConfiguration -Clear
        Clears the global configuration to the default settings.
    #>
    [cmdletBinding(PositionalBinding=$false, SupportsShouldProcess = $true)]
    param(
        [Parameter(ParameterSetName = 'ByName')]
        [Alias('ifAlias InterfaceAlias')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $Name,

        [Parameter(ParameterSetName = 'ByDescription', Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias('ifDesc')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $InterfaceDescription,

        [Parameter(ParameterSetName = 'ByHardwareId', Mandatory = $true)]
        [String[]] $HardwareId,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [switch] $Clear,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [ValidateNotNull()]
        [String] $PortMode,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [ValidateNotNull()]
        [String] $FirmwareVariant,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [ValidateNotNull()]
        [String] $AllowDowngradeToLegacyFirmware,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Alias('Session')]
        [ValidateNotNull()]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession
    )

    begin {
        $baseParams = @{}
        if ($PSBoundParameters.ContainsKey('CimSession')) {
            $baseParams['CimSession'] = $PSBoundParameters['CimSession']
        }
        $sc = [SfConfig]::new($baseParams)
    }

    process {

        $PartitionViewInfoList = $sc.GetPartitionViewInfoList()
        if ($PSBoundParameters.ContainsKey('Name')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            foreach ($interface in (Get-NetAdapter @baseParams -Name $Name -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('InterfaceDescription')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            foreach ($interface in (Get-NetAdapter @baseParams -InterfaceDescription $InterfaceDescription `
                    -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('HardwareId')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            $SolarflareAdapters = Get-PnpEntity @baseParams -HardwareId $HardwareId -PresentOnly
            if (!$SolarflareAdapters) {
                # No Adapters Found
                Write-Error "No Solarflare adapter(s) found with HardwareId:$HardwareId"
                return $Adapters
            }
            foreach($interface in $SolarflareAdapters) {
                $selectedSet.Add($interface.Name) | Out-Null
            }
        }
        else {
            $selectedSet = $null
        }
        $instances = $sc.FilterPartitionsByName($PartitionViewInfoList, $null, $selectedSet)

        foreach($instance in $instances) {

            # Get settings from dynamic config partition view
            $view = $sc.GetDynCfgView($instance, 'Global Dynamic Config')
            if ($null -ne $view) {
                $matchedSettings = $sc.ReadTLV($view)
                $extraActions = 0

                if ($Clear) {
                    $view =  $sc.RemoveTLV($view, $sc.GlobalDynCfgTagMap['Global Port Mode'])
                    $view =  $sc.RemoveTLV($view, $sc.GlobalDynCfgTagMap['Firmware Options'])
                    $view =  $sc.RemoveTLV($view, $sc.GlobalDynCfgTagMap['Bundle Update Disabled'])
                    # MC reboot needed on any change to legacy firmware mode
                    $extraActions = $extraActions -bOR 0x1
                }

                if ($PSBoundParameters.ContainsKey('PortMode')) {
                    $tagId = $sc.GlobalDynCfgTagMap['Global Port Mode']
                    if ($PortMode) {
                        $PortModeMap_family = $sc.LookupFamilyPortMap($instance.InstanceName)
                        $val = $PortModeMap_family[$PortMode]
                        if ($null -eq $val) {
                            $val = $sc.PortModeMap[$PortMode]
                        }
                        if ($null -eq $val) {
                            $legacyVal = $sc.PortModeMap_Legacy[$PortMode]
                            # Check legacy terminology entry is supported by this family
                            if ($sc.ReverseLookup($PortModeMap_family, $legacyVal)) {
                                $val = $legacyVal
                            }
                        }
                        if ($null -eq $val) {
                            Write-Error 'Unrecognised Port Mode'
                        } else {
                            $view = $sc.UpdateTLV([UInt32[]] $view, $tagId, @([UInt32]$val))
                        }
                    } else {
                        $view =  $sc.RemoveTLV($view, $tagId)
                    }
                }
                if ($PSBoundParameters.ContainsKey('FirmwareVariant')) {
                    $tagId = $sc.GlobalDynCfgTagMap['Firmware Options']
                    if ($FirmwareVariant) {
                        $val = $sc.FirmwareVariantMap[$FirmwareVariant]
                        if ($null -eq $val) {
                            Write-Error 'Unrecognised Firmware Variant'
                        } else {
                            $view = $sc.UpdateTLV([UInt32[]] $view, $tagId, @([UInt32] $val))
                        }
                    } else {
                        $view =  $sc.RemoveTLV($view, $tagId)
                    }
                }
                if ($PSBoundParameters.ContainsKey('AllowDowngradeToLegacyFirmware')) {
                    $tagId = $sc.GlobalDynCfgTagMap['Bundle Update Disabled']
                    # MC reboot needed on any change to legacy firmware mode
                    $extraActions = $extraActions -bOR 0x1
                    if ($AllowDowngradeToLegacyFirmware -and
                        $sc.BooleanFlagMap[$AllowDowngradeToLegacyFirmware]) {
                        $view = $sc.UpdateTLV([UInt32[]] $view, $tagId, @())
                    } else {
                        $view =  $sc.RemoveTLV($view, $tagId)
                    }
                }
                # update the relevant settings
                $sc.SetDynCfgView([Partition]$instance, 'Global Dynamic Config', [UInt32[]] $view,
                    $extraActions)
            }
        }
    }

    end {
    }
}

function Set-NetAdapterGlobalPrivileges(){
    <#
        .SYNOPSIS
        Set global privilege settings for Solarflare NICs.
        .DESCRIPTION
        Changes the privilege settings common to all ports of Solarflare NICs.
        .PARAMETER Name
        Specifies the network adapter by name.
        .PARAMETER InterfaceDescription
        Specifies the network adapter by interface description.
        .PARAMETER HardwareId
        Specifies network adapters by Windows HardwareId match.
        .PARAMETER Clear
        Clears the global privileges to the default settings. Individual settings may be cleared by providing an
        empty string ('') value.
        .PARAMETER Link
        Possible values:
            Enabled
            Disabled
        .EXAMPLE
        Get-NetAdapter | Set-SfNetAdapterGlobalPrivileges -Link Enabled
    #>
    [cmdletBinding(PositionalBinding=$false,ConfirmImpact='Low')]
    param(

        [Parameter(ParameterSetName = 'ByName')]
        [Alias('ifAlias InterfaceAlias')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [object[]] $Name,

        [Parameter(ParameterSetName = 'ByDescription', Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias('ifDesc')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [object[]] $InterfaceDescription,

        [Parameter(ParameterSetName = 'ByHardwareId', Mandatory = $true)]
        [String[]] $HardwareId,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [switch] $Clear,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [string] $Link,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Alias('Session')]
        [ValidateNotNull()]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession
    )

    begin {
        $baseParams = @{}
        if ($PSBoundParameters.ContainsKey('CimSession')) {
            $baseParams['CimSession'] = $PSBoundParameters['CimSession']
        }
        $sc = [SfConfig]::new($baseParams)
    }

    process {

        $PartitionViewInfoList = $sc.GetPartitionViewInfoList()
        if($PSBoundParameters.ContainsKey('Name')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[string]
            foreach ($interface in (Get-NetAdapter @baseParams -Name $Name)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('InterfaceDescription')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            foreach ($interface in (Get-NetAdapter @baseParams -InterfaceDescription $InterfaceDescription `
                    -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('HardwareId')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            $SolarflareAdapters = Get-PnpEntity @baseParams -HardwareId $HardwareId -PresentOnly
            if (!$SolarflareAdapters) {
                # No Adapters Found
                Write-Error "No Solarflare adapter(s) found with HardwareId:$HardwareId"
                return $Adapters
            }
            foreach($interface in $SolarflareAdapters) {
                $selectedSet.Add($interface.Name) | Out-Null
            }
        }
        else {
            $selectedSet = $null
        }
        $instances = $sc.FilterPartitionsByName($PartitionViewInfoList, $null, $selectedSet)

        foreach($instance in $instances) {

            # Get settings from dynamic config partition view
            $view = $sc.GetDynCfgView($instance, "Global Dynamic Config")

            if ($null -ne $view) {
                $extraActions = 0
                $matchedSettings = $sc.ReadTLV($view)

                if ($Clear) {
                    $view =  $sc.RemoveTLV($view, $sc.GlobalDynCfgTagMap['Privilege Mask Add'])
                    $view =  $sc.RemoveTLV($view, $sc.GlobalDynCfgTagMap['Privilege Mask Rem'])
                    # MC reboot is needed on any change to privileges
                    $extraActions = $extraActions -bOR 0x1
                }
                elseif ($matchedSettings) {
                    $addTagId = $sc.GlobalDynCfgTagMap['Privilege Mask Add']
                    if($matchedSettings[$addTagId]) {
                        [uint32]$addMask = $matchedSettings[$addTagId][0]
                    }
                    else {
                        [uint32]$addMask = 0
                    }
                    $removeTagId = $sc.GlobalDynCfgTagMap['Privilege Mask Rem']
                    if($matchedSettings[$removeTagId]) {
                        [uint32]$removeMask = $matchedSettings[$removeTagId][0]
                    }
                    else {
                        [uint32]$removeMask = 0
                    }
                    if ($PSBoundParameters.ContainsKey('Link')) {
                        # MC reboot is needed on any change to privileges
                        $extraActions = $extraActions -bOR 0x1
                        if ($Link) {
                            if ($Link -eq 'Enabled') {
                                $addMask = $addMask -bor $sc.GlobalPrivilegesMap['Link']
                                $removeMask = $removeMask -band (-bnot $sc.GlobalPrivilegesMap['Link'])
                            }
                            elseif ($Link -eq "Disabled") {
                                $addMask = $addMask -band (-bnot $sc.GlobalPrivilegesMap['Link'])
                                $removeMask = $removeMask -bor $sc.GlobalPrivilegesMap['Link']
                            }
                            else {
                                Write-Error 'Unrecognised Link setting'
                            }
                        }
                        else {
                            $addMask = $addMask -band (-bnot $sc.GlobalPrivilegesMap['Link'])
                            $removeMask = $removeMask -band (-bnot $sc.GlobalPrivilegesMap['Link'])
                        }
                    }
                    if ($addMask) {
                        $view = $sc.UpdateTLV([UInt32[]] $view, $addTagId, @([UInt32] $addMask))
                    }
                    else {
                        $view =  $sc.RemoveTLV($view, $addTagId)
                    }
                    if ($removeMask) {
                        $view = $sc.UpdateTLV([UInt32[]] $view, $removeTagId, @([UInt32] $removeMask))
                    }
                    else {
                        $view =  $sc.RemoveTLV($view, $removeTagId)
                    }
                }
                # Update the relevant settings
                $sc.SetDynCfgView([Partition]$instance, 'Global Dynamic Config', [UInt32[]] $view, $extraActions)
            }
        }
    }

    end {
    }
}

function Set-NetAdapterSwitchConfiguration(){
    <#
        .SYNOPSIS
        Set global privilege settings for Solarflare NICs.
        .DESCRIPTION
        Changes the privilege settings common to all ports of Solarflare NICs.
        .PARAMETER Name
        Specifies the network adapter by name.
        .PARAMETER InterfaceDescription
        Specifies the network adapter by interface description.
        .PARAMETER HardwareId
        Specifies network adapters by Windows HardwareId match.
        .PARAMETER Clear
        Clears the global privileges to the default settings. Individual settings may be cleared by providing an
        empty string ('') value.
        .PARAMETER VlanTags
        List of VLAN tags to assign to the PFs presented on this port.
        .PARAMETER PfCount
        Number of PCIe Physical Functions to be presented on this port. Maximum 16 PFs per NIC. Possible values: 1..16
        .PARAMETER MsixLimit
        Maximum number of MSIX interrupts assigned to the PFs presented on this port.
        .EXAMPLE
        Get-NetAdapter | Set-SfNetAdapterSwitchConfiguration -PfCount 2
    #>
    [cmdletBinding(PositionalBinding=$false,ConfirmImpact='Low')]
    param(

        [Parameter(ParameterSetName = 'ByName')]
        [Alias('ifAlias InterfaceAlias')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [object[]] $Name,

        [Parameter(ParameterSetName = 'ByDescription', Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias('ifDesc')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [object[]] $InterfaceDescription,

        [Parameter(ParameterSetName = 'ByHardwareId', Mandatory = $true)]
        [String[]] $HardwareId,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [switch] $Clear,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [String[]] $VlanTags,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [string] $PfCount,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [String[]] $MsixLimit,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Alias('Session')]
        [ValidateNotNull()]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession
    )

    begin {
        $baseParams = @{}
        if ($PSBoundParameters.ContainsKey('CimSession')) {
            $baseParams['CimSession'] = $PSBoundParameters['CimSession']
        }
        $sc = [SfConfig]::new($baseParams)
    }

    process {

        $PartitionViewInfoList = $sc.GetPartitionViewInfoList()
        if($PSBoundParameters.ContainsKey('Name')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[string]
            foreach ($interface in (Get-NetAdapter @baseParams -Name $Name)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('InterfaceDescription')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            foreach ($interface in (Get-NetAdapter @baseParams -InterfaceDescription $InterfaceDescription `
                    -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('HardwareId')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            $SolarflareAdapters = Get-PnpEntity @baseParams -HardwareId $HardwareId -PresentOnly
            if (!$SolarflareAdapters) {
                # No Adapters Found
                Write-Error "No Solarflare adapter(s) found with HardwareId:$HardwareId"
                return $Adapters
            }
            foreach($interface in $SolarflareAdapters) {
                $selectedSet.Add($interface.Name) | Out-Null
            }
        } else {
            $selectedSet = $null
        }
        $instances = $sc.FilterPartitionsByName($PartitionViewInfoList, $null, $selectedSet)

        foreach($instance in $instances) {

            # Get settings from dynamic config partition view
            $view = $sc.GetDynCfgView($instance, "Port Dynamic Config")

            if ($null -ne $view) {
                $extraActions = 0
                $matchedSettings = $sc.ReadTLV($view)

                if ($Clear) {
                    $view =  $sc.RemoveTLV($view, $sc.PortDynCfgTagMap['VSwitch Type'])
                    for ($pfIndex = 0; $pfIndex -lt 16; $pfIndex++) {
                        $tagId = $sc.PortDynCfgTagMap['Pf Pcie Config'] + $pfIndex
                        if ($matchedSettings.Contains($tagId)) {
                            $view = $sc.RemoveTLV($view, $tagId)
                        }
                    }
                    # To be safe a cold reboot is needed on any change to switch mode
                    $extraActions = $extraActions -bOR 0x8
                }
                elseif ($matchedSettings) {
                    [UInt32]$vswitchType = 0 # NONE
                    if ($PSBoundParameters.ContainsKey('PfCount')) {
                        if ($PfCount) {
                            [int] $intCount = 0
                            if ((![int]::TryParse($PfCount, [ref]$intCount)) -or
                                (($intCount -lt 1) -or ($intCount -gt 16))) {
                                Write-Error 'Out of bounds PfCount setting'
                            }
                            else {
                                # Create tags up to the count
                                for ($pfIndex = 0; $pfIndex -lt $intCount; $pfIndex++) {
                                    $tagId = $sc.PortDynCfgTagMap['Pf Pcie Config'] + $pfIndex
                                    if (!$matchedSettings.Contains($tagId))
                                    {
                                        $view = $sc.UpdateTLVBytes($view, $tagId, @(
                                            [byte]'0x00', # [vfs_total:8]
                                            [byte]'0x00', # [port_allocation:8]
                                            [byte]'0xFF', [byte]'0xFF', # [vectors_per_pf:16]
                                            [byte]'0xFF', [byte]'0xFF', # [vectors_per_vf:16]
                                            [byte]'0x08', # [pf_bar0_aperture:8]
                                            [byte]'0x17', # [pf_bar2_aperture: 8]
                                            [byte]'0x14', # [vf_bar0_aperture: 8]
                                            [byte]'0xFF', # [vf_base: 8]
                                            [byte]'0xFF', [byte]'0xFF', # [supp_pagesz:16]
                                            [byte]'0xFF', [byte]'0xFF' # [msix_vec_base:16]
                                            ))
                                    }
                                }
                                # Delete any surplus tags
                                for ($pfIndex = $intCount; $pfIndex -lt 16; $pfIndex++) {
                                    $tagId = $sc.PortDynCfgTagMap['Pf Pcie Config'] + $pfIndex
                                    if ($matchedSettings.Contains($tagId)) {
                                        $view = $sc.RemoveTLV($view, $tagId)
                                    }
                                }
                            }
                        }
                        else {
                            for ($pfIndex = 0; $pfIndex -lt 16; $pfIndex++) {
                                $tagId = $sc.PortDynCfgTagMap['Pf Pcie Config'] + $pfIndex
                                if ($matchedSettings.Contains($tagId)) {
                                    $view = $sc.RemoveTLV($view, $tagId)
                                }
                            }
                        }
                    }
                    # Reload and patch Pf Pcie Config tags
                    $matchedSettings = $sc.ReadTLV($view)
                    if ($PSBoundParameters.ContainsKey('MsixLimit')) {

                        # To be safe a cold reboot is needed on any change to switch mode
                        $extraActions = $extraActions -bOR 0x8

                        if ($MsixLimit) {
                            $pfIndex = 0
                            foreach ($limit in $MsixLimit) {
                                [UInt16]$uintLimit = 0
                                $tagId = $sc.PortDynCfgTagMap['Pf Pcie Config'] + $pfIndex
                                if ($limit) {
                                    if ($limit -eq 'Default') {
                                        $uintLimit = [UInt16]'0xFFFF'
                                    }
                                    else {
                                        $uintLimit = [UInt16]$limit
                                        if (($uintLimit -lt 8) -or ($uintLimit -gt 1024)) {
                                            Write-Warning "Invalid MsixLimit $uintLimit"
                                            break
                                        }
                                    }
                                }
                                else {
                                    $uintLimit = [UInt16]'0xFFFF'
                                }
                                if ($matchedSettings.Contains($tagId)) {
                                    [byte] $hiByte = ($uintLimit -shr 8) -band [byte]'0xFF'
                                    [byte] $loByte = $uintLimit -band [byte]'0xFF'
                                    $view = $sc.UpdateTLVBytes($view, $tagId, @(
                                        [byte]'0x00', # [vfs_total:8]
                                        [byte]'0x00', # [port_allocation:8]
                                        $loByte, $hiByte, # [vectors_per_pf:16]
                                        [byte]'0xFF', [byte]'0xFF', # [vectors_per_vf:16]
                                        [byte]'0x08', # [pf_bar0_aperture:8]
                                        [byte]'0x17', # [pf_bar2_aperture: 8]
                                        [byte]'0x14', # [vf_bar0_aperture: 8]
                                        [byte]'0xFF', # [vf_base: 8]
                                        [byte]'0xFF', [byte]'0xFF', # [supp_pagesz:16]
                                        [byte]'0xFF', [byte]'0xFF' # [msix_vec_base:16]
                                        ))
                                }
                                $pfIndex++
                            }
                        }
                        else {
                            $pfIndex = 0
                        }
                        # Clear remaining MsixLimit
                        while ($pfIndex -lt 16) {
                            $tagId = $sc.PortDynCfgTagMap['Pf Pcie Config'] + $pfIndex
                            if ($matchedSettings.Contains($tagId)) {
                                $view = $sc.UpdateTLVBytes($view, $tagId, @(
                                    [byte]'0x00', # [vfs_total:8]
                                    [byte]'0x00', # [port_allocation:8]
                                    [byte]'0xFF', [byte]'0xFF', # [vectors_per_pf:16]
                                    [byte]'0xFF', [byte]'0xFF', # [vectors_per_vf:16]
                                    [byte]'0x08', # [pf_bar0_aperture:8]
                                    [byte]'0x17', # [pf_bar2_aperture: 8]
                                    [byte]'0x14', # [vf_bar0_aperture: 8]
                                    [byte]'0xFF', # [vf_base: 8]
                                    [byte]'0xFF', [byte]'0xFF', # [supp_pagesz:16]
                                    [byte]'0xFF', [byte]'0xFF' # [msix_vec_base:16]
                                    ))
                            }
                            $pfIndex++
                        }
                    }

                    if ($PSBoundParameters.ContainsKey('VlanTags')) {
                        $vlanSet = New-Object System.Collections.Generic.HashSet[UInt32]

                        # To be safe a cold reboot is needed on any change to switch mode
                        $extraActions = $extraActions -bOR 0x8

                        if ($VlanTags) {
                            $pfIndex = 0
                            foreach ($VlanTag in $VlanTags) {
                                $tagId = $sc.PortDynCfgTagMap['VPort VLan Tag'] + $pfIndex
                                if ($VlanTag) {
                                    [UInt32]$uintTag = $VlanTag
                                    if ($uintTag -gt 4094) {
                                        Write-Error "Invalid VlanTag $uintTag"
                                        $pfIndex = 0
                                        $vlanSet.Clear()
                                        break
                                    }
                                    if ($vlanSet.Contains($uintTag)) {
                                        Write-Error "Duplicate VlanTag $uintTag"
                                        $pfIndex = 0
                                        $vlanSet.Clear()
                                        break
                                    }
                                    $vlanSet.Add($uintTag) | Out-Null
                                    $view = $sc.UpdateTLV($view, $tagId, @($uintTag))
                                }
                                else {
                                    $view = $sc.RemoveTLV($view, $tagId)
                                }
                                $pfIndex++
                            }
                        }
                        else {
                            $pfIndex = 0
                        }

                        # Clear remaining VlanTags
                        while ($pfIndex -lt 16) {
                            $tagId = $sc.PortDynCfgTagMap['VPort VLan Tag'] + $pfIndex
                            $view = $sc.RemoveTLV($view, $tagId)
                            $pfIndex++
                        }
                    }

                    # Derive VSwitch Type
                    $matchedSettings = $sc.ReadTLV($view)
                    [int] $intPfCount = 0
                    [int] $intVlanCount = 0
                    [Boolean] $boolVlanMismatched = $false
                    for ($pfIndex = 0; $pfIndex -lt 16; $pfIndex++) {
                        $tagId = $sc.PortDynCfgTagMap['Pf Pcie Config'] + $pfIndex
                        $hasPfCfg = $matchedSettings.Contains($tagId)
                        if ($hasPfCfg) {
                            $intPfCount++
                        }
                        $tagId = $sc.PortDynCfgTagMap['VPort VLan Tag'] + $pfIndex
                        $hasVlanTag = $matchedSettings.Contains($tagId)
                        if ($hasVlanTag) {
                            $intVlanCount++
                        }
                        # Detect Vlan tag mismatches
                        if ($hasPfCfg -bxor $hasVlanTag) {
                            $boolVlanMismatched = $true
                        }
                    }
                    # Update switch mode
                    if ($intPfCount -gt 1) {
                        [UInt32]$vswitchType = 4 # MUX
                    }
                    if ($intVlanCount -gt 0) {
                        if ($boolVlanMismatched) {
                            if ($VlanTags) {
                                Write-Error "VlanTags inconsistent with PfCount"
                            }
                            else {
                                Write-Warning "VlanTags cleared as they do not match PfCount"
                            }
                            for ($pfIndex = 0; $pfIndex -lt 16; $pfIndex++) {
                                $tagId = $sc.PortDynCfgTagMap['VPort VLan Tag'] + $pfIndex
                                $view = $sc.RemoveTLV($view, $tagId)
                            }
                        }
                        else {
                            $vswitchType = 1 # VLAN
                        }
                    }
                    # TODO VF modes

                    $tagId = $sc.PortDynCfgTagMap['VSwitch Type']
                    if ($vswitchType -gt 0) {
                        $view = $sc.UpdateTLV($view, $tagId, @([UInt32]$vswitchType))
                    }
                    else {
                        $view = $sc.RemoveTLV($view, $tagId)
                    }
                }

                # Update the relevant settings
                $sc.SetDynCfgView([Partition]$instance, 'Port Dynamic Config', $view, $extraActions)
            }
        }
    }

    end {
    }
}


function Invoke-NetAdapterConfiguration() {
    <#
        .SYNOPSIS
        Solarflare configuration utilities
        .DESCRIPTION
        Configuration tools for Solarflare-specific settings.
        .PARAMETER Name
        Specifies the network adapter by name.
        .PARAMETER InterfaceDescription
        Specifies the network adapter by interface description.
        .PARAMETER CimSession
        Enter a computer name or a session object, such as the output of a New-CimSession or Get-CimSession cmdlet.
        The default is the current session on the local computer.
        .PARAMETER Clear
        Clears the configuration to the default settings.
        .PARAMETER PortMode
        Specifies the global port mode configuration at power-up.
        The valid values for this setting depend on the series and model of the NIC:
          X2522: Default, [1x10/25G][1x10/25G]*
          X2541: Default, [4x10/25G], [2x50G], [1x100G]*
          X2542: Default, [4x10/25G], [2x10/25G][2x10/25G], [2x50G], [1x50G][1x50G]*, [1x100G]
          X2552: Default, [1x10/25G][1x10/25G]*
          X2562: Default, [1x10/25G][1x10/25G]*
          SFN8042: Default, [1x40G][1x40G]*, [4x10G], [2x10G][2x10G]
          SFN8522: Default, [1x10G][1x10G]*
          SFN8542: Default, [1x40G][1x40G]*, [4x10G], [2x10G][2x10G]
          SFN8722: Default, [1x10G][1x10G]*
        The mode annotated with * is the Default port mode for that model.
        Note that MAC address assignments may change after altering this setting.
        .PARAMETER FirmwareVariant
        Specifies the global NIC firmware variant to enable at power-up. Possible values:
            Auto
            Full feature
            Ultra low latency
        .PARAMETER VlanTags
        List of VLAN tags to assign to the PFs presented on this port.
        .PARAMETER PfCount
        Number of PCIe Physical Functions to be presented on this port. Maximum 16 PFs per NIC. Possible values: 1..16
        .PARAMETER MsixLimit
        Specifies the maximum number of MSI-X interrupts each PF may use. Possible values: 8,16,32,64,128,256,512,1024
        .PARAMETER Partitioning
        Apply a configuration compatible with multiple PF presented on ports of this NIC. Possible values:
            Enabled
            Disabled
        .OUTPUTS
        Solarflare.Configuration
        .EXAMPLE
        Invoke-SfNetAdapterConfiguration
        Reports the current configuration of Solarflare network adapters.
        .EXAMPLE
        SfConfig -Clear
        Clears the configuration to the default settings.
        .LINK
        Get-SfNetAdapterGlobalConfiguration
        Set-SfNetAdapterGlobalConfiguration
    #>
    [Alias('Config')]
    [CmdletBinding(PositionalBinding = $false, SupportsShouldProcess = $true)]
    [OutputType('Solarflare.Configuration', ParameterSetName = 'ByName')]
    [OutputType('Solarflare.Configuration', ParameterSetName = 'ByDescription')]
    param(
        [Parameter(ParameterSetName = 'ByName')]
        [Alias('ifAlias InterfaceAlias')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $Name,

        [Parameter(ParameterSetName = 'ByDescription', Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias('ifDesc')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $InterfaceDescription,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Alias('Session')]
        [ValidateNotNull()]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [switch] $Clear,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [ValidateNotNull()]
        [String] $PortMode,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [ValidateNotNull()]
        [String] $FirmwareVariant,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [ValidateNotNull()]
        [String[]] $VlanTags,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [string] $PfCount,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [ValidateNotNull()]
        [String[]] $MsixLimit,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ValueFromPipelineByPropertyName = $true)]
        [ValidateNotNull()]
        [String] $Partitioning
    )

    begin {

        $baseParams = @{}
        if (-not $PSBoundParameters.ContainsKey('InformationAction')) {
            $baseParams['InformationAction'] = 'Continue'
        }

        Write-Information 'Solarflare configuration utility' @baseParams
        if ($MyInvocation.MyCommand.Module) {
            Write-Information $MyInvocation.MyCommand.Module.Copyright @baseParams
            $version = $MyInvocation.MyCommand.Module.PrivateData.ModuleSemanticVersion
            Write-Verbose "SolarflareTools $version" @baseParams
        }

        if ($PSBoundParameters.ContainsKey('CimSession')) {
            $baseParams['CimSession'] = $PSBoundParameters['CimSession']
        }

        $configHash = @{}
    }

    process {

        # Make clone of bound parameters for children
        $Passthrough = @{} + $PSBoundParameters

        # Filter passthrough items for each sub-function
        $SetGlobalSettingsPassthrough = Filter-Hashtable $Passthrough 'PortMode', 'FirmwareVariant'
        $SetGlobalPrivilegesPassthrough = Filter-Hashtable $Passthrough @()
        $SetSwitchPassthrough = Filter-Hashtable $Passthrough 'VlanTags', 'PfCount', 'MsixLimit'
        $SetPartitioningPassthrough = Filter-Hashtable $Passthrough 'Partitioning'
        if ($SetPartitioningPassthrough.Count -gt 0) {

            if($Partitioning -eq 'Enabled') {
                if( -not $Passthrough.ContainsKey('FirmwareVariant')) {
                    $SetGlobalSettingsPassthrough.Add('FirmwareVariant', "Full feature")
                } else {
                    $SetGlobalSettingsPassthrough.Remove('FirmwareVariant')
                    $SetGlobalSettingsPassthrough.Add('FirmwareVariant', "Full feature")
                }
                $SetGlobalPrivilegesPassthrough.Add('Link', "Enabled")
            } else {
                if( -not $Passthrough.ContainsKey('FirmwareVariant')) {
                    $SetGlobalSettingsPassthrough.Add('FirmwareVariant', "")
                }
                $SetGlobalPrivilegesPassthrough.Add('Link', "")
            }
        }

        $selectedSet = New-Object System.Collections.Generic.HashSet[String]
        if ($PSBoundParameters.ContainsKey('Name')) {
            foreach ($interface in (Get-NetAdapter @baseParams -Name $Name -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('InterfaceDescription')) {
            foreach ($interface in (Get-NetAdapter @baseParams -InterfaceDescription $InterfaceDescription `
                    -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        else {
            # Default to all Solarflare adapters
            if (Get-Command -CommandType Function "Get-NetAdapter" -errorAction SilentlyContinue) {
                foreach ($interface in Get-NetAdapter @baseParams) {
                    if ($interface.DriverProvider -eq 'Solarflare') {
                        $selectedSet.Add($interface.InterfaceDescription) | Out-Null
                    }
                }
            } else {
                $selectedSet = $null
            }
        }

        if ($Clear) {
            $scg = [SfConfig]::new($baseParams)
            $scg.ClearAll($selectedSet)
        }
        else {
            if ($selectedSet) {
                foreach ($interface in $selectedSet.GetEnumerator()) {
                    if ($SetGlobalSettingsPassthrough.Count -gt 0) {
                        Set-NetAdapterGlobalConfiguration @baseParams -InterfaceDescription $interface `
                            @SetGlobalSettingsPassthrough
                    }
                    if ($SetGlobalPrivilegesPassthrough.Count -gt 0) {
                        Set-NetAdapterGlobalPrivileges @baseParams -InterfaceDescription $interface `
                            @SetGlobalPrivilegesPassthrough
                    }
                    if ($SetSwitchPassthrough.Count -gt 0) {
                        Set-NetAdapterSwitchConfiguration @baseParams -InterfaceDescription $interface `
                            @SetSwitchPassthrough
                    }
                }
            } else {
                if ($SetGlobalSettingsPassthrough.Count -gt 0) {
                    Set-NetAdapterGlobalConfiguration @baseParams @SetGlobalSettingsPassthrough
                }
                if ($SetGlobalPrivilegesPassthrough.Count -gt 0) {
                    Set-NetAdapterGlobalPrivileges @baseParams @SetGlobalPrivilegesPassthrough
                }
                if ($SetSwitchPassthrough.Count -gt 0) {
                    Set-NetAdapterSwitchConfiguration @baseParams @SetSwitchPassthrough
                }
            }
        }
        $appendConfigs = {
            foreach($globalSettings in $globalSettingsList) {
                if (-not $configHash.ContainsKey($globalSettings.InterfaceDescription)) {
                    $configHash[$globalSettings.InterfaceDescription] = [PSCustomObject] @{
                        PSTypeName = 'Solarflare.Configuration'
                        InterfaceDescription = $globalSettings.InterfaceDescription
                        PortMode = $null
                        FirmwareVariant = $null
                        VlanTags = $null
                        PfCount = $null
                        MsixLimit = $null
                        Partitioning = $null
                    }
                }
                $configHash[$globalSettings.InterfaceDescription].PortMode = $globalSettings.PortMode
                $configHash[$globalSettings.InterfaceDescription].FirmwareVariant = $globalSettings.FirmwareVariant
            }
        }
        if ($selectedSet) {
            foreach ($interface in $selectedSet.GetEnumerator()) {
                $globalSettingsList = Get-NetAdapterGlobalConfiguration @baseParams -InterfaceDescription $interface
                $appendConfigs.invoke()
            }
        } else {
            $globalSettingsList = Get-NetAdapterGlobalConfiguration @baseParams
            $appendConfigs.invoke()
        }
        $appendGlobalPrivilegesConfigs = {
            foreach($globalPrivileges in $globalPrivilegesList) {
                if (-not $configHash.ContainsKey($globalPrivileges.InterfaceDescription)) {
                    $configHash[$globalPrivileges.InterfaceDescription] = [PSCustomObject] @{
                        PSTypeName = 'Solarflare.Configuration'
                        InterfaceDescription = $globalPrivileges.InterfaceDescription
                        PortMode = $null
                        FirmwareVariant = $null
                        VlanTags = $null
                        PfCount = $null
                        MsixLimit = $null
                        Partitioning = $null
                    }
                }
                if(($globalPrivileges.Link -eq "Enabled") -and
                   ($configHash[$globalPrivileges.InterfaceDescription].FirmwareVariant -eq "Full feature")) {
                    $configHash[$globalPrivileges.InterfaceDescription].Partitioning = "Enabled"
                } else {
                    $configHash[$globalPrivileges.InterfaceDescription].Partitioning = ""
                }
            }
        }
        if ($selectedSet) {
            foreach ($interface in $selectedSet.GetEnumerator()) {
                $globalPrivilegesList = Get-NetAdapterGlobalPrivileges @baseParams -InterfaceDescription $interface
                $appendGlobalPrivilegesConfigs.invoke()
            }
        } else {
            $globalPrivilegesList = Get-NetAdapterGlobalPrivileges @baseParams
            $appendGlobalPrivilegesConfigs.invoke()
        }

        $appendSwitchConfigs = {
            foreach($switchConfig in $switchConfigsList) {
                if (-not $configHash.ContainsKey($switchConfig.InterfaceDescription)) {
                    $configHash[$switchConfig.InterfaceDescription] = [PSCustomObject] @{
                        PSTypeName = 'Solarflare.Configuration'
                        InterfaceDescription = $switchConfig.InterfaceDescription
                        PortMode = $null
                        FirmwareVariant = $null
                        VlanTags = $null
                        PfCount = $null
                        MsixLimit = $null
                        Partitioning = $null
                    }
                }
                $configHash[$switchConfig.InterfaceDescription].VlanTags = $switchConfig.VlanTags
                $configHash[$switchConfig.InterfaceDescription].PfCount = $switchConfig.PfCount
                $configHash[$switchConfig.InterfaceDescription].MsixLimit = $switchConfig.MsixLimit

                if (($configHash[$switchConfig.InterfaceDescription].Partitioning -eq "") -and
                    ($switchConfig.PfCount -gt 1)) {
                    Write-Warning "For the current configuration on $($switchConfig.InterfaceDescription) the Partitioning setting is recommended."
                }
            }
        }
        if ($selectedSet) {
            foreach ($interface in $selectedSet.GetEnumerator()) {
                $switchConfigsList = Get-NetAdapterSwitchConfiguration @baseParams -InterfaceDescription $interface
                $appendSwitchConfigs.invoke()
            }
        } else {
            $switchConfigsList = Get-NetAdapterSwitchConfiguration @baseParams
            $appendSwitchConfigs.invoke()
        }
    }

    end {
        # Output full configuration similar to legacy SfBoot
        $configHash.Values
    }
}

# SIG # Begin signature block
# MIIefQYJKoZIhvcNAQcCoIIebjCCHmoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCB87vrV9DBDHKNY
# Wr9fLSrOTrwBcAadI5zjat8YY1i7B6CCGY0wggWKMIIEcqADAgECAhAL9isXqX/2
# 8aS6px6yF9fnMA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNV
# BAMTIkRpZ2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwHhcNMjAwOTA0
# MDAwMDAwWhcNMjMwODMxMTIwMDAwWjCBqDETMBEGCysGAQQBgjc8AgEDEwJHQjEd
# MBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xETAPBgNVBAUTCDA0NDQxMzg2
# MQswCQYDVQQGEwJHQjESMBAGA1UEBxMJQ2FtYnJpZGdlMR4wHAYDVQQKExVYaWxp
# bnggVGVjaG5vbG9neSBMdGQxHjAcBgNVBAMTFVhpbGlueCBUZWNobm9sb2d5IEx0
# ZDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALpCrVaJ0WUXy0vh2eDQ
# PbK2vwC51KJMF0vEbwtj501kbujnHRbd03C9K6kFw7crzLI1KI7sKqPep5bLjQfP
# mG3rdY1dS8d40yXQJLTiQWtlSkGSW2UIlhJdN9ASlwMPIqjbLrZlBbKsalyc/8Ry
# 9CayLQM1dJECX7MgRxz15fr04X4FbC2baJdrg6hgbJ9IDDuU5l7XVYXp1GkZFCPD
# S+92WMPTpb7LFFb+4KPULlF0Vmf3fJ6ZL8geqdCrVpADekGgj/EopsrIBvVy3Anr
# y5PgvVWl+GyYn+Xr9i3HxDkqrsJ9fZOuCWI1M8yyQE7trqPRCt+9bUwbpUSA7hES
# sWkCAwEAAaOCAekwggHlMB8GA1UdIwQYMBaAFI/ofvBtMmoABSPHcJdqOpD/a+rU
# MB0GA1UdDgQWBBQbN9po8ibTH5kEwgmurjm1ryenPTAmBgNVHREEHzAdoBsGCCsG
# AQUFBwgDoA8wDQwLR0ItMDQ0NDEzODYwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQM
# MAoGCCsGAQUFBwMDMHsGA1UdHwR0MHIwN6A1oDOGMWh0dHA6Ly9jcmwzLmRpZ2lj
# ZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwN6A1oDOGMWh0dHA6Ly9j
# cmw0LmRpZ2ljZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwSwYDVR0g
# BEQwQjA3BglghkgBhv1sAwIwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGln
# aWNlcnQuY29tL0NQUzAHBgVngQwBAzB+BggrBgEFBQcBAQRyMHAwJAYIKwYBBQUH
# MAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBIBggrBgEFBQcwAoY8aHR0cDov
# L2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0RVZDb2RlU2lnbmluZ0NBLVNI
# QTIuY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggEBAJGCCl1voKTA
# ml2M6QyubvxhbjOHzau7EL8YEHQgkBfarH0zrtOFXypqwELz219z9wdjUQ4czWEg
# MWCAusWIQpA47qFsrcFSjmvoa+AMYzCEMbkwXGGjquRTD/s61Zy6jh5ayPzxyj2+
# Ql61mIvDYiXhWv5BZuq/mS8YZGNXM1GwIDZK05gDup+NvIVVCoUa9A61KAJeXOyq
# d6yquSSaqW1HqD4Yg29YdxdF+nySo7cuI9LnefYofsNZ4PJJC2W7OtNgr770RTPz
# QrhJHRpJwfm5w2aUV0sO8KciQ+JySwKqZoO+WqxJ9q9JjUl/WY7qsFe3EcY+9vdK
# +dlK+QD24gowggZqMIIFUqADAgECAhADAZoCOv9YsWvW1ermF/BmMA0GCSqGSIb3
# DQEBBQUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgQ0EtMTAeFw0xNDEwMjIwMDAwMDBaFw0yNDEwMjIwMDAwMDBaMEcxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDElMCMGA1UEAxMcRGlnaUNlcnQg
# VGltZXN0YW1wIFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAKNkXfx8s+CCNeDg9sYq5kl1O8xu4FOpnx9kWeZ8a39rjJ1V+JLjntVaY1sC
# SVDZg85vZu7dy4XpX6X51Id0iEQ7Gcnl9ZGfxhQ5rCTqqEsskYnMXij0ZLZQt/US
# s3OWCmejvmGfrvP9Enh1DqZbFP1FI46GRFV9GIYFjFWHeUhG98oOjafeTl/iqLYt
# WQJhiGFyGGi5uHzu5uc0LzF3gTAfuzYBje8n4/ea8EwxZI3j6/oZh6h+z+yMDDZb
# esF6uHjHyQYuRhDIjegEYNu8c3T6Ttj+qkDxss5wRoPp2kChWTrZFQlXmVYwk/PJ
# YczQCMxr7GJCkawCwO+k8IkRj3cCAwEAAaOCAzUwggMxMA4GA1UdDwEB/wQEAwIH
# gDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIIBvwYDVR0g
# BIIBtjCCAbIwggGhBglghkgBhv1sBwEwggGSMCgGCCsGAQUFBwIBFhxodHRwczov
# L3d3dy5kaWdpY2VydC5jb20vQ1BTMIIBZAYIKwYBBQUHAgIwggFWHoIBUgBBAG4A
# eQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkAYwBhAHQA
# ZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBjAGUA
# IABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMAUABTACAA
# YQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkAIABBAGcA
# cgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBhAGIA
# aQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBhAHQA
# ZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMAZQAuMAsG
# CWCGSAGG/WwDFTAfBgNVHSMEGDAWgBQVABIrE5iymQftHt+ivlcNK2cCzTAdBgNV
# HQ4EFgQUYVpNJLZJMp1KKnkag0v0HonByn0wfQYDVR0fBHYwdDA4oDagNIYyaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0EtMS5jcmww
# OKA2oDSGMmh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RENBLTEuY3JsMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0xLmNydDANBgkqhkiG9w0BAQUF
# AAOCAQEAnSV+GzNNsiaBXJuGziMgD4CH5Yj//7HUaiwx7ToXGXEXzakbvFoWOQCd
# 42yE5FpA+94GAYw3+puxnSR+/iCkV61bt5qwYCbqaVchXTQvH3Gwg5QZBWs1kBCg
# e5fH9j/n4hFBpr1i2fAnPTgdKG86Ugnw7HBi02JLsOBzppLA044x2C/jbRcTBu7k
# A7YUq/OPQ6dxnSHdFMoVXZJB2vkPgdGZdA0mxA5/G7X1oPHGdwYoFenYk+VVFvC7
# Cqsc21xIJ2bIo4sKHOWV2q7ELlmgYd3a822iYemKC23sEhi991VUQAOSK2vCUcIK
# SK+w1G7g9BQKOhvjjz3Kr2qNe9zYRDCCBrwwggWkoAMCAQICEAPxtOFfOoLxFJZ4
# s9fYR1wwDQYJKoZIhvcNAQELBQAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMi
# RGlnaUNlcnQgSGlnaCBBc3N1cmFuY2UgRVYgUm9vdCBDQTAeFw0xMjA0MTgxMjAw
# MDBaFw0yNzA0MTgxMjAwMDBaMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdp
# Q2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNVBAMTIkRp
# Z2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCnU/oPsrUT8WTPhID8roA10bbXx6MsrBosrPGErDo1
# EjqSkbpX5MTJ8y+oSDy31m7clyK6UXlhr0MvDbebtEkxrkRYPqShlqeHTyN+w2xl
# JJBVPqHKI3zFQunEemJFm33eY3TLnmMl+ISamq1FT659H8gTy3WbyeHhivgLDJj0
# yj7QRap6HqVYkzY0visuKzFYZrQyEJ+d8FKh7+g+03byQFrc+mo9G0utdrCMXO42
# uoPqMKhM3vELKlhBiK4AiasD0RaCICJ2615UOBJi4dJwJNvtH3DSZAmALeK2nc4f
# 8rsh82zb2LMZe4pQn+/sNgpcmrdK0wigOXn93b89OgklAgMBAAGjggNYMIIDVDAS
# BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggr
# BgEFBQcDAzB/BggrBgEFBQcBAQRzMHEwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBJBggrBgEFBQcwAoY9aHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0SGlnaEFzc3VyYW5jZUVWUm9vdENBLmNydDCBjwYDVR0f
# BIGHMIGEMECgPqA8hjpodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRI
# aWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMECgPqA8hjpodHRwOi8vY3JsNC5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMIIBxAYD
# VR0gBIIBuzCCAbcwggGzBglghkgBhv1sAwIwggGkMDoGCCsGAQUFBwIBFi5odHRw
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9zc2wtY3BzLXJlcG9zaXRvcnkuaHRtMIIBZAYI
# KwYBBQUHAgIwggFWHoIBUgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAg
# AEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAg
# AGEAYwBjAGUAcAB0AGEAbgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBl
# AHIAdAAgAEMAUAAvAEMAUABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBu
# AGcAIABQAGEAcgB0AHkAIABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAg
# AGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAg
# AGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIABy
# AGUAZgBlAHIAZQBuAGMAZQAuMB0GA1UdDgQWBBSP6H7wbTJqAAUjx3CXajqQ/2vq
# 1DAfBgNVHSMEGDAWgBSxPsNpA/i/RwHUmCYaCALvY2QrwzANBgkqhkiG9w0BAQsF
# AAOCAQEAGTNKDIEzN9utNsnkyTq7tRsueqLi9ENCF56/TqFN4bHb6YHdnwHy5IjV
# 6f4J/SHB7F2A0vDWwUPC/ncr2/nXkTPObNWyGTvmLtbJk0+IQI7N4fV+8Q/GWVZy
# 6OtqQb0c1UbVfEnKZjgVwb/gkXB3h9zJjTHJDCmiM+2N4ofNiY0/G//V4BqXi3za
# bfuoxrI6Zmt7AbPN2KY07BIBq5VYpcRTV6hg5ucCEqC5I2SiTbt8gSVkIb7P7kIY
# Q5e7pTcGr03/JqVNYUvsRkG4Zc64eZ4IlguBjIo7j8eZjKMqbphtXmHGlreKuWEt
# k7jrDgRD1/X+pvBi1JlqpcHB8GSUgDCCBs0wggW1oAMCAQICEAb9+QOWA63qAArr
# Pye7uhswDQYJKoZIhvcNAQEFBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMb
# RGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4XDTA2MTExMDAwMDAwMFoXDTIx
# MTExMDAwMDAwMFowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IElu
# YzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQg
# QXNzdXJlZCBJRCBDQS0xMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
# 6IItmfnKwkKVpYBzQHDSnlZUXKnE0kEGj8kz/E1FkVyBn+0snPgWWd+etSQVwpi5
# tHdJ3InECtqvy15r7a2wcTHrzzpADEZNk+yLejYIA6sMNP4YSYL+x8cxSIB8HqIP
# kg5QycaH6zY/2DDD/6b3+6LNb3Mj/qxWBZDwMiEWicZwiPkFl32jx0PdAug7Pe2x
# QaPtP77blUjE7h6z8rwMK5nQxl0SQoHhg26Ccz8mSxSQrllmCsSNvtLOBq6thG9I
# hJtPQLnxTPKvmPv2zkBdXPao8S+v7Iki8msYZbHBc63X8djPHgp0XEK4aH631XcK
# J1Z8D2KkPzIUYJX9BwSiCQIDAQABo4IDejCCA3YwDgYDVR0PAQH/BAQDAgGGMDsG
# A1UdJQQ0MDIGCCsGAQUFBwMBBggrBgEFBQcDAgYIKwYBBQUHAwMGCCsGAQUFBwME
# BggrBgEFBQcDCDCCAdIGA1UdIASCAckwggHFMIIBtAYKYIZIAYb9bAABBDCCAaQw
# OgYIKwYBBQUHAgEWLmh0dHA6Ly93d3cuZGlnaWNlcnQuY29tL3NzbC1jcHMtcmVw
# b3NpdG9yeS5odG0wggFkBggrBgEFBQcCAjCCAVYeggFSAEEAbgB5ACAAdQBzAGUA
# IABvAGYAIAB0AGgAaQBzACAAQwBlAHIAdABpAGYAaQBjAGEAdABlACAAYwBvAG4A
# cwB0AGkAdAB1AHQAZQBzACAAYQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8AZgAgAHQA
# aABlACAARABpAGcAaQBDAGUAcgB0ACAAQwBQAC8AQwBQAFMAIABhAG4AZAAgAHQA
# aABlACAAUgBlAGwAeQBpAG4AZwAgAFAAYQByAHQAeQAgAEEAZwByAGUAZQBtAGUA
# bgB0ACAAdwBoAGkAYwBoACAAbABpAG0AaQB0ACAAbABpAGEAYgBpAGwAaQB0AHkA
# IABhAG4AZAAgAGEAcgBlACAAaQBuAGMAbwByAHAAbwByAGEAdABlAGQAIABoAGUA
# cgBlAGkAbgAgAGIAeQAgAHIAZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZIAYb9bAMV
# MBIGA1UdEwEB/wQIMAYBAf8CAQAweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzAB
# hhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9j
# YWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQw
# gYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdp
# Q2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwHQYDVR0OBBYEFBUA
# EisTmLKZB+0e36K+Vw0rZwLNMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3z
# bcgPMA0GCSqGSIb3DQEBBQUAA4IBAQBGUD7Jtygkpzgdtlspr1LPUukxR6tWXHvV
# DQtBs+/sdR90OPKyXGGinJXDUOSCuSPRujqGcq04eKx1XRcXNHJHhZRW0eu7NoR3
# zCSl8wQZVann4+erYs37iy2QwsDStZS9Xk+xBdIOPRqpFFumhjFiqKgz5Js5p8T1
# zh14dpQlc+Qqq8+cdkvtX8JLFuRLcEwAiR78xXm8TBJX/l/hHrwCXaj++wc4Tw3G
# XZG5D2dFzdaD7eeSDY2xaYxP+1ngIw/Sqq4AfO6cQg7PkdcntxbuD8O9fAqg7iwI
# VYUiuOsYGk38KiGtSTGDR5V3cdyxG0tLHBCcdxTBnU8vWpUIKRAmMYIERjCCBEIC
# AQEwgYAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMiRGlnaUNlcnQgRVYgQ29k
# ZSBTaWduaW5nIENBIChTSEEyKQIQC/YrF6l/9vGkuqceshfX5zANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCAUZpjzXhmF45A2U4+NR6A0zZwRcJE6nK3fUaWqUr27TjANBgkq
# hkiG9w0BAQEFAASCAQAfqbNLpl51VOlYE6CIHwr37q9oFjzyrZNYI9qTxOabBAMz
# 9OH3HHGVRRik/uWr2JVEq7bo1vwcMv1MiHgggbL7zm/tw5Q6tsl/6EQuPDGuYmfe
# rtjxFcjsNUsv0LPO3UyvKVXz/ADaaxoRA/cQcclyQmt37/AlI5MhDKIOnIEgBwBY
# nGUbXHyYkma3HJ/FFqtw8A086FBae0jq/Y7fgWtEuYKtN41T/t1WNFTxso/jsPE8
# uM92EhqOEBCXmjRjxUe/dOZ/+/+QocgMsY/gz9F3cN+ZeeaxumGBiZ7FnEGPXSda
# GKesPmunD2pkeNo/x0IF1CwUFr2fZ2L9145wKtz+oYICDzCCAgsGCSqGSIb3DQEJ
# BjGCAfwwggH4AgEBMHYwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0
# IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNl
# cnQgQXNzdXJlZCBJRCBDQS0xAhADAZoCOv9YsWvW1ermF/BmMAkGBSsOAwIaBQCg
# XTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0yMDEw
# MTkxMDMxMjdaMCMGCSqGSIb3DQEJBDEWBBRaujyQXO0Wcb5QtI9WfpCrtLgSUjAN
# BgkqhkiG9w0BAQEFAASCAQCfIdR+CBkwIsP7/4jcsUjM8ijAkKoLmlvXfaJGlLvy
# jYaOnITjlsYvSvjD+Ex3OGGQ0r70NXhWe2HBRRZpbpchjGE8YikvdwwLPkqqLmO1
# 0PE0ddrgYhA8e1unO6Ogf5Vpht2knEZ5jRTukm0hlhkGIEDzONPAd+lGg6CiQMGc
# z7EJm8T/yfsG1Kx88CrE9Z6ealToL6hbdUqQMZDKYyDoTpQUyodOnS+WIJ4ZPOdH
# sm8+ep0S6wewtqJloYphHFvanIVHfLGQ3gROBZg+6HzDD2CAbIy7ztGqMFZpiBol
# afnDDnYgNhkJkKsIu6yGZq46G7155/MJR2NY2m6ziA30
# SIG # End signature block
