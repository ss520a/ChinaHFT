<#
    Copyright (c) 2020 Xilinx, Inc. All rights reserved.
    Copyright (c) 2018-2019 Solarflare Communications Inc.
    Use is subject to license terms.
#>

<#
.SYNOPSIS
    DataSource
.DESCRIPTION
    File reader that searches for the file first in the Zip file in the
    directory, and then directly in the directory if that fails.
#>

#Requires -Version 5.1
#Requires -Modules CimCmdlets

class DataSource {

    [String] $BasePath = $null
    [String] $FilePath = $null
    [Boolean] $BaseIsZip = $false

    [System.IO.Stream] $stream = $null
    [System.IO.Compression.ZipArchive] $zip = $null

    DataSource([String] $BasePath, [String] $ZipName, [String] $FileName) {
        # Canonicalise the file path using Join-Path
        $ProcessedFileName = (Join-Path '.' $FileName).Substring(2)
        if(Test-Path -LiteralPath $BasePath -PathType Leaf) {
            $this.BasePath = $BasePath
            $this.FilePath = $ProcessedFileName
            $this.BaseIsZip = $true
        } elseif (Test-Path -LiteralPath $BasePath -PathType Container) {
            $Path = Join-Path $BasePath $ProcessedFileName
            if(Test-Path -LiteralPath $Path -PathType Leaf) {
                $this.BasePath = $BasePath
                $this.FilePath = $Path
                $this.BaseIsZip = $false
            } else {
                $this.BasePath = Join-Path $BasePath $ZipName
                $this.FilePath = $ProcessedFileName
                $this.BaseIsZip = $true
            }
        } else {
          # Fallback on relative path if BasePath is bad
          $this.BasePath = '.'
          $this.FilePath = $ProcessedFileName
          $this.BaseIsZip = $false
        }
    }

    [void] Open()
    {
        if($this.BaseIsZip) {
            $this.zip = [System.IO.Compression.ZipFile]::OpenRead($(Convert-Path -LiteralPath $this.BasePath))
            # Find the entry matching the canonicalised path
            $file = $this.zip.Entries | where-object { (Join-Path '.' $_.FullName).Substring(2) -eq $this.FilePath }
            $this.stream = $file.Open()
        } else {
            $this.stream = [System.IO.File]::OpenRead($(Convert-Path -LiteralPath $this.FilePath))
        }
    }

    hidden [Xml] ReadXml()
    {
        $reader = New-Object IO.StreamReader($this.stream)
        $raw = $reader.ReadToEnd()
        $reader.Close()
        return [Xml]$raw
    }

    hidden [Byte[]] ReadBytes()
    {
        $memoryStream = New-Object IO.MemoryStream
        $this.stream.CopyTo($memoryStream)
        return $memoryStream.ToArray()
    }

    # Read a subsection of the DataSource.
    # Offset is relative to the start of the data when >= 0, and
    # relative to the data end otherwise.
    # Length is relative to offset when > 0, and relative to the
    # data end otherwise.
    # This formulation means offset=0,length=0 reads the full data
    # without needing to know the size of the DataSource.
    hidden [Byte[]] ReadBytes([int64] $Offset, [int64] $Length)
    {
        # Ensure seek capability is available
        if (!$this.stream.CanSeek) {
            $inStream = New-Object IO.MemoryStream
            $this.stream.CopyTo($inStream)
        } else {
            $inStream = $this.stream
        }
        try {
            if ($Offset -ge 0) {
                $inStream.Seek($Offset, [System.IO.SeekOrigin]::Begin)
            } else {
                $inStream.Seek($Offset, [System.IO.SeekOrigin]::End)
            }
            if ($Length -le 0) {
                $Length = ($inStream.Length + $Length) - $inStream.Position
            }
            if ($Length -lt 0) {
                throw System.IO.EndOfStreamException
            }
            [Byte[]] $buffer = [System.Byte[]]::new($Length)

            $inStream.Read($buffer, 0, $buffer.Count)
            return $buffer

        } finally {
            # Cleanup temporary stream if used
            if (!$this.stream.CanSeek) {
                $inStream.Close()
            } else {
                $this.stream.Seek(0, [System.IO.SeekOrigin]::Begin)
            }
        }
    }


    [void] Close() {
        $this.stream.Close()
        if($this.zip) {
          $this.zip.Dispose()
        }
    }

}

# SIG # Begin signature block
# MIIefQYJKoZIhvcNAQcCoIIebjCCHmoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCAmIBFxWc3vOqXy
# HRwcUzCwzRYJqOXh3+/GEWv9mDOE1qCCGY0wggWKMIIEcqADAgECAhAL9isXqX/2
# 8aS6px6yF9fnMA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNV
# BAMTIkRpZ2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwHhcNMjAwOTA0
# MDAwMDAwWhcNMjMwODMxMTIwMDAwWjCBqDETMBEGCysGAQQBgjc8AgEDEwJHQjEd
# MBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xETAPBgNVBAUTCDA0NDQxMzg2
# MQswCQYDVQQGEwJHQjESMBAGA1UEBxMJQ2FtYnJpZGdlMR4wHAYDVQQKExVYaWxp
# bnggVGVjaG5vbG9neSBMdGQxHjAcBgNVBAMTFVhpbGlueCBUZWNobm9sb2d5IEx0
# ZDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALpCrVaJ0WUXy0vh2eDQ
# PbK2vwC51KJMF0vEbwtj501kbujnHRbd03C9K6kFw7crzLI1KI7sKqPep5bLjQfP
# mG3rdY1dS8d40yXQJLTiQWtlSkGSW2UIlhJdN9ASlwMPIqjbLrZlBbKsalyc/8Ry
# 9CayLQM1dJECX7MgRxz15fr04X4FbC2baJdrg6hgbJ9IDDuU5l7XVYXp1GkZFCPD
# S+92WMPTpb7LFFb+4KPULlF0Vmf3fJ6ZL8geqdCrVpADekGgj/EopsrIBvVy3Anr
# y5PgvVWl+GyYn+Xr9i3HxDkqrsJ9fZOuCWI1M8yyQE7trqPRCt+9bUwbpUSA7hES
# sWkCAwEAAaOCAekwggHlMB8GA1UdIwQYMBaAFI/ofvBtMmoABSPHcJdqOpD/a+rU
# MB0GA1UdDgQWBBQbN9po8ibTH5kEwgmurjm1ryenPTAmBgNVHREEHzAdoBsGCCsG
# AQUFBwgDoA8wDQwLR0ItMDQ0NDEzODYwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQM
# MAoGCCsGAQUFBwMDMHsGA1UdHwR0MHIwN6A1oDOGMWh0dHA6Ly9jcmwzLmRpZ2lj
# ZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwN6A1oDOGMWh0dHA6Ly9j
# cmw0LmRpZ2ljZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwSwYDVR0g
# BEQwQjA3BglghkgBhv1sAwIwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGln
# aWNlcnQuY29tL0NQUzAHBgVngQwBAzB+BggrBgEFBQcBAQRyMHAwJAYIKwYBBQUH
# MAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBIBggrBgEFBQcwAoY8aHR0cDov
# L2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0RVZDb2RlU2lnbmluZ0NBLVNI
# QTIuY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggEBAJGCCl1voKTA
# ml2M6QyubvxhbjOHzau7EL8YEHQgkBfarH0zrtOFXypqwELz219z9wdjUQ4czWEg
# MWCAusWIQpA47qFsrcFSjmvoa+AMYzCEMbkwXGGjquRTD/s61Zy6jh5ayPzxyj2+
# Ql61mIvDYiXhWv5BZuq/mS8YZGNXM1GwIDZK05gDup+NvIVVCoUa9A61KAJeXOyq
# d6yquSSaqW1HqD4Yg29YdxdF+nySo7cuI9LnefYofsNZ4PJJC2W7OtNgr770RTPz
# QrhJHRpJwfm5w2aUV0sO8KciQ+JySwKqZoO+WqxJ9q9JjUl/WY7qsFe3EcY+9vdK
# +dlK+QD24gowggZqMIIFUqADAgECAhADAZoCOv9YsWvW1ermF/BmMA0GCSqGSIb3
# DQEBBQUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgQ0EtMTAeFw0xNDEwMjIwMDAwMDBaFw0yNDEwMjIwMDAwMDBaMEcxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDElMCMGA1UEAxMcRGlnaUNlcnQg
# VGltZXN0YW1wIFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAKNkXfx8s+CCNeDg9sYq5kl1O8xu4FOpnx9kWeZ8a39rjJ1V+JLjntVaY1sC
# SVDZg85vZu7dy4XpX6X51Id0iEQ7Gcnl9ZGfxhQ5rCTqqEsskYnMXij0ZLZQt/US
# s3OWCmejvmGfrvP9Enh1DqZbFP1FI46GRFV9GIYFjFWHeUhG98oOjafeTl/iqLYt
# WQJhiGFyGGi5uHzu5uc0LzF3gTAfuzYBje8n4/ea8EwxZI3j6/oZh6h+z+yMDDZb
# esF6uHjHyQYuRhDIjegEYNu8c3T6Ttj+qkDxss5wRoPp2kChWTrZFQlXmVYwk/PJ
# YczQCMxr7GJCkawCwO+k8IkRj3cCAwEAAaOCAzUwggMxMA4GA1UdDwEB/wQEAwIH
# gDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIIBvwYDVR0g
# BIIBtjCCAbIwggGhBglghkgBhv1sBwEwggGSMCgGCCsGAQUFBwIBFhxodHRwczov
# L3d3dy5kaWdpY2VydC5jb20vQ1BTMIIBZAYIKwYBBQUHAgIwggFWHoIBUgBBAG4A
# eQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkAYwBhAHQA
# ZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBjAGUA
# IABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMAUABTACAA
# YQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkAIABBAGcA
# cgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBhAGIA
# aQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBhAHQA
# ZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMAZQAuMAsG
# CWCGSAGG/WwDFTAfBgNVHSMEGDAWgBQVABIrE5iymQftHt+ivlcNK2cCzTAdBgNV
# HQ4EFgQUYVpNJLZJMp1KKnkag0v0HonByn0wfQYDVR0fBHYwdDA4oDagNIYyaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0EtMS5jcmww
# OKA2oDSGMmh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RENBLTEuY3JsMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0xLmNydDANBgkqhkiG9w0BAQUF
# AAOCAQEAnSV+GzNNsiaBXJuGziMgD4CH5Yj//7HUaiwx7ToXGXEXzakbvFoWOQCd
# 42yE5FpA+94GAYw3+puxnSR+/iCkV61bt5qwYCbqaVchXTQvH3Gwg5QZBWs1kBCg
# e5fH9j/n4hFBpr1i2fAnPTgdKG86Ugnw7HBi02JLsOBzppLA044x2C/jbRcTBu7k
# A7YUq/OPQ6dxnSHdFMoVXZJB2vkPgdGZdA0mxA5/G7X1oPHGdwYoFenYk+VVFvC7
# Cqsc21xIJ2bIo4sKHOWV2q7ELlmgYd3a822iYemKC23sEhi991VUQAOSK2vCUcIK
# SK+w1G7g9BQKOhvjjz3Kr2qNe9zYRDCCBrwwggWkoAMCAQICEAPxtOFfOoLxFJZ4
# s9fYR1wwDQYJKoZIhvcNAQELBQAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMi
# RGlnaUNlcnQgSGlnaCBBc3N1cmFuY2UgRVYgUm9vdCBDQTAeFw0xMjA0MTgxMjAw
# MDBaFw0yNzA0MTgxMjAwMDBaMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdp
# Q2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNVBAMTIkRp
# Z2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCnU/oPsrUT8WTPhID8roA10bbXx6MsrBosrPGErDo1
# EjqSkbpX5MTJ8y+oSDy31m7clyK6UXlhr0MvDbebtEkxrkRYPqShlqeHTyN+w2xl
# JJBVPqHKI3zFQunEemJFm33eY3TLnmMl+ISamq1FT659H8gTy3WbyeHhivgLDJj0
# yj7QRap6HqVYkzY0visuKzFYZrQyEJ+d8FKh7+g+03byQFrc+mo9G0utdrCMXO42
# uoPqMKhM3vELKlhBiK4AiasD0RaCICJ2615UOBJi4dJwJNvtH3DSZAmALeK2nc4f
# 8rsh82zb2LMZe4pQn+/sNgpcmrdK0wigOXn93b89OgklAgMBAAGjggNYMIIDVDAS
# BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggr
# BgEFBQcDAzB/BggrBgEFBQcBAQRzMHEwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBJBggrBgEFBQcwAoY9aHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0SGlnaEFzc3VyYW5jZUVWUm9vdENBLmNydDCBjwYDVR0f
# BIGHMIGEMECgPqA8hjpodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRI
# aWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMECgPqA8hjpodHRwOi8vY3JsNC5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMIIBxAYD
# VR0gBIIBuzCCAbcwggGzBglghkgBhv1sAwIwggGkMDoGCCsGAQUFBwIBFi5odHRw
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9zc2wtY3BzLXJlcG9zaXRvcnkuaHRtMIIBZAYI
# KwYBBQUHAgIwggFWHoIBUgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAg
# AEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAg
# AGEAYwBjAGUAcAB0AGEAbgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBl
# AHIAdAAgAEMAUAAvAEMAUABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBu
# AGcAIABQAGEAcgB0AHkAIABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAg
# AGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAg
# AGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIABy
# AGUAZgBlAHIAZQBuAGMAZQAuMB0GA1UdDgQWBBSP6H7wbTJqAAUjx3CXajqQ/2vq
# 1DAfBgNVHSMEGDAWgBSxPsNpA/i/RwHUmCYaCALvY2QrwzANBgkqhkiG9w0BAQsF
# AAOCAQEAGTNKDIEzN9utNsnkyTq7tRsueqLi9ENCF56/TqFN4bHb6YHdnwHy5IjV
# 6f4J/SHB7F2A0vDWwUPC/ncr2/nXkTPObNWyGTvmLtbJk0+IQI7N4fV+8Q/GWVZy
# 6OtqQb0c1UbVfEnKZjgVwb/gkXB3h9zJjTHJDCmiM+2N4ofNiY0/G//V4BqXi3za
# bfuoxrI6Zmt7AbPN2KY07BIBq5VYpcRTV6hg5ucCEqC5I2SiTbt8gSVkIb7P7kIY
# Q5e7pTcGr03/JqVNYUvsRkG4Zc64eZ4IlguBjIo7j8eZjKMqbphtXmHGlreKuWEt
# k7jrDgRD1/X+pvBi1JlqpcHB8GSUgDCCBs0wggW1oAMCAQICEAb9+QOWA63qAArr
# Pye7uhswDQYJKoZIhvcNAQEFBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMb
# RGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4XDTA2MTExMDAwMDAwMFoXDTIx
# MTExMDAwMDAwMFowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IElu
# YzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQg
# QXNzdXJlZCBJRCBDQS0xMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
# 6IItmfnKwkKVpYBzQHDSnlZUXKnE0kEGj8kz/E1FkVyBn+0snPgWWd+etSQVwpi5
# tHdJ3InECtqvy15r7a2wcTHrzzpADEZNk+yLejYIA6sMNP4YSYL+x8cxSIB8HqIP
# kg5QycaH6zY/2DDD/6b3+6LNb3Mj/qxWBZDwMiEWicZwiPkFl32jx0PdAug7Pe2x
# QaPtP77blUjE7h6z8rwMK5nQxl0SQoHhg26Ccz8mSxSQrllmCsSNvtLOBq6thG9I
# hJtPQLnxTPKvmPv2zkBdXPao8S+v7Iki8msYZbHBc63X8djPHgp0XEK4aH631XcK
# J1Z8D2KkPzIUYJX9BwSiCQIDAQABo4IDejCCA3YwDgYDVR0PAQH/BAQDAgGGMDsG
# A1UdJQQ0MDIGCCsGAQUFBwMBBggrBgEFBQcDAgYIKwYBBQUHAwMGCCsGAQUFBwME
# BggrBgEFBQcDCDCCAdIGA1UdIASCAckwggHFMIIBtAYKYIZIAYb9bAABBDCCAaQw
# OgYIKwYBBQUHAgEWLmh0dHA6Ly93d3cuZGlnaWNlcnQuY29tL3NzbC1jcHMtcmVw
# b3NpdG9yeS5odG0wggFkBggrBgEFBQcCAjCCAVYeggFSAEEAbgB5ACAAdQBzAGUA
# IABvAGYAIAB0AGgAaQBzACAAQwBlAHIAdABpAGYAaQBjAGEAdABlACAAYwBvAG4A
# cwB0AGkAdAB1AHQAZQBzACAAYQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8AZgAgAHQA
# aABlACAARABpAGcAaQBDAGUAcgB0ACAAQwBQAC8AQwBQAFMAIABhAG4AZAAgAHQA
# aABlACAAUgBlAGwAeQBpAG4AZwAgAFAAYQByAHQAeQAgAEEAZwByAGUAZQBtAGUA
# bgB0ACAAdwBoAGkAYwBoACAAbABpAG0AaQB0ACAAbABpAGEAYgBpAGwAaQB0AHkA
# IABhAG4AZAAgAGEAcgBlACAAaQBuAGMAbwByAHAAbwByAGEAdABlAGQAIABoAGUA
# cgBlAGkAbgAgAGIAeQAgAHIAZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZIAYb9bAMV
# MBIGA1UdEwEB/wQIMAYBAf8CAQAweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzAB
# hhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9j
# YWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQw
# gYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdp
# Q2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwHQYDVR0OBBYEFBUA
# EisTmLKZB+0e36K+Vw0rZwLNMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3z
# bcgPMA0GCSqGSIb3DQEBBQUAA4IBAQBGUD7Jtygkpzgdtlspr1LPUukxR6tWXHvV
# DQtBs+/sdR90OPKyXGGinJXDUOSCuSPRujqGcq04eKx1XRcXNHJHhZRW0eu7NoR3
# zCSl8wQZVann4+erYs37iy2QwsDStZS9Xk+xBdIOPRqpFFumhjFiqKgz5Js5p8T1
# zh14dpQlc+Qqq8+cdkvtX8JLFuRLcEwAiR78xXm8TBJX/l/hHrwCXaj++wc4Tw3G
# XZG5D2dFzdaD7eeSDY2xaYxP+1ngIw/Sqq4AfO6cQg7PkdcntxbuD8O9fAqg7iwI
# VYUiuOsYGk38KiGtSTGDR5V3cdyxG0tLHBCcdxTBnU8vWpUIKRAmMYIERjCCBEIC
# AQEwgYAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMiRGlnaUNlcnQgRVYgQ29k
# ZSBTaWduaW5nIENBIChTSEEyKQIQC/YrF6l/9vGkuqceshfX5zANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCDG/oh2rNCIFWSO5Jd51hLOWMkO9yNdG64ZUy0kf1e2JDANBgkq
# hkiG9w0BAQEFAASCAQA01zvfEKDW+rS0xknd6d3fxX+A7G5DHFG93fhfN71s/Dp1
# mdlVWd3QQDsZcTXnPMx3MRmqYo+7//V2vZRFRtxXEMXuauWaiA/u3L8i+D6w246l
# n4i8V7HyHAseXkm5HGRLaAdksa7ZROVfYMB2Clm70J89utELLmxFSqjt+yNn1m3b
# Cl9sQv7Oa08RnUc2cAsNuZbD8M6/WJAD94zgwynQPDpYcUmsocaZUH+gSD3lZ8Pu
# vHU2Us+Co4NE40pZqN4cbUc0oFuHaO+YTwn+cPeh2LhSDEt7XIIfyTzaxgdXgzMr
# anaWYWtMh2e/gnw7jFy4RPzcgMwPvMyK6gCBKsPwoYICDzCCAgsGCSqGSIb3DQEJ
# BjGCAfwwggH4AgEBMHYwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0
# IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNl
# cnQgQXNzdXJlZCBJRCBDQS0xAhADAZoCOv9YsWvW1ermF/BmMAkGBSsOAwIaBQCg
# XTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0yMDEw
# MTkxMDMxMjNaMCMGCSqGSIb3DQEJBDEWBBQ1AD+EiBkXDkyVlwxBwPQfB1rM9TAN
# BgkqhkiG9w0BAQEFAASCAQACJJyIXEubrrHIIMsWZ832zC2pRBZF/kCS/kl5HHqu
# chvKRD+M7HaaMLMkO9IfyrzCzla79FsFA9N/xhbF0LziL5ff/EIufp9j3HPoEbMb
# BXZCgxRthG5bzwsfCJOrdUmpV309lWMJOuk3DgUBS99fITZCvJbrHC20XF7gjsdh
# 2ZGrvfTSbihCPGG42Njco+DIoaTwk1OBk7kNISIS/Eez5SNPaBvWleMvqEWC796u
# BNZSCgd7Af73j0uwAYNcPFMhXd1NdMPW2SnpszMfoUYBFEYw8QBpwAzieOB9NvS/
# 99Nrhrww1Eec7lqt94TOtDN12DhLtDx7q7AM+iATBl+X
# SIG # End signature block
