<#
    Copyright (c) 2020 Xilinx, Inc. All rights reserved.
    Copyright (c) 2018-2019 Solarflare Communications Inc.
    Use is subject to license terms.
#>

<#
.SYNOPSIS
    SfUpdate
.DESCRIPTION
    # Tool to manage firmware updates for Solarflare hardware
#>

#Requires -Version 5.1
#Requires -Modules CimCmdlets

Enum PartitionWriteMode
{
    Sync = 0
    Async = 16
}

class SfUpdate : PartitionControl {

    [UInt32] $OperationActions = 0

    SfUpdate([Hashtable] $BaseParams)
    : base ($BaseParams) {
    }

    hidden [String] GetFirmwareTypeDescription([Int] $Type, [Int] $SubType) {
        # Generic descriptions for EFX firmware types
        # FIXME: Legacy SfUpdate customizes description by subtype (e.g. specific PHY model and MUM vs SUC)
        $descriptions = @{
            1  = 'Boot ROM';
            3  = 'Adapter';
            5  = 'PHY';
            7  = 'FPGA';
            13 = 'UEFI ROM';
            14 = 'SUC';
            17 = 'Bundle';
        }
        $match = $descriptions[$Type]
        if ($match) {
            return $match
        }
        else {
            return "Firmware $Type"
        }
    }

    hidden [FirmwareInformation[]] GetListOfMatchedPartitions([CimInstance] $Instance, [Manifest] $Manifest) {
        $arr = @()
        $baseParams = $this.baseParams
        $instanceName = $Instance.InstanceName
        # Minimum driver version supporting this version of SolarflareTools
        $minimumDriverVersion = [Version]::new(1,4,1,1000)

        foreach ($viewinfo in $Instance.PartitionViewInfo) {
            $view = $viewInfo.View
            $versionValid = $viewInfo.VersionValid

            if ($view -ne 1) { continue }
            if ($versionValid -eq $false) { continue }

            if (($viewInfo.OperationsSupported -bAnd 0x2) -eq 0) { continue }

            $pnpEntity = Get-PnpEntity @baseParams -FriendlyName $instanceName
            if ($pnpEntity) {
                $pnpIds = ($pnpEntity.HardwareID).Split() + ($pnpEntity.CompatibleID).Split()
                $driverVersionString = Get-PnpEntityPropertyData -InputObject $pnpEntity -KeyName 'DEVPKEY_Device_DriverVersion'
            }
            else {
                $pnpIds = $null
                $driverVersionString = $null
            }
            $driverVersion = [Version]::new(0,0,0,0)
            if ([Version]::TryParse($driverVersionString, [ref]$null)) {
                $driverVersion = [Version]$driverVersionString
            }
            else {
                # Fallback for WS 2012 R2
                $pnpDriver = CimCmdlets\Get-CimInstance @baseParams -Namespace 'root/CIMV2' -ClassName 'Win32_PnPSignedDriver' |
                    Where-Object { $_.FriendlyName -eq $instanceName}
                if ([Version]::TryParse($pnpDriver.DriverVersion, [ref]$null)) {
                    $driverVersion = [Version]$pnpDriver.DriverVersion
                }
            }

            if ([Version]::new($driverVersion) -lt $minimumDriverVersion) {
                Write-Warning "Unable to update to $instanceName. Update driver to $minimumDriverVersion or later."
                continue
            }

            $type = $viewInfo.Type
            $subType = $viewInfo.SubType
            $version = $viewInfo.Version
            $currentVersion = [Version]::new($version.Major, $version.Minor, $version.Patch, $version.Build)
            $matchingImage = $Manifest.GetMatchingImage($type, $subtype, $pnpIds)

            if ($matchingImage) {
                $arr += [FirmwareInformation]::new($instanceName,
                    $type, $subType, $view,
                    $currentVersion,
                    $Manifest.Element($matchingImage, 'Version'),
                    $Manifest.BasePath,
                    $Manifest.Element($matchingImage, 'Path'),
                    $this.GetFirmwareTypeDescription($type, $subType),
                    $Manifest.Element($matchingImage, 'offset'),
                    $Manifest.Element($matchingImage, 'length') )
            }
        }
        return $arr
    }

    hidden [FirmwareInformation[]] GetListOfUpdatablePartitions([FirmwareInformation[]] $MatchedPartitions) {
        return $MatchedPartitions | Where-Object { $_.IsUpgrade -eq $true} | Select-Object
    }

    hidden [void] GetFirmwareInformationVersions([CimInstance[]] $PartitionViewInfoList,
        [FirmwareInformation[]] $Matches) {
        foreach ($match in $Matches) {
            foreach ($instance in $PartitionViewInfoList) {
                if ($instance.InstanceName -ne $match.InstanceName) {
                    continue
                }
                foreach ($viewinfo in $instance.PartitionViewInfo) {
                    if ($viewInfo.versionValid -eq $false) { continue }

                    if (($viewInfo.Type -ne $match.Type) -or
                        ($viewInfo.SubType -ne $match.SubType) -or
                        ($viewInfo.View -ne $match.View)) { continue }

                    $version = $viewInfo.Version
                    $match.currentVersion = [Version]::new($version.Major, $version.Minor, $version.Patch, $version.Build)
                }
            }
        }
    }

    hidden [void] PerformUpdate([FirmwareInformation] $Update) {
        $instanceName = $Update.InstanceName
        $type = $Update.Type
        $subtype = $Update.SubType
        $view = $Update.View
        $accessMode = 0

        $instance = $this.GetPartitionControl($instanceName)
        $sessionId = $this.OpenView($instance, $type, $subtype, $view, $accessMode, "")
        if ($sessionId) {
            try {
                $this.ClearView($instance, $sessionId)

                $source = [DataSource]::new($Update.BasePath, $null, $Update.ImagePath)
                $source.Open()
                if ($Update.Offset.length -gt 0) {
                    $offset = [System.Int64]::Parse($Update.Offset)
                } else {
                    $offset = 0
                }

                if (($Update.Length.length -gt 0)) {
                    $length = [System.Int64]::Parse($Update.Length)
                } else {
                    $length = 0
                }
                if (($offset -ne 0) -or ($length -ne 0)) {
                    $bytes = $source.ReadBytes(
                        $offset,
                        $length)
                } else {
                    $bytes = $source.ReadBytes()
                }
                $source.Close()

                $this.WriteView($instance, $sessionId, $bytes)
                $result = $this.CommitView($instance, $sessionId, [PartitionWriteMode]::Async)
                if ($result -eq 0) {
                    $result = $this.GetAsyncStatus($instance, $sessionId)
                }
                if ($result -ne 0) {
                    Write-Error ('Update {0}:{1} rejected. Error: {2}' -f
                        $Update.InstanceName, $Update.Description, $result)
                }
                else {
                    # Set all flags to indicate success
                    $Update.IsUpgrade = $true
                    $Update.IsDowngrade = $true
                }
            } catch [System.IO.IOException] {
                Write-Warning ('Update {0}:{1} failed' -f
                    $Update.InstanceName, $Update.Description)
            } finally {
                $this.CloseView($instance, $sessionId)
            }
        } else {
            Write-Warning ('Update {0}:{1} failed' -f
                $Update.InstanceName, $Update.Description)
        }
    }

    hidden [UInt32] GetAsyncStatus([CimInstance] $Instance, [Int64] $SessionId)
    {
        $Timeout = New-TimeSpan -Minutes 5
        $sw = [Diagnostics.Stopwatch]::StartNew()

        [int] $progress = 0
        [uint32] $opresult = 0
        [uint32] $actions = 0

        while ($sw.elapsed -lt $Timeout)
        {
            Write-Progress -Activity "Updating firmware..." -PercentComplete $progress
            $status = CimCmdlets\Invoke-CimMethod -InputObject $Instance `
                        -MethodName Solarflare_PartitionControl_GetStatus `
                        -Arguments @{SessionId = $SessionId } -Confirm:$false
            if ($status.Result -ne 0) { throw "Error occurred in GetAsyncStatus"; }
            $progress = $status.OperationProgress
            $opresult = $status.OperationResult
            $actions = $status.ActionsRequired
            if ($progress -ge 100) { break; }
            if ($opresult -ne 0) { break; }
            Start-Sleep -Milliseconds 1000
        }

        if (($opresult -eq 0) -and ($progress -lt 100)) {
            Write-Warning ('Update to {0} did not complete before timeout' -f
                $Instance.InstanceName)
        }

        $this.OperationActions = $actions
        return  $opresult
    }

    hidden [void] ClearVpdFamily([Partition] $VpdPartition)
    {
        $instanceName   = $VpdPartition.InstanceName
        $type           = $VpdPartition.Type
        $subtype        = $VpdPartition.SubType
        $view           = $VpdPartition.View
        $accessMode     = 0

        $instance       = $this.GetPartitionControl($instanceName)
        if ($instance) {
            $sessionId = $this.OpenView($instance, $type, $subtype, $view, $accessMode, "PVD")
            if ($sessionId) {
                try {
                    $this.ClearView($instance, $sessionId)
                    $result = $this.CommitView($instance, $sessionId, [PartitionWriteMode]::Sync)
                    if ($result -ne 0) {
                        Write-Warning 'Clearing VPD (VD) failed'
                    }
                } finally {
                    $this.CloseView($instance, $sessionId)
                }
            }
            $sessionId = $this.OpenView($instance, $type, $subtype, $view, $accessMode, "PV0")
            if ($sessionId) {
                try {
                    $this.ClearView($instance, $sessionId)
                    $result = $this.CommitView($instance, $sessionId, [PartitionWriteMode]::Sync)
                    if ($result -ne 0) {
                        Write-Warning 'Clearing VPD (V0) failed'
                    }
                } finally {
                    $this.CloseView($instance, $sessionId)
                }
            }
        }
    }

    hidden [void] SetVpdFamily([Partition] $VpdPartition, [String] $Family) {
        $instanceName = $VpdPartition.InstanceName
        $type = $VpdPartition.Type
        $subtype = $VpdPartition.SubType
        $view = $VpdPartition.View
        $accessMode = 0
        $bytes = [System.Text.Encoding]::ASCII.GetBytes($Family)

        $instance = $this.GetPartitionControl($instanceName)
        if ($instance) {
            $sessionId = $this.OpenView($instance, $type, $subtype, $view, $accessMode, "PVD")
            if ($sessionId) {
                try {
                    $this.ClearView($instance, $sessionId)
                    $this.WriteView($instance, $sessionId, $bytes)
                    $result = $this.CommitView($instance, $sessionId, [PartitionWriteMode]::Sync)
                    if ($result -ne 0) {
                        Write-Warning 'Setting VPD (VD) failed'
                    }
                } finally {
                    $this.CloseView($instance, $sessionId)
                }
            }
            $sessionId = $this.OpenView($instance, $type, $subtype, $view, $accessMode, "PV0")
            if ($sessionId) {
                try {
                    $this.ClearView($instance, $sessionId)
                    $this.WriteView($instance, $sessionId, $bytes)
                    $result = $this.CommitView($instance, $sessionId, [PartitionWriteMode]::Sync)
                    if ($result -ne 0) {
                        Write-Warning 'Setting VPD (V0) failed'
                    }
                } finally {
                    $this.CloseView($instance, $sessionId)
                }
            }
        }
    }

    hidden [void] ClearDynCfgTag([Partition]$ViewInfo, [UInt32] $Tag)
    {
        $instanceName = $ViewInfo.InstanceName

        if ($ViewInfo.Type -ne 11) { return }

        $accessMode = 1 #1: Fetch
        $path = ''
        $updateMode = 0 #0: sync
        $status = @{}

        $instance = $this.GetPartitionControl($instanceName)
        $sessionId = $this.OpenView(
                        $instance, $ViewInfo.Type, $ViewInfo.Subtype, $ViewInfo.View, $accessMode, $path)
        if ($sessionId) {
            try {
                $viewSize = $this.GetViewSize($instance, $sessionId)
                $view = $this.ReadViewUInt32s($instance, $sessionId, 0, $viewSize)
                $view =  $this.RemoveTLV($view, $Tag)
                $this.WriteViewUInt32s($instance, $sessionId, $view)
                $result = $this.CommitView($instance, $sessionId, $updateMode)
                if ($result -ne 0) {
                    Write-Error "Update to $($viewInfo.InstanceName):$($ViewInfo.Name) rejected"
                }
            } finally {
                $this.CloseView($instance, $sessionId)
            }
        }
    }


}

# Class representing a firmware revision.
# NOTE: Powershell 5 and 6 classes do not support namespaces, so the
# class is translated to a PSCustomObject type at the external boundary.
# If a future version of PS supports namespaced classes, this translation
# can be removed.
class FirmwareInformation {
    [String] $InstanceName
    [Int] $Type
    [Int] $SubType
    [Int] $View
    [Version] $CurrentVersion
    [Version] $ImageVersion
    [String] $BasePath
    [String] $ImagePath
    [Bool] $IsUpgrade
    [Bool] $IsDowngrade
    [String] $Description
    [String] $Offset
    [String] $Length

    FirmwareInformation() {}

    FirmwareInformation([String] $InstanceName,[Int] $Type, [Int] $SubType, [Int] $View,
                        [Version] $CurrentVersion, [Version] $ImageVersion, [String] $BasePath, [String] $ImagePath,
                        [String] $Description, [String] $Offset, [String] $Length) {
        $this.InstanceName = $InstanceName
        $this.Type = $Type
        $this.SubType = $SubType
        $this.View = $View
        $this.CurrentVersion = $CurrentVersion
        $this.ImageVersion = $ImageVersion
        $this.BasePath = $BasePath
        $this.ImagePath = $ImagePath
        $this.IsUpgrade = $ImageVersion -gt $this.CurrentVersion
        $this.IsDowngrade = $ImageVersion -lt $this.CurrentVersion
        $this.Description = $Description
        $this.Offset = $Offset
        $this.Length = $Length
    }
}
function Get-NetAdapterFirmwareInformation() {
    <#
        .SYNOPSIS
        Produce a list of possible firmware updates for Solarflare products.
        .DESCRIPTION
        The output objects can be piped to Update-SfNetAdapterFirmware
        .PARAMETER BundlePath
        Path to a firmware image bundle ZIP file.
        .PARAMETER Name
        Specifies the network adapter by name.
        .PARAMETER InterfaceDescription
        Specifies the network adapter by interface description.
        .OUTPUTS
        Solarflare.FirmwareInformation
        .EXAMPLE
        Get-NetAdapter | Get-SfNetAdapterFirmwareInformation | Update-SfNetAdapterFirmware
        .LINK
        Update-SfNetAdapterFirmware
    #>
    [CmdletBinding(PositionalBinding = $false, ConfirmImpact = 'Low')]
    [OutputType('Solarflare.FirmwareInformation', ParameterSetName = 'ByName')]
    [OutputType('Solarflare.FirmwareInformation', ParameterSetName = 'ByDescription')]
    [OutputType('Solarflare.FirmwareInformation', ParameterSetName = 'ByHardwareId')]
    param(
        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [ValidateScript({ Test-Path -Path $_ })]
        [String] $BundlePath = "",

        [Parameter(ParameterSetName = 'ByName')]
        [Alias('ifAlias InterfaceAlias')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $Name,

        [Parameter(ParameterSetName = 'ByDescription', Mandatory = $true, ValueFromPipelineByPropertyName = $true)]
        [Alias('ifDesc')]
        [ValidateNotNull()]
        [SupportsWildcards()]
        [String[]] $InterfaceDescription,

        [Parameter(ParameterSetName = 'ByHardwareId', Mandatory = $true)]
        [String[]] $HardwareId,

        [Parameter(ParameterSetName = 'ByName')]
        [Parameter(ParameterSetName = 'ByDescription')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Alias('Session')]
        [ValidateNotNull()]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession
    )

    process {

        $baseParams = @{}
        if ($PSBoundParameters.ContainsKey('CimSession')) {
            $baseParams['CimSession'] = $PSBoundParameters['CimSession']
        }

        $sut = [SfUpdate]::new($baseParams)
        $manifest = [Manifest]::new($BundlePath)
        $updateList = @()

        $PartitionViewInfoList = $sut.GetPartitionViewInfoList()
        if ($PSBoundParameters.ContainsKey('Name')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            foreach ($interface in (Get-NetAdapter @baseParams -Name $Name -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('InterfaceDescription')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            foreach ($interface in (Get-NetAdapter @baseParams -InterfaceDescription $InterfaceDescription `
                     -ErrorAction Stop)) {
                $selectedSet.Add($interface.InterfaceDescription) | Out-Null
            }
        }
        elseif ($PSBoundParameters.ContainsKey('HardwareId')) {
            $selectedSet = New-Object System.Collections.Generic.HashSet[String]
            $SolarflareAdapters = Get-PnpEntity @baseParams -HardwareId $HardwareId -PresentOnly
            if (!$SolarflareAdapters) {
                # No Adapters Found
                Write-Error "No Solarflare adapter(s) found with HardwareId:$HardwareId"
                return $Adapters
            }
            foreach($interface in $SolarflareAdapters) {
                $selectedSet.Add($interface.Name) | Out-Null
            }
        } else {
            $selectedSet = $null
        }

        foreach ($instance in $PartitionViewInfoList) {
            if ($selectedSet -and (!$selectedSet.Contains($instance.InstanceName))) {
                continue
            }
            $matchedPartitions = $sut.GetListOfMatchedPartitions($instance, $manifest)
            if ($matchedPartitions.Length -eq 0) {
                continue
            }
            # Output empty line between instances to be similar to legacy SfUpdate
            Write-Information ""
            Write-Information "$($Instance.InstanceName):"

            if ($manifest.firmwareFamilyRevision) {
                Write-Information "  Comparing to $($manifest.firmwareFamilyDescription) $($manifest.firmwareFamilyRevision)"
            }
            $zeroVersion = [Version]::new(0,0,0,0)
            foreach ($partition in $matchedPartitions) {

                # Avoid displaying zero version (e.g on conversion to bundle updates)
                if ($partition.CurrentVersion -gt $zeroVersion) {
                    $currentDesc = "  $($partition.Description): v$($partition.currentVersion) - "
                }
                else {
                    $currentDesc = "  $($partition.Description) - "
                }

                if ($partition.IsUpgrade) {
                    Write-Information $( -join ( $currentDesc,
                        "update to v$($partition.ImageVersion)" )
                    )
                }
                elseif ($partition.IsDowngrade) {
                    Write-Information $( -join ( $currentDesc,
                        "downgrade to v$($partition.ImageVersion)" )
                    )
                }
                else {
                    Write-Information $( -join ( $currentDesc,
                        "up to date" )
                    )
                }
                $firmwareInfo = [PSCustomObject] @{
                        PSTypeName = 'Solarflare.FirmwareInformation'
                        InterfaceDescription = $partition.InstanceName
                        Type = $partition.Type
                        SubType = $partition.SubType
                        View = $partition.View
                        CurrentVersion = $partition.CurrentVersion
                        ImageVersion = $partition.ImageVersion
                        BasePath = $partition.BasePath
                        ImagePath = $partition.ImagePath
                        Description = $partition.Description
                        Offset = $partition.Offset
                        Length = $partition.Length
                    }
                $updateList += $firmwareInfo
            }
        }
    }

    end {
        $updateList
    }
}

function Update-NetAdapterFirmware() {
    <#
        .SYNOPSIS
        Process a list of possible firmware updates for Solarflare products.
        .DESCRIPTION
        Takes as pipeline input objects output by Get-SfNetAdapterFirmwareInformation
        .PARAMETER InputObject
        Specifies Solarflare.FirmwareInformation objects to process.
        .PARAMETER UpdateAll
        Force firmware to be updated, not just when there is an upgrade.
        .PARAMETER CimSession
        Enter a computer name or a session object, such as the output of a New-CimSession or Get-CimSession cmdlet.
        The default is the current session on the local computer.
        .INPUTS
        Solarflare.FirmwareInformation

        Firmware information objects describing versioned firmware images available.
        .EXAMPLE
        Get-NetAdapter | Get-SfNetAdapterFirmwareInformation | Update-SfNetAdapterFirmware
        .LINK
        Get-SfNetAdapterFirmwareInformation
    #>
    [CmdletBinding(PositionalBinding = $false, SupportsShouldProcess = $true, ConfirmImpact = 'High')]
    [OutputType('Solarflare.FirmwareInformation')]
    param(

        [Parameter(ValueFromPipeline = $true)]
        [ValidateNotNull()]
        [PSTypeName('Solarflare.FirmwareInformation')]
        [PSCustomObject[]] $InputObject,

        [Switch] $UpdateAll,

        [String] $Family,

        [Alias('Session')]
        [ValidateNotNull()]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession
    )

    begin {

        $baseParams = @{}
        if ($PSBoundParameters.ContainsKey('CimSession')) {
            $baseParams['CimSession'] = $PSBoundParameters['CimSession']
        }

        $actions = @{}
        $sut = [SfUpdate]::new($baseParams)
        $results = @()
    }

    process {
        foreach ($firmwareInfo in $InputObject) {

            $matchedPartition = [FirmwareInformation]::new(
                $firmwareInfo.InterfaceDescription,
                $firmwareInfo.Type,
                $firmwareInfo.SubType,
                $firmwareInfo.View,
                $firmwareInfo.CurrentVersion,
                $firmwareInfo.ImageVersion,
                $firmwareInfo.BasePath,
                $firmwareInfo.ImagePath,
                $firmwareInfo.Description,
                $firmwareInfo.Offset,
                $firmwareInfo.Length)

            if ($UpdateAll) {
                $updatablePartitions = @($matchedPartition)
            }
            else {
                $updatablePartitions = $sut.GetListOfUpdatablePartitions(@($matchedPartition))
            }
            foreach ($updatablePartition in $updatablePartitions) {
                if ($updatablePartition.IsUpgrade) {
                    $changeText = "an upgrade"
                    $installText = "install?"
                }
                elseif ($updatablePartition.IsDowngrade) {
                    $changeText = "a downgrade"
                    $installText = "install anyway?"
                }
                else {
                    $changeText = "no change"
                    $installText = "install anyway?"
                }
                if ($PSCmdlet.ShouldProcess(
                    "Install $($updatablePartition.InstanceName):$($updatablePartition.Description) update",
                    -join (
                        "There is $($changeText) to $($updatablePartition.InstanceName):",
                        "$($updatablePartition.Description). Do you want to $($installText)"
                    ),
                    "Firmware update available")) {
                    Write-Information (-join (
                        "Updating $($updatablePartition.InstanceName):$($updatablePartition.Description)",
                        " to $($updatablePartition.ImageVersion)") )
                    $sut.PerformUpdate($updatablePartition)

                    $results += $updatablePartition

                    # IsUpgrade/Downgrade flags now indicate whether update occurred for followup actions
                    if ($updatablePartition.IsUpgrade -and $updatablePartition.IsDowngrade) {
                        # Log touched adapters and the post-operation actions
                        if ($actions.ContainsKey($updatablePartition.InstanceName)) {
                            $actions[$updatablePartition.InstanceName] =
                            $actions[$updatablePartition.InstanceName] -bOR $sut.OperationActions
                        }
                        else {
                            $actions.add($updatablePartition.InstanceName, $sut.OperationActions)
                        }
                    }
                }
            }
        }
    }

    end {
        $PartitionViewInfoList = $sut.GetPartitionViewInfoList()
        $keySet = New-Object System.Collections.Generic.HashSet[String]
        foreach ($key in $actions.Keys) {
            $keySet.Add([string]$key) | Out-Null
        }
        $VpdList = $sut.FilterPartitionsByName($PartitionViewInfoList, "VPD", $keySet)
        foreach ($VpdPartition in $VpdList) {
            if ($Family) {
                # Explicit override to set VPD family entry to specified string
                $sut.SetVpdFamily($VpdPartition, $Family)
            }
            else {
                # Clear family VPD entry
                $sut.ClearVpdFamily($VpdPartition)
            }
        }

        $GdcList = $sut.FilterPartitionsByName($PartitionViewInfoList, 'Global Dynamic Config', $keySet)
        foreach ($GdcPartition in $GdcList) {
            # Clear BundleUpdateDisabled flag
            $sut.ClearDynCfgTag($GdcPartition, [UInt32]'0x102d0000')
            # Add MCDI reboot action
            $actions[$GdcPartition.InstanceName] =
                $actions[$GdcPartition.InstanceName] -bOR 0x1
        }

        # Apply and/or print post-update actions
        $systemActions = 0
        foreach ($instanceName in $actions.keys) {
            $instanceActions = $actions[$instanceName]
            if ($instanceActions -bAND 0x1) {
                # Adapter firmware reboot required - schedule an MCDI reboot
                Write-Warning "Adapter $instanceName is being rebooted."
                $sut.McdiReboot($instanceName)
            }
            elseif ($instanceActions -bAND 0x2) {
                Write-Warning "Adapter $instanceName is being restarted."
                $sut.DeviceRestart($instanceName)
            }
            $systemActions = $systemActions -bOR $instanceActions
        }

        if ($systemActions -bAND 0x8) {
            Write-Warning "Computer must be powered off for changes to take effect"
        }
        elseif ($systemActions -bAND 0x4) {
            Write-Warning "Computer must be restarted for changes to take effect"
        }

        # Rescan partitions to get final version information
        $PartitionViewInfoList = $sut.GetPartitionViewInfoList()
        $sut.GetFirmwareInformationVersions($PartitionViewInfoList,
                        $results)
        $updateList = @()
        foreach ($result in $results) {
            $firmwareInfo = [PSCustomObject] @{
                    PSTypeName = 'Solarflare.FirmwareInformation'
                    InterfaceDescription = $result.InstanceName
                    Type = $result.Type
                    SubType = $result.SubType
                    View = $result.View
                    CurrentVersion = $result.CurrentVersion
                    ImageVersion = $result.ImageVersion
                    BasePath = $result.BasePath
                    ImagePath = $result.ImagePath
                    Description = $result.Description
                    Offset = $result.Offset
                    Length = $result.Length
                }
            $updateList += $firmwareInfo
        }
        return $updateList
    }
}

# SIG # Begin signature block
# MIIefQYJKoZIhvcNAQcCoIIebjCCHmoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDSWiHio5yKwuT/
# W3cifIz+bfYVFToPBE9lhsdR42eXDqCCGY0wggWKMIIEcqADAgECAhAL9isXqX/2
# 8aS6px6yF9fnMA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNV
# BAMTIkRpZ2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwHhcNMjAwOTA0
# MDAwMDAwWhcNMjMwODMxMTIwMDAwWjCBqDETMBEGCysGAQQBgjc8AgEDEwJHQjEd
# MBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xETAPBgNVBAUTCDA0NDQxMzg2
# MQswCQYDVQQGEwJHQjESMBAGA1UEBxMJQ2FtYnJpZGdlMR4wHAYDVQQKExVYaWxp
# bnggVGVjaG5vbG9neSBMdGQxHjAcBgNVBAMTFVhpbGlueCBUZWNobm9sb2d5IEx0
# ZDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALpCrVaJ0WUXy0vh2eDQ
# PbK2vwC51KJMF0vEbwtj501kbujnHRbd03C9K6kFw7crzLI1KI7sKqPep5bLjQfP
# mG3rdY1dS8d40yXQJLTiQWtlSkGSW2UIlhJdN9ASlwMPIqjbLrZlBbKsalyc/8Ry
# 9CayLQM1dJECX7MgRxz15fr04X4FbC2baJdrg6hgbJ9IDDuU5l7XVYXp1GkZFCPD
# S+92WMPTpb7LFFb+4KPULlF0Vmf3fJ6ZL8geqdCrVpADekGgj/EopsrIBvVy3Anr
# y5PgvVWl+GyYn+Xr9i3HxDkqrsJ9fZOuCWI1M8yyQE7trqPRCt+9bUwbpUSA7hES
# sWkCAwEAAaOCAekwggHlMB8GA1UdIwQYMBaAFI/ofvBtMmoABSPHcJdqOpD/a+rU
# MB0GA1UdDgQWBBQbN9po8ibTH5kEwgmurjm1ryenPTAmBgNVHREEHzAdoBsGCCsG
# AQUFBwgDoA8wDQwLR0ItMDQ0NDEzODYwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQM
# MAoGCCsGAQUFBwMDMHsGA1UdHwR0MHIwN6A1oDOGMWh0dHA6Ly9jcmwzLmRpZ2lj
# ZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwN6A1oDOGMWh0dHA6Ly9j
# cmw0LmRpZ2ljZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwSwYDVR0g
# BEQwQjA3BglghkgBhv1sAwIwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGln
# aWNlcnQuY29tL0NQUzAHBgVngQwBAzB+BggrBgEFBQcBAQRyMHAwJAYIKwYBBQUH
# MAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBIBggrBgEFBQcwAoY8aHR0cDov
# L2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0RVZDb2RlU2lnbmluZ0NBLVNI
# QTIuY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggEBAJGCCl1voKTA
# ml2M6QyubvxhbjOHzau7EL8YEHQgkBfarH0zrtOFXypqwELz219z9wdjUQ4czWEg
# MWCAusWIQpA47qFsrcFSjmvoa+AMYzCEMbkwXGGjquRTD/s61Zy6jh5ayPzxyj2+
# Ql61mIvDYiXhWv5BZuq/mS8YZGNXM1GwIDZK05gDup+NvIVVCoUa9A61KAJeXOyq
# d6yquSSaqW1HqD4Yg29YdxdF+nySo7cuI9LnefYofsNZ4PJJC2W7OtNgr770RTPz
# QrhJHRpJwfm5w2aUV0sO8KciQ+JySwKqZoO+WqxJ9q9JjUl/WY7qsFe3EcY+9vdK
# +dlK+QD24gowggZqMIIFUqADAgECAhADAZoCOv9YsWvW1ermF/BmMA0GCSqGSIb3
# DQEBBQUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgQ0EtMTAeFw0xNDEwMjIwMDAwMDBaFw0yNDEwMjIwMDAwMDBaMEcxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDElMCMGA1UEAxMcRGlnaUNlcnQg
# VGltZXN0YW1wIFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAKNkXfx8s+CCNeDg9sYq5kl1O8xu4FOpnx9kWeZ8a39rjJ1V+JLjntVaY1sC
# SVDZg85vZu7dy4XpX6X51Id0iEQ7Gcnl9ZGfxhQ5rCTqqEsskYnMXij0ZLZQt/US
# s3OWCmejvmGfrvP9Enh1DqZbFP1FI46GRFV9GIYFjFWHeUhG98oOjafeTl/iqLYt
# WQJhiGFyGGi5uHzu5uc0LzF3gTAfuzYBje8n4/ea8EwxZI3j6/oZh6h+z+yMDDZb
# esF6uHjHyQYuRhDIjegEYNu8c3T6Ttj+qkDxss5wRoPp2kChWTrZFQlXmVYwk/PJ
# YczQCMxr7GJCkawCwO+k8IkRj3cCAwEAAaOCAzUwggMxMA4GA1UdDwEB/wQEAwIH
# gDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIIBvwYDVR0g
# BIIBtjCCAbIwggGhBglghkgBhv1sBwEwggGSMCgGCCsGAQUFBwIBFhxodHRwczov
# L3d3dy5kaWdpY2VydC5jb20vQ1BTMIIBZAYIKwYBBQUHAgIwggFWHoIBUgBBAG4A
# eQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkAYwBhAHQA
# ZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBjAGUA
# IABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMAUABTACAA
# YQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkAIABBAGcA
# cgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBhAGIA
# aQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBhAHQA
# ZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMAZQAuMAsG
# CWCGSAGG/WwDFTAfBgNVHSMEGDAWgBQVABIrE5iymQftHt+ivlcNK2cCzTAdBgNV
# HQ4EFgQUYVpNJLZJMp1KKnkag0v0HonByn0wfQYDVR0fBHYwdDA4oDagNIYyaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0EtMS5jcmww
# OKA2oDSGMmh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RENBLTEuY3JsMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0xLmNydDANBgkqhkiG9w0BAQUF
# AAOCAQEAnSV+GzNNsiaBXJuGziMgD4CH5Yj//7HUaiwx7ToXGXEXzakbvFoWOQCd
# 42yE5FpA+94GAYw3+puxnSR+/iCkV61bt5qwYCbqaVchXTQvH3Gwg5QZBWs1kBCg
# e5fH9j/n4hFBpr1i2fAnPTgdKG86Ugnw7HBi02JLsOBzppLA044x2C/jbRcTBu7k
# A7YUq/OPQ6dxnSHdFMoVXZJB2vkPgdGZdA0mxA5/G7X1oPHGdwYoFenYk+VVFvC7
# Cqsc21xIJ2bIo4sKHOWV2q7ELlmgYd3a822iYemKC23sEhi991VUQAOSK2vCUcIK
# SK+w1G7g9BQKOhvjjz3Kr2qNe9zYRDCCBrwwggWkoAMCAQICEAPxtOFfOoLxFJZ4
# s9fYR1wwDQYJKoZIhvcNAQELBQAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMi
# RGlnaUNlcnQgSGlnaCBBc3N1cmFuY2UgRVYgUm9vdCBDQTAeFw0xMjA0MTgxMjAw
# MDBaFw0yNzA0MTgxMjAwMDBaMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdp
# Q2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNVBAMTIkRp
# Z2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCnU/oPsrUT8WTPhID8roA10bbXx6MsrBosrPGErDo1
# EjqSkbpX5MTJ8y+oSDy31m7clyK6UXlhr0MvDbebtEkxrkRYPqShlqeHTyN+w2xl
# JJBVPqHKI3zFQunEemJFm33eY3TLnmMl+ISamq1FT659H8gTy3WbyeHhivgLDJj0
# yj7QRap6HqVYkzY0visuKzFYZrQyEJ+d8FKh7+g+03byQFrc+mo9G0utdrCMXO42
# uoPqMKhM3vELKlhBiK4AiasD0RaCICJ2615UOBJi4dJwJNvtH3DSZAmALeK2nc4f
# 8rsh82zb2LMZe4pQn+/sNgpcmrdK0wigOXn93b89OgklAgMBAAGjggNYMIIDVDAS
# BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggr
# BgEFBQcDAzB/BggrBgEFBQcBAQRzMHEwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBJBggrBgEFBQcwAoY9aHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0SGlnaEFzc3VyYW5jZUVWUm9vdENBLmNydDCBjwYDVR0f
# BIGHMIGEMECgPqA8hjpodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRI
# aWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMECgPqA8hjpodHRwOi8vY3JsNC5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMIIBxAYD
# VR0gBIIBuzCCAbcwggGzBglghkgBhv1sAwIwggGkMDoGCCsGAQUFBwIBFi5odHRw
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9zc2wtY3BzLXJlcG9zaXRvcnkuaHRtMIIBZAYI
# KwYBBQUHAgIwggFWHoIBUgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAg
# AEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAg
# AGEAYwBjAGUAcAB0AGEAbgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBl
# AHIAdAAgAEMAUAAvAEMAUABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBu
# AGcAIABQAGEAcgB0AHkAIABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAg
# AGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAg
# AGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIABy
# AGUAZgBlAHIAZQBuAGMAZQAuMB0GA1UdDgQWBBSP6H7wbTJqAAUjx3CXajqQ/2vq
# 1DAfBgNVHSMEGDAWgBSxPsNpA/i/RwHUmCYaCALvY2QrwzANBgkqhkiG9w0BAQsF
# AAOCAQEAGTNKDIEzN9utNsnkyTq7tRsueqLi9ENCF56/TqFN4bHb6YHdnwHy5IjV
# 6f4J/SHB7F2A0vDWwUPC/ncr2/nXkTPObNWyGTvmLtbJk0+IQI7N4fV+8Q/GWVZy
# 6OtqQb0c1UbVfEnKZjgVwb/gkXB3h9zJjTHJDCmiM+2N4ofNiY0/G//V4BqXi3za
# bfuoxrI6Zmt7AbPN2KY07BIBq5VYpcRTV6hg5ucCEqC5I2SiTbt8gSVkIb7P7kIY
# Q5e7pTcGr03/JqVNYUvsRkG4Zc64eZ4IlguBjIo7j8eZjKMqbphtXmHGlreKuWEt
# k7jrDgRD1/X+pvBi1JlqpcHB8GSUgDCCBs0wggW1oAMCAQICEAb9+QOWA63qAArr
# Pye7uhswDQYJKoZIhvcNAQEFBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMb
# RGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4XDTA2MTExMDAwMDAwMFoXDTIx
# MTExMDAwMDAwMFowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IElu
# YzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQg
# QXNzdXJlZCBJRCBDQS0xMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
# 6IItmfnKwkKVpYBzQHDSnlZUXKnE0kEGj8kz/E1FkVyBn+0snPgWWd+etSQVwpi5
# tHdJ3InECtqvy15r7a2wcTHrzzpADEZNk+yLejYIA6sMNP4YSYL+x8cxSIB8HqIP
# kg5QycaH6zY/2DDD/6b3+6LNb3Mj/qxWBZDwMiEWicZwiPkFl32jx0PdAug7Pe2x
# QaPtP77blUjE7h6z8rwMK5nQxl0SQoHhg26Ccz8mSxSQrllmCsSNvtLOBq6thG9I
# hJtPQLnxTPKvmPv2zkBdXPao8S+v7Iki8msYZbHBc63X8djPHgp0XEK4aH631XcK
# J1Z8D2KkPzIUYJX9BwSiCQIDAQABo4IDejCCA3YwDgYDVR0PAQH/BAQDAgGGMDsG
# A1UdJQQ0MDIGCCsGAQUFBwMBBggrBgEFBQcDAgYIKwYBBQUHAwMGCCsGAQUFBwME
# BggrBgEFBQcDCDCCAdIGA1UdIASCAckwggHFMIIBtAYKYIZIAYb9bAABBDCCAaQw
# OgYIKwYBBQUHAgEWLmh0dHA6Ly93d3cuZGlnaWNlcnQuY29tL3NzbC1jcHMtcmVw
# b3NpdG9yeS5odG0wggFkBggrBgEFBQcCAjCCAVYeggFSAEEAbgB5ACAAdQBzAGUA
# IABvAGYAIAB0AGgAaQBzACAAQwBlAHIAdABpAGYAaQBjAGEAdABlACAAYwBvAG4A
# cwB0AGkAdAB1AHQAZQBzACAAYQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8AZgAgAHQA
# aABlACAARABpAGcAaQBDAGUAcgB0ACAAQwBQAC8AQwBQAFMAIABhAG4AZAAgAHQA
# aABlACAAUgBlAGwAeQBpAG4AZwAgAFAAYQByAHQAeQAgAEEAZwByAGUAZQBtAGUA
# bgB0ACAAdwBoAGkAYwBoACAAbABpAG0AaQB0ACAAbABpAGEAYgBpAGwAaQB0AHkA
# IABhAG4AZAAgAGEAcgBlACAAaQBuAGMAbwByAHAAbwByAGEAdABlAGQAIABoAGUA
# cgBlAGkAbgAgAGIAeQAgAHIAZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZIAYb9bAMV
# MBIGA1UdEwEB/wQIMAYBAf8CAQAweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzAB
# hhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9j
# YWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQw
# gYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdp
# Q2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwHQYDVR0OBBYEFBUA
# EisTmLKZB+0e36K+Vw0rZwLNMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3z
# bcgPMA0GCSqGSIb3DQEBBQUAA4IBAQBGUD7Jtygkpzgdtlspr1LPUukxR6tWXHvV
# DQtBs+/sdR90OPKyXGGinJXDUOSCuSPRujqGcq04eKx1XRcXNHJHhZRW0eu7NoR3
# zCSl8wQZVann4+erYs37iy2QwsDStZS9Xk+xBdIOPRqpFFumhjFiqKgz5Js5p8T1
# zh14dpQlc+Qqq8+cdkvtX8JLFuRLcEwAiR78xXm8TBJX/l/hHrwCXaj++wc4Tw3G
# XZG5D2dFzdaD7eeSDY2xaYxP+1ngIw/Sqq4AfO6cQg7PkdcntxbuD8O9fAqg7iwI
# VYUiuOsYGk38KiGtSTGDR5V3cdyxG0tLHBCcdxTBnU8vWpUIKRAmMYIERjCCBEIC
# AQEwgYAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMiRGlnaUNlcnQgRVYgQ29k
# ZSBTaWduaW5nIENBIChTSEEyKQIQC/YrF6l/9vGkuqceshfX5zANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCBGyGgOOc+6Khv8KYRj5gthwghRSNx9tUjeWeViu3ZKdzANBgkq
# hkiG9w0BAQEFAASCAQAzAXc2G4NkJ68s5C+G94GGjqb5ztD9yTVo0lZ3YqndWc9d
# P0N0XDGHtXOc6dYCon2poszVwQpEOx+LQ0b27UXgATW1C/IZb7tsPGuqQokED0js
# +O4GoX9dIMe4vDt5NqGVsW3/P4pCSGsS9V1BEBpgh5rjR8j0dRtCDeXsgn+sYVyn
# lqc6aHT9+hHYqG4TLFiLLHc76OgZcIxIlewEKaw2lYd8CMYGYcF4NBs12l7JU968
# i1ffQTjWDdDYiD7dr2a26Z4GycvV4OZkDHjvJVTOQjiFJ79L5eW4U4XtOAMrzfGP
# yW0TQ0VtOu2TXzXnrDmvlySYmsPnBMq+aKA08zvpoYICDzCCAgsGCSqGSIb3DQEJ
# BjGCAfwwggH4AgEBMHYwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0
# IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNl
# cnQgQXNzdXJlZCBJRCBDQS0xAhADAZoCOv9YsWvW1ermF/BmMAkGBSsOAwIaBQCg
# XTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0yMDEw
# MTkxMDMxMjlaMCMGCSqGSIb3DQEJBDEWBBSpj5uPk3CnUo4YApbmZeLvUrVJGTAN
# BgkqhkiG9w0BAQEFAASCAQCPZ9NubelfTgepct7oQKGG+VTuye7+12x0kH9xS3uP
# KmWe+Wax56u+zeA2km0ZwqpvKu7aW5WtjLg8SYhOZEJZTkhmfhpacr86G6cQlYMt
# 4NjBXzGqjJl8DrimVd96w9kpaI2SRI+8A9+89DJIrjBMKv1v6YH8NwH5aX7LUygN
# XFYRVOtWdrlBxb15Iz7m0ARBxKuD15x+07eo+RWnNFh3exbo0E9oJ3I7NbVAA2WY
# FITKFPnV7I7xpJBK1v2jMnRNqkXIJhNKrc7Ze0NOUFTr51wy0xmRmDaG87/YjMvN
# qB0PtQlRAeDScR6+PwAjtS+uI24rjVIGNsMScwywPdWl
# SIG # End signature block
