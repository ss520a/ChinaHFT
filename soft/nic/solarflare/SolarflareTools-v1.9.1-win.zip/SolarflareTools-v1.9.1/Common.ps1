<#
    Copyright (c) 2020 Xilinx, Inc. All rights reserved.
    Copyright (c) 2018-2019 Solarflare Communications Inc.
    Use is subject to license terms.
#>

<#
.SYNOPSIS
    Common
.DESCRIPTION
    Common base class and functions for Solarflare powershell utilities
#>

#Requires -Version 5.1
#Requires -Modules CimCmdlets

class Common {

    hidden [Hashtable] $baseParams

    Common([Hashtable] $BaseParams) {
        $this.baseParams = $BaseParams
    }
}

function Filter-Hashtable(
    [OutputType([Hashtable])]
    [Hashtable] $Hashtable,
    [String[]] $KeysToInclude
) {
   $filtered = $Hashtable.Clone()
   foreach ($key in $Hashtable.Keys) {
       if ($KeysToInclude -NotContains $key) {
           $filtered.Remove($key)
       }
   }
   return $filtered
}

function Get-SfDeviceInventoryInfo {
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType('Solarflare.DeviceInventoryInformation')]
    param(
        [Parameter(Position = 0)]
        [ValidateNotNullOrEmpty()]
        [String[]] $HardwareId,

        [Alias('Session')]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession
    )

    $baseParams = @{}
    if ($PSBoundParameters.ContainsKey('CimSession')) {
        $baseParams['CimSession'] = $PSBoundParameters['CimSession']
    }

    [regex] $pciInstanceIdRegEx = '^PCI\\VEN_(?<VendorId>[0-9A-F]{4})&DEV_(?<DeviceId>[0-9A-F]{4})&SUBSYS_(?<SubsystemId>[0-9A-F]{4})(?<SubsystemVendorId>[0-9A-F]{4})&REV_(?<RevisionId>[0-9A-F]{2})\\.+$'

    $pnpEntities = Get-PnpEntity @baseParams -HardwareId $HardwareId -PresentOnly
    foreach ($pnpEntity in $pnpEntities) {
        $properties = [Ordered]@{
            PSTypeName                = 'Solarflare.DeviceInventoryInformation'

            InstanceId                = $pnpEntity.DeviceID
            FriendlyName              = $pnpEntity.Name
            Description               = $pnpEntity.Description
            Status                    = $pnpEntity.Status

            VendorId                  = $null
            DeviceId                  = $null
            SubsystemId               = $null
            SubsystemVendorId         = $null
            RevisionId                = $null

            BusNumber                 = $null
            DeviceNumber              = $null
            FunctionNumber            = $null

            DriverKeyPath             = $null
            DriverProvider            = $null
            DriverInfPath             = $null
            DriverDate                = $null
            DriverVersionString       = $null
            DriverVersion             = $null

            PermanentMacAddress       = $null
            PermanentMacAddressString = $null

            VpdId                     = $null
            VpdPartNumber             = $null
            VpdSerialNumber           = $null
            VpdEngineeringChanges     = $null
        }

        # Parse instance ID to determine PCI identifers
        if ($pnpEntity.DeviceID -match $pciInstanceIdRegEx) {
            $properties.VendorId = [Convert]::ToUInt16($matches.VendorId, 16)
            $properties.DeviceId = [Convert]::ToUInt16($matches.DeviceId, 16)
            $properties.SubsystemId  = [Convert]::ToUInt16($matches.SubsystemId, 16)
            $properties.SubsystemVendorId = [Convert]::ToUInt16($matches.SubsystemVendorId, 16)
            $properties.RevisionId = [Convert]::ToByte($matches.RevisionId, 16)
        }

        # Determine PCI location
        #
        # NOTE: The interpretation of DEVPKEY_Device_BusNumber and
        #       DEVPKEY_Device_Address is bus type (i.e. enumerator) specific.
        $enumeratorName = Get-PnpEntityPropertyData -InputObject $pnpEntity -KeyName 'DEVPKEY_Device_EnumeratorName'
        if ($enumeratorName -eq 'PCI') {
            $properties.BusNumber = Get-PnpEntityPropertyData -InputObject $pnpEntity -KeyName 'DEVPKEY_Device_BusNumber'
            $Address = Get-PnpEntityPropertyData -InputObject $pnpEntity -KeyName 'DEVPKEY_Device_Address'
            $properties.DeviceNumber = [UInt16]($Address -shr 16)
            $properties.FunctionNumber = [UInt16]($Address -band 65535)
        }

        # Determine driver details
        $properties.DriverKeyPath = Get-PnpEntityPropertyData -InputObject $pnpEntity -KeyName 'DEVPKEY_Device_Driver'
        $properties.DriverProvider = Get-PnpEntityPropertyData -InputObject $pnpEntity -KeyName 'DEVPKEY_Device_DriverProvider'
        $properties.DriverInfPath = Get-PnpEntityPropertyData -InputObject $pnpEntity -KeyName 'DEVPKEY_Device_DriverInfPath'
        $properties.DriverDate = Get-PnpEntityPropertyData -InputObject $pnpEntity -KeyName 'DEVPKEY_Device_DriverDate'
        $properties.DriverVersionString = Get-PnpEntityPropertyData -InputObject $pnpEntity -KeyName 'DEVPKEY_Device_DriverVersion'
        if ([Version]::TryParse($properties.DriverVersionString, [ref]$null)) {
            $properties.DriverVersion = [Version]$properties.DriverVersionString
        }

        # Read VPD data
        #
        # \DEVNOTE: This will require the device be enabled, started and
        #           operational. Perhaps check $pnpEntity.Status -eq 'OK' first?
        $properties.VpdId = Get-SfVpdStringForPnpEntity -InputObject $pnpEntity -Tag 'ID'
        $properties.VpdPartNumber = Get-SfVpdStringForPnpEntity -InputObject $pnpEntity -Tag 'RO' -Keyword 'PN'
        $properties.VpdSerialNumber = Get-SfVpdStringForPnpEntity -InputObject $pnpEntity -Tag 'RO' -Keyword 'SN'
        $properties.VpdEngineeringChanges = Get-SfVpdStringForPnpEntity -InputObject $pnpEntity -Tag 'RO' -Keyword 'EC'

        # Determine permanent MAC address (also useful for asset tracking)
        $ethernetPermanentAddress = Get-CimInstanceForPnpEntity -InputObject $pnpEntity -Namespace 'root/WMI' -ClassName 'MSNdis_EthernetPermanentAddress'
        if ($ethernetPermanentAddress) {
            $properties.PermanentMacAddress = $ethernetPermanentAddress[0].NdisPermanentAddress.Address
            $properties.PermanentMacAddressString = Format-EthernetMacAddress $properties.PermanentMacAddress
        }

        # TODO: Determine firmware version

        [PSCustomObject]$properties
    }
  }

function Get-PnpEntity {
    [CmdletBinding(PositionalBinding = $false, DefaultParameterSetName = 'All')]
    [OutputType('Microsoft.Management.Infrastructure.CimInstance#root/cimv2/Win32_PnPEntity')]
    param(
        [Parameter(ParameterSetName = 'ByInstanceId', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String[]] $InstanceId,

        [Parameter(ParameterSetName = 'ByFriendlyName', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String[]] $FriendlyName,

        [Parameter(ParameterSetName = 'ByHardwareId', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String[]] $HardwareId,

        [Parameter(ParameterSetName = 'ByCompatibleId', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String[]] $CompatibleId,

        [Parameter(ParameterSetName = 'All')]
        [Parameter(ParameterSetName = 'ByInstanceId')]
        [Parameter(ParameterSetName = 'ByFriendlyName')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(ParameterSetName = 'ByCompatibleId')]
        [Switch] $PresentOnly,

        [Parameter(ParameterSetName = 'All')]
        [Parameter(ParameterSetName = 'ByInstanceId')]
        [Parameter(ParameterSetName = 'ByFriendlyName')]
        [Parameter(ParameterSetName = 'ByHardwareId')]
        [Parameter(ParameterSetName = 'ByCompatibleId')]
        [ValidateSet('OK', 'ERROR', 'DEGRADED', 'UNKNOWN')]
        [String] $Status,

        [Alias('Session')]
        [Microsoft.Management.Infrastructure.CimSession] $CimSession
    )

    $baseParams = @{}
    if ($PSBoundParameters.ContainsKey('CimSession')) {
        $baseParams['CimSession'] = $PSBoundParameters['CimSession']
    }

    switch ($PsCmdlet.ParameterSetName) {
        'All' {
            $idFilterScript = {
                $true
            }
            break
        }
        'ByInstanceId' {
            $idFilterScript = {
                $InstanceId -contains $_.DeviceID
            }
            break
        }
        'ByFriendlyName' {
            $idFilterScript = {
                $FriendlyName -contains $_.Name
            }
            break
        }
        'ByHardwareId' {
            $idFilterScript = {
                foreach ($id in $HardwareId) {
                    if ($_.HardwareID -contains $id) {
                        return $true
                    }
                }
                return $false
            }
            break
        }
        'ByCompatibleId' {
            $idFilterScript = {
                foreach ($id in $CompatibleId) {
                    if ($_.CompatibleID -contains $id) {
                        return $true
                    }
                }
                return $false
            }
            break
        }
    }

    $filtered = CimCmdlets\Get-CimInstance -Namespace 'root/CIMV2' -ClassName 'Win32_PnpEntity' @baseParams |
        Where-Object -FilterScript $idFilterScript
    if ($PresentOnly) {
        if ($filtered -and ($filtered[0].PSObject.Properties.name -match "Present")) {
            $filtered = $filtered | Where-Object { $_.Present -eq $true }
        }
        else {
            # Force fallback on Status for Win2K12R2
            $Status = 'OK'
        }
    }
    $filtered | Where-Object { $Status -eq '' -or $_.Status -eq $Status }
}

function Get-PnpEntityPropertyData {
    [CmdletBinding(PositionalBinding = $false)]
    param(
        [Parameter(ParameterSetName = 'ByInputObject', Mandatory = $true, ValueFromPipeline = $true)]
        [ValidateNotNull()]
        [PSTypeName('Microsoft.Management.Infrastructure.CimInstance#root/cimv2/Win32_PnPEntity')]
        [Microsoft.Management.Infrastructure.CimInstance] $InputObject,

        [Parameter(ParameterSetName = 'ByInstanceId', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String] $InstanceId,

        [Parameter(ParameterSetName = 'ByInputObject', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ByInstanceId', Mandatory = $true)]
        [String] $KeyName
    )

    if (-not $InputObject) {
        $InputObject = Get-PnpEntity -InstanceId $InstanceId
    }
    $cimMethodParameters = @{
        InputObject = $InputObject
        MethodName = 'GetDeviceProperties'
        Arguments = @{
            devicePropertyKeys = @( $KeyName )
        }
    }
    $cimMethodResult = CimCmdlets\Invoke-CimMethod @cimMethodParameters
    if ($cimMethodResult.ReturnValue -eq 0) {
        foreach ($deviceProperty in $cimMethodResult.deviceProperties) {
            if($deviceProperty.PSObject.Properties.Name -contains 'Data') {
                return $deviceProperty.Data
            }
        }
    }
}

function Format-EthernetMacAddress(
    [Byte[]] $MacAddress
    ) {
        if ($MacAddress.Length -eq 6) {
            '{0:X2}-{1:X2}-{2:X2}-{3:X2}-{4:X2}-{5:X2}' -f $MacAddress[0..5]
        } else {
            ''
        }
    }

function Invoke-CimMethodForPnpEntity {
    [CmdletBinding(PositionalBinding = $false)]
    param(
        [Parameter(ParameterSetName = 'ByInputObject', Mandatory = $true, ValueFromPipeline = $true)]
        [ValidateNotNull()]
        [PSTypeName('Microsoft.Management.Infrastructure.CimInstance#root/cimv2/Win32_PnPEntity')]
        [Microsoft.Management.Infrastructure.CimInstance] $InputObject,

        [Parameter(ParameterSetName = 'ByInstanceId', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String] $InstanceId,

        [Parameter(ParameterSetName = 'ByInputObject')]
        [Parameter(ParameterSetName = 'ByInstanceId')]
        [String] $Namespace = 'root/CIMV2',

        [Parameter(ParameterSetName = 'ByInputObject', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ByInstanceId', Mandatory = $true)]
        [String] $ClassName,

        [Parameter(ParameterSetName = 'ByInputObject', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ByInstanceId', Mandatory = $true)]
        [String] $MethodName,

        [Parameter(ParameterSetName = 'ByInputObject')]
        [Parameter(ParameterSetName = 'ByInstanceId')]
        [System.Collections.IDictionary] $Arguments
    )

    if (-not $InputObject) {
        $InputObject = Get-PnpEntity -InstanceId $InstanceId
    }

    $cimInstanceParameters = @{
        Namespace   = $Namespace
        ClassName   = $ClassName
        ErrorAction = 'SilentlyContinue'
    }
    $cimInstance = CimCmdlets\Get-CimInstance @cimInstanceParameters |
        Where-Object {$_.InstanceName -eq $InputObject.Name}
    if ($cimInstance) {
        $cimMethodParameters = @{
            InputObject = $cimInstance
            MethodName  = $MethodName
        }
        if ($Arguments) {
            $cimMethodParameters.Arguments = $Arguments
        }
        Invoke-CimMethod @cimMethodParameters
    }
}

function Get-SfVpdStringForPnpEntity {
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType('String')]
    param(
        [Parameter(ParameterSetName = 'ByInputObject', Mandatory = $true, ValueFromPipeline = $true)]
        [ValidateNotNull()]
        [PSTypeName('Microsoft.Management.Infrastructure.CimInstance#root/cimv2/Win32_PnPEntity')]
        [Microsoft.Management.Infrastructure.CimInstance] $InputObject,

        [Parameter(ParameterSetName = 'ByInstanceId', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String] $InstanceId,

        [Parameter(ParameterSetName = 'ByInputObject', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ByInstanceId', Mandatory = $true)]
        [ValidateSet('ID', 'RO', 'ReadOnly', 'RW', 'ReadWrite')]
        [String] $Tag,

        [Parameter(ParameterSetName = 'ByInputObject')]
        [Parameter(ParameterSetName = 'ByInstanceId')]
        [String] $Keyword
    )

    switch ($Tag) {
        'ID'        { $TagNumber = [Byte]0x02 }
        'RO'        { $TagNumber = [Byte]0x10 }
        'ReadOnly'  { $TagNumber = [Byte]0x10 }
        'RW'        { $TagNumber = [Byte]0x11 }
        'ReadWrite' { $TagNumber = [Byte]0x11 }
        default     { throw ('Unknown Tag type "{0}"' -f $Tag) }
    }
    if ($TagNumber -eq 0x02) {
        $KeywordNumber = 0
    }
    else {
        if ($Keyword.Length -eq 2) {
            $KeywordNumber = ([UInt16][Byte]$Keyword[1] -shl 8) -bor [UInt16][Byte]$Keyword[0]
        }
        else {
            throw ('Invalid Keyword "{0}"' -f $Keyword)
        }
    }

    if (-not $InputObject) {
        $InputObject = Get-PnpEntity -InstanceId $InstanceId
    }
    $cimMethodParameters = @{
        InputObject = $InputObject
        Namespace   = 'root/WMI'
        ClassName   = 'Solarflare_VPD'
        MethodName  = 'Solarflare_VPD_ReadStringKeyword'
        Arguments = @{
            Tag     = $TagNumber
            Keyword = $KeywordNumber
        }
    }
    $cimMethodResult = Invoke-CimMethodForPnpEntity @cimMethodParameters
    if ($cimMethodResult -and $cimMethodResult.ReturnValue) {
        $cimMethodResult.StrData
    }
}

function Get-CimInstanceForPnpEntity {
    [CmdletBinding(PositionalBinding = $false)]
    [OutputType('Microsoft.Management.Infrastructure.CimInstance')]
    param(
        [Parameter(ParameterSetName = 'ByInputObject', Mandatory = $true, ValueFromPipeline = $true)]
        [ValidateNotNull()]
        [PSTypeName('Microsoft.Management.Infrastructure.CimInstance#root/cimv2/Win32_PnPEntity')]
        [Microsoft.Management.Infrastructure.CimInstance] $InputObject,

        [Parameter(ParameterSetName = 'ByInstanceId', Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String] $InstanceId,

        [Parameter(ParameterSetName = 'ByInputObject')]
        [Parameter(ParameterSetName = 'ByInstanceId')]
        [String] $Namespace = 'root/CIMV2',

        [Parameter(ParameterSetName = 'ByInputObject', Mandatory = $true)]
        [Parameter(ParameterSetName = 'ByInstanceId', Mandatory = $true)]
        [String] $ClassName
    )

    if (-not $InputObject) {
        $InputObject = Get-PnpEntity -InstanceId $InstanceId
    }
    $cimInstanceParameters = @{
        Namespace   = $Namespace
        ClassName   = $ClassName
        ErrorAction = 'SilentlyContinue'
    }
    CimCmdlets\Get-CimInstance @cimInstanceParameters |
        Where-Object {$_.InstanceName -eq $InputObject.Name}
}

# SIG # Begin signature block
# MIIefQYJKoZIhvcNAQcCoIIebjCCHmoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCDsqO5/vR9whBf0
# 0A9WJTzB1iuQ25xl0dcp5gzZ0K5yFaCCGY0wggWKMIIEcqADAgECAhAL9isXqX/2
# 8aS6px6yF9fnMA0GCSqGSIb3DQEBCwUAMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNV
# BAMTIkRpZ2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwHhcNMjAwOTA0
# MDAwMDAwWhcNMjMwODMxMTIwMDAwWjCBqDETMBEGCysGAQQBgjc8AgEDEwJHQjEd
# MBsGA1UEDwwUUHJpdmF0ZSBPcmdhbml6YXRpb24xETAPBgNVBAUTCDA0NDQxMzg2
# MQswCQYDVQQGEwJHQjESMBAGA1UEBxMJQ2FtYnJpZGdlMR4wHAYDVQQKExVYaWxp
# bnggVGVjaG5vbG9neSBMdGQxHjAcBgNVBAMTFVhpbGlueCBUZWNobm9sb2d5IEx0
# ZDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALpCrVaJ0WUXy0vh2eDQ
# PbK2vwC51KJMF0vEbwtj501kbujnHRbd03C9K6kFw7crzLI1KI7sKqPep5bLjQfP
# mG3rdY1dS8d40yXQJLTiQWtlSkGSW2UIlhJdN9ASlwMPIqjbLrZlBbKsalyc/8Ry
# 9CayLQM1dJECX7MgRxz15fr04X4FbC2baJdrg6hgbJ9IDDuU5l7XVYXp1GkZFCPD
# S+92WMPTpb7LFFb+4KPULlF0Vmf3fJ6ZL8geqdCrVpADekGgj/EopsrIBvVy3Anr
# y5PgvVWl+GyYn+Xr9i3HxDkqrsJ9fZOuCWI1M8yyQE7trqPRCt+9bUwbpUSA7hES
# sWkCAwEAAaOCAekwggHlMB8GA1UdIwQYMBaAFI/ofvBtMmoABSPHcJdqOpD/a+rU
# MB0GA1UdDgQWBBQbN9po8ibTH5kEwgmurjm1ryenPTAmBgNVHREEHzAdoBsGCCsG
# AQUFBwgDoA8wDQwLR0ItMDQ0NDEzODYwDgYDVR0PAQH/BAQDAgeAMBMGA1UdJQQM
# MAoGCCsGAQUFBwMDMHsGA1UdHwR0MHIwN6A1oDOGMWh0dHA6Ly9jcmwzLmRpZ2lj
# ZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwN6A1oDOGMWh0dHA6Ly9j
# cmw0LmRpZ2ljZXJ0LmNvbS9FVkNvZGVTaWduaW5nU0hBMi1nMS5jcmwwSwYDVR0g
# BEQwQjA3BglghkgBhv1sAwIwKjAoBggrBgEFBQcCARYcaHR0cHM6Ly93d3cuZGln
# aWNlcnQuY29tL0NQUzAHBgVngQwBAzB+BggrBgEFBQcBAQRyMHAwJAYIKwYBBQUH
# MAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBIBggrBgEFBQcwAoY8aHR0cDov
# L2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0RVZDb2RlU2lnbmluZ0NBLVNI
# QTIuY3J0MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggEBAJGCCl1voKTA
# ml2M6QyubvxhbjOHzau7EL8YEHQgkBfarH0zrtOFXypqwELz219z9wdjUQ4czWEg
# MWCAusWIQpA47qFsrcFSjmvoa+AMYzCEMbkwXGGjquRTD/s61Zy6jh5ayPzxyj2+
# Ql61mIvDYiXhWv5BZuq/mS8YZGNXM1GwIDZK05gDup+NvIVVCoUa9A61KAJeXOyq
# d6yquSSaqW1HqD4Yg29YdxdF+nySo7cuI9LnefYofsNZ4PJJC2W7OtNgr770RTPz
# QrhJHRpJwfm5w2aUV0sO8KciQ+JySwKqZoO+WqxJ9q9JjUl/WY7qsFe3EcY+9vdK
# +dlK+QD24gowggZqMIIFUqADAgECAhADAZoCOv9YsWvW1ermF/BmMA0GCSqGSIb3
# DQEBBQUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgQ0EtMTAeFw0xNDEwMjIwMDAwMDBaFw0yNDEwMjIwMDAwMDBaMEcxCzAJ
# BgNVBAYTAlVTMREwDwYDVQQKEwhEaWdpQ2VydDElMCMGA1UEAxMcRGlnaUNlcnQg
# VGltZXN0YW1wIFJlc3BvbmRlcjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoC
# ggEBAKNkXfx8s+CCNeDg9sYq5kl1O8xu4FOpnx9kWeZ8a39rjJ1V+JLjntVaY1sC
# SVDZg85vZu7dy4XpX6X51Id0iEQ7Gcnl9ZGfxhQ5rCTqqEsskYnMXij0ZLZQt/US
# s3OWCmejvmGfrvP9Enh1DqZbFP1FI46GRFV9GIYFjFWHeUhG98oOjafeTl/iqLYt
# WQJhiGFyGGi5uHzu5uc0LzF3gTAfuzYBje8n4/ea8EwxZI3j6/oZh6h+z+yMDDZb
# esF6uHjHyQYuRhDIjegEYNu8c3T6Ttj+qkDxss5wRoPp2kChWTrZFQlXmVYwk/PJ
# YczQCMxr7GJCkawCwO+k8IkRj3cCAwEAAaOCAzUwggMxMA4GA1UdDwEB/wQEAwIH
# gDAMBgNVHRMBAf8EAjAAMBYGA1UdJQEB/wQMMAoGCCsGAQUFBwMIMIIBvwYDVR0g
# BIIBtjCCAbIwggGhBglghkgBhv1sBwEwggGSMCgGCCsGAQUFBwIBFhxodHRwczov
# L3d3dy5kaWdpY2VydC5jb20vQ1BTMIIBZAYIKwYBBQUHAgIwggFWHoIBUgBBAG4A
# eQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAgAEMAZQByAHQAaQBmAGkAYwBhAHQA
# ZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAgAGEAYwBjAGUAcAB0AGEAbgBjAGUA
# IABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBlAHIAdAAgAEMAUAAvAEMAUABTACAA
# YQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBuAGcAIABQAGEAcgB0AHkAIABBAGcA
# cgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAgAGwAaQBtAGkAdAAgAGwAaQBhAGIA
# aQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAgAGkAbgBjAG8AcgBwAG8AcgBhAHQA
# ZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIAByAGUAZgBlAHIAZQBuAGMAZQAuMAsG
# CWCGSAGG/WwDFTAfBgNVHSMEGDAWgBQVABIrE5iymQftHt+ivlcNK2cCzTAdBgNV
# HQ4EFgQUYVpNJLZJMp1KKnkag0v0HonByn0wfQYDVR0fBHYwdDA4oDagNIYyaHR0
# cDovL2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEQ0EtMS5jcmww
# OKA2oDSGMmh0dHA6Ly9jcmw0LmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RENBLTEuY3JsMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDovL29j
# c3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURDQS0xLmNydDANBgkqhkiG9w0BAQUF
# AAOCAQEAnSV+GzNNsiaBXJuGziMgD4CH5Yj//7HUaiwx7ToXGXEXzakbvFoWOQCd
# 42yE5FpA+94GAYw3+puxnSR+/iCkV61bt5qwYCbqaVchXTQvH3Gwg5QZBWs1kBCg
# e5fH9j/n4hFBpr1i2fAnPTgdKG86Ugnw7HBi02JLsOBzppLA044x2C/jbRcTBu7k
# A7YUq/OPQ6dxnSHdFMoVXZJB2vkPgdGZdA0mxA5/G7X1oPHGdwYoFenYk+VVFvC7
# Cqsc21xIJ2bIo4sKHOWV2q7ELlmgYd3a822iYemKC23sEhi991VUQAOSK2vCUcIK
# SK+w1G7g9BQKOhvjjz3Kr2qNe9zYRDCCBrwwggWkoAMCAQICEAPxtOFfOoLxFJZ4
# s9fYR1wwDQYJKoZIhvcNAQELBQAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMi
# RGlnaUNlcnQgSGlnaCBBc3N1cmFuY2UgRVYgUm9vdCBDQTAeFw0xMjA0MTgxMjAw
# MDBaFw0yNzA0MTgxMjAwMDBaMGwxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdp
# Q2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xKzApBgNVBAMTIkRp
# Z2lDZXJ0IEVWIENvZGUgU2lnbmluZyBDQSAoU0hBMikwggEiMA0GCSqGSIb3DQEB
# AQUAA4IBDwAwggEKAoIBAQCnU/oPsrUT8WTPhID8roA10bbXx6MsrBosrPGErDo1
# EjqSkbpX5MTJ8y+oSDy31m7clyK6UXlhr0MvDbebtEkxrkRYPqShlqeHTyN+w2xl
# JJBVPqHKI3zFQunEemJFm33eY3TLnmMl+ISamq1FT659H8gTy3WbyeHhivgLDJj0
# yj7QRap6HqVYkzY0visuKzFYZrQyEJ+d8FKh7+g+03byQFrc+mo9G0utdrCMXO42
# uoPqMKhM3vELKlhBiK4AiasD0RaCICJ2615UOBJi4dJwJNvtH3DSZAmALeK2nc4f
# 8rsh82zb2LMZe4pQn+/sNgpcmrdK0wigOXn93b89OgklAgMBAAGjggNYMIIDVDAS
# BgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIBhjATBgNVHSUEDDAKBggr
# BgEFBQcDAzB/BggrBgEFBQcBAQRzMHEwJAYIKwYBBQUHMAGGGGh0dHA6Ly9vY3Nw
# LmRpZ2ljZXJ0LmNvbTBJBggrBgEFBQcwAoY9aHR0cDovL2NhY2VydHMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0SGlnaEFzc3VyYW5jZUVWUm9vdENBLmNydDCBjwYDVR0f
# BIGHMIGEMECgPqA8hjpodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRI
# aWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMECgPqA8hjpodHRwOi8vY3JsNC5kaWdp
# Y2VydC5jb20vRGlnaUNlcnRIaWdoQXNzdXJhbmNlRVZSb290Q0EuY3JsMIIBxAYD
# VR0gBIIBuzCCAbcwggGzBglghkgBhv1sAwIwggGkMDoGCCsGAQUFBwIBFi5odHRw
# Oi8vd3d3LmRpZ2ljZXJ0LmNvbS9zc2wtY3BzLXJlcG9zaXRvcnkuaHRtMIIBZAYI
# KwYBBQUHAgIwggFWHoIBUgBBAG4AeQAgAHUAcwBlACAAbwBmACAAdABoAGkAcwAg
# AEMAZQByAHQAaQBmAGkAYwBhAHQAZQAgAGMAbwBuAHMAdABpAHQAdQB0AGUAcwAg
# AGEAYwBjAGUAcAB0AGEAbgBjAGUAIABvAGYAIAB0AGgAZQAgAEQAaQBnAGkAQwBl
# AHIAdAAgAEMAUAAvAEMAUABTACAAYQBuAGQAIAB0AGgAZQAgAFIAZQBsAHkAaQBu
# AGcAIABQAGEAcgB0AHkAIABBAGcAcgBlAGUAbQBlAG4AdAAgAHcAaABpAGMAaAAg
# AGwAaQBtAGkAdAAgAGwAaQBhAGIAaQBsAGkAdAB5ACAAYQBuAGQAIABhAHIAZQAg
# AGkAbgBjAG8AcgBwAG8AcgBhAHQAZQBkACAAaABlAHIAZQBpAG4AIABiAHkAIABy
# AGUAZgBlAHIAZQBuAGMAZQAuMB0GA1UdDgQWBBSP6H7wbTJqAAUjx3CXajqQ/2vq
# 1DAfBgNVHSMEGDAWgBSxPsNpA/i/RwHUmCYaCALvY2QrwzANBgkqhkiG9w0BAQsF
# AAOCAQEAGTNKDIEzN9utNsnkyTq7tRsueqLi9ENCF56/TqFN4bHb6YHdnwHy5IjV
# 6f4J/SHB7F2A0vDWwUPC/ncr2/nXkTPObNWyGTvmLtbJk0+IQI7N4fV+8Q/GWVZy
# 6OtqQb0c1UbVfEnKZjgVwb/gkXB3h9zJjTHJDCmiM+2N4ofNiY0/G//V4BqXi3za
# bfuoxrI6Zmt7AbPN2KY07BIBq5VYpcRTV6hg5ucCEqC5I2SiTbt8gSVkIb7P7kIY
# Q5e7pTcGr03/JqVNYUvsRkG4Zc64eZ4IlguBjIo7j8eZjKMqbphtXmHGlreKuWEt
# k7jrDgRD1/X+pvBi1JlqpcHB8GSUgDCCBs0wggW1oAMCAQICEAb9+QOWA63qAArr
# Pye7uhswDQYJKoZIhvcNAQEFBQAwZTELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERp
# Z2lDZXJ0IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEkMCIGA1UEAxMb
# RGlnaUNlcnQgQXNzdXJlZCBJRCBSb290IENBMB4XDTA2MTExMDAwMDAwMFoXDTIx
# MTExMDAwMDAwMFowYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IElu
# YzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNlcnQg
# QXNzdXJlZCBJRCBDQS0xMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA
# 6IItmfnKwkKVpYBzQHDSnlZUXKnE0kEGj8kz/E1FkVyBn+0snPgWWd+etSQVwpi5
# tHdJ3InECtqvy15r7a2wcTHrzzpADEZNk+yLejYIA6sMNP4YSYL+x8cxSIB8HqIP
# kg5QycaH6zY/2DDD/6b3+6LNb3Mj/qxWBZDwMiEWicZwiPkFl32jx0PdAug7Pe2x
# QaPtP77blUjE7h6z8rwMK5nQxl0SQoHhg26Ccz8mSxSQrllmCsSNvtLOBq6thG9I
# hJtPQLnxTPKvmPv2zkBdXPao8S+v7Iki8msYZbHBc63X8djPHgp0XEK4aH631XcK
# J1Z8D2KkPzIUYJX9BwSiCQIDAQABo4IDejCCA3YwDgYDVR0PAQH/BAQDAgGGMDsG
# A1UdJQQ0MDIGCCsGAQUFBwMBBggrBgEFBQcDAgYIKwYBBQUHAwMGCCsGAQUFBwME
# BggrBgEFBQcDCDCCAdIGA1UdIASCAckwggHFMIIBtAYKYIZIAYb9bAABBDCCAaQw
# OgYIKwYBBQUHAgEWLmh0dHA6Ly93d3cuZGlnaWNlcnQuY29tL3NzbC1jcHMtcmVw
# b3NpdG9yeS5odG0wggFkBggrBgEFBQcCAjCCAVYeggFSAEEAbgB5ACAAdQBzAGUA
# IABvAGYAIAB0AGgAaQBzACAAQwBlAHIAdABpAGYAaQBjAGEAdABlACAAYwBvAG4A
# cwB0AGkAdAB1AHQAZQBzACAAYQBjAGMAZQBwAHQAYQBuAGMAZQAgAG8AZgAgAHQA
# aABlACAARABpAGcAaQBDAGUAcgB0ACAAQwBQAC8AQwBQAFMAIABhAG4AZAAgAHQA
# aABlACAAUgBlAGwAeQBpAG4AZwAgAFAAYQByAHQAeQAgAEEAZwByAGUAZQBtAGUA
# bgB0ACAAdwBoAGkAYwBoACAAbABpAG0AaQB0ACAAbABpAGEAYgBpAGwAaQB0AHkA
# IABhAG4AZAAgAGEAcgBlACAAaQBuAGMAbwByAHAAbwByAGEAdABlAGQAIABoAGUA
# cgBlAGkAbgAgAGIAeQAgAHIAZQBmAGUAcgBlAG4AYwBlAC4wCwYJYIZIAYb9bAMV
# MBIGA1UdEwEB/wQIMAYBAf8CAQAweQYIKwYBBQUHAQEEbTBrMCQGCCsGAQUFBzAB
# hhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUHMAKGN2h0dHA6Ly9j
# YWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcnQw
# gYEGA1UdHwR6MHgwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9EaWdp
# Q2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwOqA4oDaGNGh0dHA6Ly9jcmw0LmRpZ2lj
# ZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwHQYDVR0OBBYEFBUA
# EisTmLKZB+0e36K+Vw0rZwLNMB8GA1UdIwQYMBaAFEXroq/0ksuCMS1Ri6enIZ3z
# bcgPMA0GCSqGSIb3DQEBBQUAA4IBAQBGUD7Jtygkpzgdtlspr1LPUukxR6tWXHvV
# DQtBs+/sdR90OPKyXGGinJXDUOSCuSPRujqGcq04eKx1XRcXNHJHhZRW0eu7NoR3
# zCSl8wQZVann4+erYs37iy2QwsDStZS9Xk+xBdIOPRqpFFumhjFiqKgz5Js5p8T1
# zh14dpQlc+Qqq8+cdkvtX8JLFuRLcEwAiR78xXm8TBJX/l/hHrwCXaj++wc4Tw3G
# XZG5D2dFzdaD7eeSDY2xaYxP+1ngIw/Sqq4AfO6cQg7PkdcntxbuD8O9fAqg7iwI
# VYUiuOsYGk38KiGtSTGDR5V3cdyxG0tLHBCcdxTBnU8vWpUIKRAmMYIERjCCBEIC
# AQEwgYAwbDELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0IEluYzEZMBcG
# A1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTErMCkGA1UEAxMiRGlnaUNlcnQgRVYgQ29k
# ZSBTaWduaW5nIENBIChTSEEyKQIQC/YrF6l/9vGkuqceshfX5zANBglghkgBZQME
# AgEFAKCBhDAYBgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEM
# BgorBgEEAYI3AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqG
# SIb3DQEJBDEiBCAUrLl79G72zhoeI0+zjCZExVwxgoPmKuG9C7Dv3xwuojANBgkq
# hkiG9w0BAQEFAASCAQAx+1KvrXZyX/4ZB0q+rDLpvgwkZqmLgYY7jko0Zw1T6VFY
# uRJYsoFMf3kTOtz87oAxMxSYgULE3NbA3PSos272rmiMhHiRrXFJGlJrsRAykPob
# rIU9tsf8JznSEwBiLH4r3I5nVtX2/HGCI7LtIiHeNP6dChAWfJ1VUQ2LbZtbqipa
# f83EJ66E2KQtZqXK7XvqjVoma2I7sZ7EVwQ2mngmuza86mSc86aVDKVU6Fqbm3pc
# S+MvZzTz22vANi9rrqKmlEj5i5Xl+8QBr5btClK6deviBmbWU/T2mTiK5VzORlf2
# AzlzAUIU7ty/U1t6/2NmqhltVc0JQckQy6ei+6jmoYICDzCCAgsGCSqGSIb3DQEJ
# BjGCAfwwggH4AgEBMHYwYjELMAkGA1UEBhMCVVMxFTATBgNVBAoTDERpZ2lDZXJ0
# IEluYzEZMBcGA1UECxMQd3d3LmRpZ2ljZXJ0LmNvbTEhMB8GA1UEAxMYRGlnaUNl
# cnQgQXNzdXJlZCBJRCBDQS0xAhADAZoCOv9YsWvW1ermF/BmMAkGBSsOAwIaBQCg
# XTAYBgkqhkiG9w0BCQMxCwYJKoZIhvcNAQcBMBwGCSqGSIb3DQEJBTEPFw0yMDEw
# MTkxMDMxMjJaMCMGCSqGSIb3DQEJBDEWBBQNXRiVga/cHKAnjTd3jwl4+lP8XDAN
# BgkqhkiG9w0BAQEFAASCAQATHJW5JGiPULvh0+jWjYauUnG9k82F8YNlzbrGmUN9
# 6KIHrcTdnSxsFgfk9gSnESF0q5T3FE74oJNJalHbseDdr0liDXhqzMNq0sZO3fGx
# ssQHxIgCuka/H11uyAZ/0fohTkVReKYt0rkIxHNYZpfCCTY8n5J0H8KgFUZwdmxo
# 1rvXR5eDYu4M9jP4ZGxlNKhHehS/PXHZ+5nLvsQ9Yldyi62JnVoEuTFcdabJdwMK
# Pkfj1oy6zJ6TjiYRSZD6prGpbFAK7ai6e1vYnAzYIbHaONhX3EK8y/yc0v52nvVM
# ATjD9Za8oB21BSg+BUYsW8TgblBk6mU18HUAFGzGJ+np
# SIG # End signature block
