

SOLARFLARE XTREMESCALE X2 SERIES TOOLS PACKAGE


Package Version: v1.9.1


Overview

This is the v1.9.1 Windows tools package for Solarflare XtremeScale X2
series network adapters.


Supported hardware platforms

This release of the Solarflare XtremeScale X2 tools supports the
following Solarflare adapters:

-   Solarflare Flareon Ultra 8000 Series 10G Adapter
-   Solarflare Flareon Ultra 8000 Series 10/40G Adapter
-   Solarflare Flareon Ultra 8000 Series OCP 10G Adapter
-   Solarflare 8000 Series 10G Adapter
-   Solarflare 8000 Series 10/40G Adapter
-   Solarflare XtremeScale X2522-25G Adapter
-   Solarflare XtremeScale X2522 (10G) Adapter
-   Solarflare XtremeScale X2541 Adapter
-   Solarflare XtremeScale X2542 Adapter
-   Solarflare XtremeScale X2552 Adapter
-   Solarflare XtremeScale X2562 Adapter

The following OEM adapters are also supported, but note each OEM may
recommend a different package version to match the version used during
their testing and qualification:

-   Dell variants of the Solarflare XtremeScale X2522-25G Adapter (Dell
    Part Number HCHXD, D64WK, XY21R and YTX2V)
-   Dell variants of the Solarflare XtremeScale X2562 Adapter (Dell Part
    Number 8HRW3 and TTKWY)


Supported operating systems

This release of the Solarflare XtremeScale X2 tools supports the
following Microsoft operating systems:

-   Windows Server 2012 R2
-   Windows Server 2016 (version 1607, build 14393)
-   Windows Server 2019 (version 1809, build 17763)


Contents

  ------------------------------------------------------------------------
  File                          Description
  ----------------------------- ------------------------------------------
  readme.txt                    This file.

  license.txt                   Solarflare software license agreement.

  SolarflareTools.1.9.1.nupkg   SolarflareTools NuGet package.
  ------------------------------------------------------------------------


Installation prerequisites

Windows PowerShell version

The Solarflare XtremeScale X2 tools require Windows PowerShell 5.1 which
is installed by default with Windows Server 2016 and later. PowerShell
5.1 is available as an optional update for Windows Server 2012 R2. To
determine your currently installed version open a PowerShell console and
type:

    $PSVersionTable.PSVersion

If the output does not show major version 5 and minor version 1 then
install Windows Management Framework 5.1 which available for download
from Microsoft at
https://www.microsoft.com/en-us/download/details.aspx?id=54616.

Windows PowerShell execution policy

In order to use Solarflare XtremeScale X2 tools PowerShell must be
configured to allow scripts to be executed. For more information about
PowerShell execution policies, type:

    Update-Help -Module Microsoft.PowerShell.Core
    help about_Execution_Policies

In order for scripts to run PowerShell's execution policy must be set to
AllSigned, RemoteSigned, Unrestricted or Bypass. To verify an
appropriate execution policy has been configured, type:

    Get-ExecutionPolicy

To change the execution policy for the current user type:

    Set-ExecutionPolicy -ExecutionPolicy <Policy> -Scope CurrentUser -Force

Or to change the execution policy for all users of the computer, as user
with local administrative privileges at an elevated PowerShell prompt,
type:

    Set-ExecutionPolicy -ExecutionPolicy <Policy> -Scope LocalMachine -Force

Local PowerShellGet repository

The Solarflare XtremeScale X2 tools are distributed as a NuGet package.
Prior to installation this package must be added to a PowerShellGet
repository. Information about working with local PowerShellGet
repositories is available at
https://docs.microsoft.com/en-gb/powershell/scripting/gallery/how-to/working-with-local-psrepositories?view=powershell-5.1.

PowerShellGet requires NuGet provider version 2.8.5.201 or later to
interact with package repositories. PowerShellGet will prompt to ask
permission to install and import the NuGet provider from PowerShell
Gallery on first use. Note that PowerShell Gallery now requires a TLS
1.2 or better connection. To configure the current session for this:

    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

The steps required to manually install the NuGet provider on a computer
that is not connected to the Internet are available at
https://docs.microsoft.com/en-us/powershell/scripting/gallery/how-to/getting-support/bootstrapping-nuget?view=powershell-5.1.

If you do not have a NuGet server or file share setup as a PowerShellGet
repository, a folder on the local computer can be used instead:

    New-Item -Path <LocalRepositoryFolderPath> -Type Directory
    Register-PSRepository -Name Local -InstallationPolicy Trusted -SourceLocation (Resolve-Path <LocalRepositoryFolderPath>).ProviderPath


Installation

Unpack the tools ZIP archive into a dedicated folder. From a PowerShell
prompt, type:

    Expand-Archive <ToolsPackageArchivePath> -DestinationPath <ToolsPackageFolderPath>

Add the SolarflareTools NuGet package to your PowerShellGet repository.
For example if using a folder on the local computer, type:

    Copy-Item -Path <ToolsPackageFolderPath>\SolarflareTools.1.9.1.nupkg -Destination <LocalRepositoryFolderPath>

To install the SolarflareTools module for all users of the computer, as
user with local administrative privileges at an elevated PowerShell
prompt, type:

    Install-Module -Name SolarflareTools -Scope AllUsers -Force

Alternatively to install the SolarflareTools module for only the current
user type:

    Install-Module -Name SolarflareTools -Scope CurrentUser -Force

To verify the SolarflareTools module is correctly installed into a
folder in the PSModulePath environment variable, type:

    Get-Module -Name SolarflareTools -ListAvailable

Confirm that the expected module version is shown (i.e. 1.9.1).

To add the SolarflareTools module to the current PowerShell session
type:

    Import-Module -Name SolarflareTools

Depending on your PowerShell execution policy, PowerShell may request
your permission to trust and run software published by "Solarflare
Communications, Inc.".


Using SolarflareTools

The SolarflareTools module is intended to be used by a user with local
administrative privileges at an elevated PowerShell prompt. PowerShell
typically imports trusted modules automatically the first time that you
run any command in an installed module. To manually add the
SolarflareTools module to the current PowerShell session type:

    Import-Module -Name SolarflareTools

For convenience the top-level utilities provided by the SolarflareTools
module can be accessed with short aliases. These are:

  ---------- ------------------------------------------------------------
  SfReport   The SfReport utility will generate a diagnostic file
             detailing aspects of the computer and Solarflare adapter
             configuration.

  SfConfig   The SfConfig utility is used to configure Solarflare adapter
             hardware and firmware settings.

  SfUpdate   The SfUpdate utility is used to manage Solarflare adapter
             firmware.
  ---------- ------------------------------------------------------------

The full set of commands that are available can be listed by:

    Get-Command -Module SolarflareTools -CommandType All

Help is available on all commands. For example:

    help -Detailed SfConfig

Some other useful example command lines:

  -------------------------- --------------------------------------------
  SfReport | Invoke-Item     Generate the full report HTML file and
                             invoke the default browser to view the
                             result.

  SfConfig -Clear            Clear configuration to factory defaults for
                             all Solarflare adapters installed in the
                             local computer.

  SfUpdate -Confirm:$false   Update the firmware on Solarflare adapters
                             installed in the local computer.
  -------------------------- --------------------------------------------


Known issues

For an up to date list of errata and workarounds please refer to the
known issues database at https://support.solarflare.com/.


Additional information

For detailed instructions of how to install and use the Solarflare
XtremeScale X2 tools please refer to the Windows chapter in the
"Solarflare Server Adapter User's Guide" (SF-103837-CD).

We recommend performing a cold reboot of the machine after updating
adapter firmware.


Support

Please contact your local Solarflare support representative or email
support@solarflare.com.


Firmware versions

The firmware update tool (SfUpdate) contained in this package includes
the following firmware:

  ----------------------------------------------------------
  Component                                    Version
  -------------------------------------------- -------------
  SFN8522 firmware family                      v8.0.0.1005

  -- Controller firmware                       v8.0.0.1015

  -- BootROM image                             v5.2.2.1006

  -- UEFI driver                               v2.9.5.10

  SFN8542 firmware family                      v8.0.0.1005

  -- Controller firmware                       v8.0.0.1015

  -- BootROM image                             v5.2.2.1006

  -- UEFI driver                               v2.9.5.10

  SFN8722 firmware family                      v8.0.0.1005

  -- Controller firmware                       v8.0.0.1015

  -- Board support microcontroller firmware    v2.1.1.1028

  -- BootROM image                             v5.2.2.1006

  -- UEFI driver                               v2.9.5.10

  SFN8522M firmware family                     v8.0.0.1005

  -- Controller firmware                       v8.0.0.1015

  -- Board support microcontroller firmware    v2.1.1.1028

  -- BootROM image                             v5.2.2.1006

  -- UEFI driver                               v2.9.5.10

  SFN8042 firmware family                      v8.0.0.1005

  -- Controller firmware                       v8.0.0.1015

  -- Board support microcontroller firmware    v2.1.1.1028

  -- BootROM image                             v5.2.2.1006

  -- UEFI driver                               v2.9.5.10

  X2522 (10G) bundle                           v8.0.0.1005

  -- Controller firmware                       v8.0.0.1015

  -- Board support microcontroller firmware    v2.1.1.1028

  -- BootROM image                             v5.2.2.1006

  -- UEFI driver                               v2.9.5.10

  X2522-25G bundle                             v8.0.0.1005

  -- Controller firmware                       v8.0.0.1015

  -- Board support microcontroller firmware    v2.1.1.1028

  -- BootROM image                             v5.2.2.1006

  -- UEFI driver                               v2.9.5.10

  X2541 bundle                                 v8.0.0.1005

  -- Controller firmware                       v8.0.0.1015

  -- Board support microcontroller firmware    v2.1.1.1028

  -- BootROM image                             v5.2.2.1006

  -- UEFI driver                               v2.9.5.10

  X2542 bundle                                 v8.0.0.1005

  -- Controller firmware                       v8.0.0.1015

  -- Board support microcontroller firmware    v2.1.1.1028

  -- BootROM image                             v5.2.2.1006

  -- UEFI driver                               v2.9.5.10

  X2552 bundle                                 v8.0.0.1005

  -- Controller firmware                       v8.0.0.1015

  -- Board support microcontroller firmware    v2.1.1.1028

  -- BootROM image                             v5.2.2.1006

  -- UEFI driver                               v2.9.5.10

  X2562 bundle                                 v8.0.0.1005

  -- Controller firmware                       v8.0.0.1015

  -- Board support microcontroller firmware    v2.1.1.1028

  -- BootROM image                             v5.2.2.1006

  -- UEFI driver                               v2.9.5.10
  ----------------------------------------------------------


Change logs

Solarflare XtremeScale X2 Series support tools

v1.9.1.1004 --- Feature Release

-   Added support for NIC Partitioning mode

v1.9.1.1002 --- Firmware Update

-   Update firmware package to v8.0.0.1005 release collection

v1.8.0.1017 --- Feature Release

-   Added support for 8000 series adapters

v1.5.4.1004 --- Feature Release

-   Initial release


Copyright

Copyright 2020 Xilinx, Inc. All rights reserved. Copyright 2018-2019
Solarflare Communications Inc. Use is subject to license terms.
