

SOLARFLARE XTREMESCALE X2 SERIES DRIVER PACKAGE


Package Version: v1.9.2.1000


Overview

This is the v1.9.2 Windows driver package for Solarflare XtremeScale X2
series network adapters.


Supported hardware platforms

The drivers, utilities and applications contained in this package
support the following Solarflare adapters:

-   Solarflare Flareon Ultra 8000 Series 10G Adapter
-   Solarflare Flareon Ultra 8000 Series 10/40G Adapter
-   Solarflare Flareon Ultra 8000 Series OCP 10G Adapter
-   Solarflare 8000 Series 10G Adapter
-   Solarflare 8000 Series 10/40G Adapter
-   Solarflare XtremeScale X2522-25G Adapter
-   Solarflare XtremeScale X2522 (10G) Adapter
-   Solarflare XtremeScale X2541 Adapter
-   Solarflare XtremeScale X2542 Adapter
-   Solarflare XtremeScale X2552 Adapter
-   Solarflare XtremeScale X2562 Adapter

The following OEM adapters are also supported, but note each OEM may
recommend a different package version to match the version used during
their testing and qualification:

-   Dell variants of the Solarflare XtremeScale X2522-25G Adapter (Dell
    Part Number HCHXD, D64WK, XY21R and YTX2V)
-   Dell variants of the Solarflare XtremeScale X2562 Adapter (Dell Part
    Number 8HRW3 and TTKWY)


Supported operating systems

This package contains drivers supporting _Desktop Experience_ and
_Server Core_ installations of:

-   Windows Server 2012 R2
-   Windows Server 2016 (version 1607, build 14393)
-   Windows Server 2019 (version 1809, build 17763)


Contents

  -----------------------------------------------------------------------
  File                 Description
  -------------------- --------------------------------------------------
  readme.txt           This file.

  license.txt          Solarflare software license agreement.

  WS2012R2             Windows Server 2012 R2 driver folder.

  WS2016               Windows Server 2016 (version 1607, build 14393)
                       driver folder.

  WS2019               Windows Server 2019 (version 1809, build 17763)
                       driver folder.
  -----------------------------------------------------------------------


Each OS-specific folder contains:

  -----------------------------------------------------------------------
  File                 Description
  -------------------- --------------------------------------------------
  sfn.inf sfn.sys      Solarflare XtremeScale X2 series network adapter
  sfn.cat              driver.

  sfn.man              An event instrumentation manifest describing the
                       driver's Windows Event Log channels and event
                       messages.

  sfn.wprp             A Windows Performance Recorder profile for
                       gathering driver analytic logging and performance
                       data.
  -----------------------------------------------------------------------


Installation

Unpack the driver package ZIP archive into a dedicated folder. From a
PowerShell prompt, type:

    Expand-Archive <DriverPackageArchivePath> -DestinationPath <DriverPackageFolderPath>

Install the appropriate driver and event instrumentation manifest for
the version of Windows Server installed on the computer. To identify the
version of Windows Server type:

Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version

As a user with local administrative privileges from an elevated
PowerShell prompt, type:

Windows Server 2012 R2

    Set-Location <DriverPackageFolderPath>\WS2012R2
    pnputil.exe -i -a sfn.inf
    wevtutil.exe uninstall-manifest sfn.man
    wevtutil.exe install-manifest sfn.man /resourceFilePath:"${Env:SystemRoot}\system32\drivers\sfn.sys" /messageFilePath:"${Env:SystemRoot}\system32\drivers\sfn.sys"

Windows Server 2016

    Set-Location <DriverPackageFolderPath>\WS2016
    pnputil.exe /add-driver sfn.inf /install
    wevtutil.exe install-manifest sfn.man /resourceFilePath:"${Env:SystemRoot}\system32\drivers\sfn.sys" /messageFilePath:"${Env:SystemRoot}\system32\drivers\sfn.sys"

Windows Server 2019

    Set-Location <DriverPackageFolderPath>\WS2019
    pnputil.exe /add-driver sfn.inf /install

To verify the expected driver version is installed and loaded, type:

    Get-NetAdapter |? DriverProvider -eq Solarflare | Format-Table -View Driver

Confirm that the output includes at least one Solarflare network
adapter, and the expected driver version is shown (i.e. 1.9.2.1000).


Known issues

For an up to date list of errata and workarounds please refer to the
known issues database at https://support.solarflare.com/.


Additional information

For detailed instructions of how to install and configure the Windows
drivers and applications please refer to the Windows chapter in the
"Solarflare Server Adapter User's Guide" (SF-103837-CD).


Support

Please contact your local Solarflare support representative or email
support@solarflare.com.


Change logs

Solarflare XtremeScale X2 Series Driver

v1.9.2.1000 --- Bug fix Release

FIXES:

-   Fixed an issue that could result in a NMI_HARDWARE_FAILURE (80) bug
    check at OS shutdown. (SWUTILSWIN-852)

v1.9.1.1002 --- Bug fix Release

FIXES:

-   Fixed an issue with JumboFrames configuration option. (WIN-628)

v1.8.2.1001 --- Bug fix Release

FIXES:

-   Fixed a potential connectivity issue following driver unload.
    (APPFW-324)

v1.8.0.1013 --- Feature Release

FEATURES AND ENHANCEMENTS:

-   Support for Windows Server 2012 R2 (all adapters).
-   Support for X2552 adapters.
-   Support for 8000 series adapters.
-   Support for Virtual Machine Queues (VMQ).

v1.7.0.1003 --- Feature Release

FEATURES AND ENHANCEMENTS:

-   Support for X2562 adapters.

v1.6.1.1003 --- Feature Release

FEATURES AND ENHANCEMENTS:

-   Support for Windows Server 2019.
-   Support for Dell variants of X2562 adapter (Dell EMC P/N: 8HRW3,
    TTKWY).
-   Improvements to buffer management, control channel and statistics
    gathering.

FIXES:

-   Improve handling of adapter firmware reboots and exceptions.
    (WIN-503 and WIN-509)

v1.4.1.1000 --- Feature Release

FEATURES AND ENHANCEMENTS:

-   Support for Dell variants of X2522-25G adapters (Dell EMC P/N:
    HCHXD, D64WK, XY21R, YTX2V).
-   Support for bundled adapter firmware updates.

v1.3.10.1004 --- Feature Release

FEATURES AND ENHANCEMENTS:

-   Support for Windows Server 2012 R2 (with X2542 adapters only).
-   Report driver version via NC-SI (Network Controller Sideband
    Interface).
-   Improved adapter hardware sensor monitoring. Logged sensor events
    should be more relevant as readings are filtered to exclude
    insignificant changes and each logged event includes the sensor's
    description and current reading.

FIXES:

-   Ensure uncompleted transmit datapath requests cannot cause a system
    hang during driver unload (i.e. at system shutdown, system restart,
    or when the network adapter is disabled). (WIN-333)
-   Improve handling of adapter firmware reboots and exceptions reducing
    the possibility of a system hang during driver unload (i.e. at
    system shutdown, system restart, or when the network adapter is
    disabled). (WIN-429, WIN-449, WIN-450 and WIN-454)
-   Resolve a potential data corruption issue when using TCP Large Send
    Offload (LSO) on systems that are using 'bounce buffers' for DMA by
    ensuring all packet edits occur before building the scatter gather
    list for the LSO request. (WIN-463)
-   Allow the transmit datapath to wait in the rare cases that DMA
    mapping can't be performed synchronously preventing packets from
    being discarded unnecessarily. (WIN-439 and WIN-464)
-   Prevent Vital Product Data (VPD) access via Windows Management
    Instrumentation (WMI) exposing the contents of uninitialized memory.
    (JIT-123753)
-   Ensure driver initialization failures are logged to the system event
    log. (WIN-429)
-   Maintain datapath statistics across miniport adapter pause and
    restart transitions. (WIN-469)
-   Bring link down, rather than failing driver load, if link
    configuration is not achievable in the adapter's current port mode.
    (WIN-477)

v1.2.1.1004 --- Feature Release

FEATURES AND ENHANCEMENTS:

-   Support for X2541 and X2542 adapters.
-   Support for Receive Segment Coalescing (RSC) offload.
-   Support the NDIS standardized network adapter configuration
    parameters to configure receive and transmit queue sizes:
    -   The 'Receive Buffers' configuration option sets number of
        receive packet buffers allocated for each RSS receive queue. An
        appropriate hardware receive queue size is chosen by the driver
        based on this setting. Increasing this value may improve receive
        performance and reduce occurrences of packet discards under
        heavy load, but consumes additional system memory. Setting this
        value higher than necessary can waste limited system resources,
        impact overall system performance and may cause the driver to
        fail initialization.
    -   The 'Transmit Buffers' configuration option sets the number of
        descriptors that can be queued simultaneously on each hardware
        transmit queue. An appropriate hardware transmit queue size is
        chosen by the driver based on this setting. As each packet may
        require multiple descriptors the number of packets that can be
        queued simultaneously may be lower than the queue size.
        Increasing this value may improve transmit performance, but also
        consumes more system resources.
-   Increased receive and transmit datapath performance (due to improved
    NUMA locality of memory allocations for hardware queues and receive
    packet buffers).
-   Additional MAC and datapath statistics are exposed via Windows
    Management Instrumentation (WMI).

FIXES:

-   Improve handling of memory allocation failures for event, receive or
    transmit queue common buffers. (WIN-393)
-   Fix an issue with receive queue refill that would result in all
    received packets being discarded once a receive queue has processed
    approximately 4.3 billion packets. (WIN-387)
-   Include the count of frames discarded due to hardware vFIFO overflow
    in the dropped receive buffer error count which is reported to NDIS
    via OID_GEN_STATISTICS and OID_GEN_RCV_ERROR queries. (WIN-377)
-   Fix an issue that could result in a DPC_WATCHDOG_VIOLATION (133) bug
    check when unblocking a transmit queue after it had become full.
    This issue is more likely to be triggered when using a smaller than
    default hardware transmit queue size, a high number of physical
    memory fragments per send request (such as when firmware assisted
    Large Send Offload is disabled) and extreme load. (WIN-367)
-   Reduce the time taken for network adapter disable, system restart
    and system shutdown by upto 5 seconds. (WIN-319)
-   Limit the number of receive indication events and send completion
    events processed in a single DPC reducing the possibility of a
    DPC_WATCHDOG_VIOLATION (133) bug check. (WIN-214)

v1.0.0.1012 --- Feature Release

-   Initial release supporting X2522 (10G) and X2522-25G adapters.


Copyright

Copyright 2020-2021 Xilinx, Inc. All rights reserved. Copyright
2017-2019 Solarflare Communications Inc. Use is subject to license
terms.
