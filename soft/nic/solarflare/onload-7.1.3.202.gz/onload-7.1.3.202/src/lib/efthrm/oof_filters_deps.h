/* SPDX-License-Identifier: BSD-2-Clause */
/* X-SPDX-Copyright-Text: (c) Copyright 2021 Xilinx, Inc. */

#ifndef __OOF_FILTERS_DEPS_H__
#define __OOF_FILTERS_DEPS_H__
#include <onload/cplane_modparam.h>
#endif
