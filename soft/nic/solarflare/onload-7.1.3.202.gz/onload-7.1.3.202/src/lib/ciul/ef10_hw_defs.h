/* SPDX-License-Identifier: LGPL-2.1 */
/* X-SPDX-Copyright-Text: (c) Solarflare Communications Inc */
#ifndef	EF10_HW_DEFS_H
#define	EF10_HW_DEFS_H

#include <ci/driver/efab/hardware/host_ef10_common.h>

#endif /* EF10_HW_DEFS_H */
