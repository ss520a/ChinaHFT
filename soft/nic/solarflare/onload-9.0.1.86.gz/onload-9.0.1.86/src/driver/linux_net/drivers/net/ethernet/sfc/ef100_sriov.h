/****************************************************************************
 * Driver for Solarflare network controllers and boards
 * Copyright 2019 Solarflare Communications Inc.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 as published
 * by the Free Software Foundation, incorporated herein by reference.
 */
#include "net_driver.h"

int efx_ef100_sriov_configure(struct efx_nic *efx, int num_vfs);
int efx_ef100_pci_sriov_disable(struct efx_nic *efx, bool force);
