/* SPDX-License-Identifier: BSD-2-Clause */
/* X-SPDX-Copyright-Text: (c) Copyright 2007-2020 Xilinx, Inc. */

#ifndef __EF_VI_EF10_H__
#define __EF_VI_EF10_H__    

#include "ef10_hw_defs.h"
#include <ci/driver/efab/hardware/ef10_vaddr.h>

#endif  /* __EF_VI_EF10_H__ */
