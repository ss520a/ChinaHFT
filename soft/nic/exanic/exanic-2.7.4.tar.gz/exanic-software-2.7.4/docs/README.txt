The ExaNIC documentation can now be found online at https://exablaze.com/docs/exanic/
